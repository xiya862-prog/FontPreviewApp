# ---- 通用 ----
-keepattributes Signature, InnerClasses, EnclosingMethod, RuntimeVisibleAnnotations, RuntimeVisibleParameterAnnotations, AnnotationDefault, *Annotation*
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile

# ---- kotlinx.serialization：应用里所有 @Serializable 类 ----
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.oneuirepo.app.**$$serializer { *; }
-keepclassmembers class com.oneuirepo.app.** { *** Companion; }
-keepclasseswithmembers class com.oneuirepo.app.** { kotlinx.serialization.KSerializer serializer(...); }

# ---- Retrofit（接口方法 + 挂起函数）----
-keep interface com.oneuirepo.app.data.remote.** { *; }
-keep class com.oneuirepo.app.data.remote.** { *; }
-keepclassmembers,allowshrinking,allowobfuscation interface * { @retrofit2.http.* <methods>; }
-dontwarn retrofit2.KotlinExtensions
-dontwarn retrofit2.KotlinExtensions$*
-if interface * { @retrofit2.http.* public *** *(...); }
-keep,allowoptimization,allowshrinking,allowobfuscation class <3>
-keep,allowobfuscation,allowshrinking class kotlin.coroutines.Continuation
-keep,allowobfuscation,allowshrinking class retrofit2.Response

# ---- Room / WorkManager（反射创建）----
-keep class * extends androidx.room.RoomDatabase { *; }
-keep class * extends androidx.work.ListenableWorker { public <init>(android.content.Context, androidx.work.WorkerParameters); }

# ---- 本应用的数据层（Room 实体 / DAO 查询结果 POJO）----
-keep class com.oneuirepo.app.data.local.** { *; }
-keep class com.oneuirepo.app.cve.** { *; }
-keep class com.oneuirepo.app.domain.model.** { *; }

# ---- OkHttp / Okio 可选依赖 ----
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-dontwarn javax.annotation.**
-dontwarn okhttp3.internal.platform.**
