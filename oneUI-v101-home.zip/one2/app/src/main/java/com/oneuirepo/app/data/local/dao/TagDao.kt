package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.CategoryTagEntity
import com.oneuirepo.app.data.local.entity.RepoTagEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TagDao {
    @Query("SELECT * FROM category_tag WHERE categoryId=:cat ORDER BY id")
    fun observeTags(cat: String): Flow<List<CategoryTagEntity>>

    @Query("SELECT rt.* FROM repo_tag rt INNER JOIN category_tag t ON rt.tagId=t.id WHERE t.categoryId=:cat")
    fun observeLinks(cat: String): Flow<List<RepoTagEntity>>

    @Insert
    suspend fun insertTag(t: CategoryTagEntity): Long

    @Query("DELETE FROM category_tag WHERE id=:id")
    suspend fun deleteTag(id: Long)

    @Query("DELETE FROM repo_tag WHERE tagId=:id")
    suspend fun deleteTagLinks(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addLink(x: RepoTagEntity)

    @Query("DELETE FROM repo_tag WHERE repositoryId=:repoId AND tagId=:tagId")
    suspend fun removeLink(repoId: Long, tagId: Long)

    @Query("DELETE FROM repo_tag WHERE tagId IN (SELECT id FROM category_tag WHERE categoryId=:cat)")
    suspend fun deleteLinksOfCategory(cat: String)

    @Query("DELETE FROM category_tag WHERE categoryId=:cat")
    suspend fun deleteTagsOfCategory(cat: String)
}
