package com.oneuirepo.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import com.oneuirepo.app.ui.category.CategoryMiniIcon
import com.oneuirepo.app.ui.theme.ThemeState
import com.oneuirepo.app.ui.category.catOf
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.theme.cardBorder
import kotlin.math.cos
import kotlin.math.sin

/** 悬浮底栏占用的高度（含系统导航栏），各页面滚动列表在底部预留，内容才能滑到底栏下面也不被挡住。 */
val LocalNavInset = androidx.compose.runtime.compositionLocalOf { 0.dp }

enum class NavGlyph { HOME, DISCOVER, CATEGORY, FAVORITE, SETTINGS }

data class NavItem(val title: String, val glyph: NavGlyph)

/**
 * 悬浮胶囊导航栏：白色圆角胶囊 + 磨砂背景；选中的浅色胶囊会弹性滑到新位置，图标各自有选中动画。
 * [vertical] = true 时旋转成竖排，贴在屏幕左边或右边（[railAtEnd]），用于横屏 / 外屏。
 */
@Composable
fun FloatingNavBar(
    items: List<NavItem>, selected: Int, activeCategory: String? = null, scrollFar: Boolean = false,
    backdrop: GraphicsLayer? = null, backdropOrigin: () -> Offset = { Offset.Zero },
    vertical: Boolean = false, railAtEnd: Boolean = false,
    onSelect: (Int) -> Unit
) {
    val itemH = if (vertical) 56.dp else 58.dp
    // 磨砂强度：0 = 不透明白底（原样），1 = 最通透 + 最强模糊
    val glass = ThemeState.navGlass
    val overlayAlpha = 1f - 0.62f * glass
    val blurPx = with(LocalDensity.current) { (26.dp * glass).toPx() }
    val surface = MaterialTheme.colorScheme.surface
    val outer = if (vertical) Modifier.fillMaxHeight().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp)
    else Modifier.fillMaxWidth().navigationBarsPadding().padding(start = 18.dp, end = 18.dp, bottom = 10.dp)
    Box(outer) {
        val surfaceMod = if (vertical)
            Modifier.align(if (railAtEnd) Alignment.CenterEnd else Alignment.CenterStart).width(80.dp)
        else
            // 折叠屏 / 平板展开后不要把导航栏拉成一整条，居中最宽 560dp
            Modifier.align(Alignment.Center).widthIn(max = 560.dp).fillMaxWidth()
        Surface(
            modifier = surfaceMod,
            shape = RoundedCornerShape(50),
            color = Color.Transparent,
            shadowElevation = (14f * (1f - 0.55f * glass)).dp,
            border = cardBorder() ?: BorderStroke(1.dp, Color.White.copy(alpha = 0.35f + 0.35f * glass))
        ) {
            Box {
                // 1 模糊后的背后内容（真正的磨砂玻璃）
                if (backdrop != null && glass > 0.02f) {
                    Box(Modifier.matchParentSize().glassBackdrop(backdrop, backdropOrigin, blurPx))
                }
                // 2 着色层：整体半透明底色 + 一点主题色渐变
                Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(surface.copy(alpha = overlayAlpha), surface.copy(alpha = overlayAlpha * 0.9f)))))
                Box(
                    Modifier.matchParentSize().background(
                        Brush.horizontalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.10f * glass),
                                Color.Transparent,
                                MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f * glass)
                            )
                        )
                    )
                )
                BoxWithConstraints(Modifier.padding(6.dp)) {
                    if (vertical) {
                        val y by animateDpAsState(
                            itemH * selected,
                            spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow), label = "navpillY"
                        )
                        // 竖排：选中底沿竖直方向滑动
                        Box(
                            Modifier.offset(y = y).fillMaxWidth().height(itemH)
                                .clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.secondaryContainer)
                        )
                        Column(Modifier.fillMaxWidth()) {
                            items.forEachIndexed { i, item ->
                                NavItemView(Modifier.fillMaxWidth(), item, i == selected, scrollFar, activeCategory, itemH) { onSelect(i) }
                            }
                        }
                    } else {
                        val itemW = maxWidth / items.size
                        val x by animateDpAsState(
                            itemW * selected,
                            spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMediumLow), label = "navpill"
                        )
                        // 滑动的选中底
                        Box(
                            Modifier.offset(x = x).width(itemW).height(itemH)
                                .clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.secondaryContainer)
                        )
                        Row(Modifier.fillMaxWidth()) {
                            items.forEachIndexed { i, item ->
                                NavItemView(Modifier.weight(1f), item, i == selected, scrollFar, activeCategory, itemH) { onSelect(i) }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** 单个导航项：图标（带各自的选中形变动画）+ 文字；横排竖排共用。 */
@Composable
private fun NavItemView(
    modifier: Modifier, item: NavItem, sel: Boolean, scrollFar: Boolean, activeCategory: String?, itemH: Dp, onClick: () -> Unit
) {
    // 带回弹的进度：选中时会略微冲过 1 再回落，形成弹跳 / 心跳 / 旋转的感觉
    val t by animateFloatAsState(
        if (sel) 1f else 0f,
        spring(dampingRatio = 0.38f, stiffness = Spring.StiffnessLow), label = "navicon"
    )
    val density = LocalDensity.current
    Column(
        modifier.height(itemH).clip(RoundedCornerShape(50))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // 固定高度的图标槽，彩色徽标 / 轮廓图标 / 普通图标切换时下面的文字不会跳动
        Box(Modifier.size(width = 30.dp, height = 28.dp), contentAlignment = Alignment.Center) {
            AnimatedContent(
                targetState = sel && scrollFar,
                transitionSpec = {
                    (fadeIn(tween(160)) + scaleIn(spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMediumLow), initialScale = 0.3f)) togetherWith
                        (fadeOut(tween(110)) + scaleOut(tween(130), targetScale = 0.3f))
                },
                label = "topMorph"
            ) { top ->
                if (top) {
                    BackToTopIcon()
                } else if (item.glyph == NavGlyph.CATEGORY) {
                    // 进入某个分类后，「分类」图标弹性变形成该分类的小图标；返回后变回网格图标
                    AnimatedContent(
                        targetState = activeCategory,
                        transitionSpec = {
                            (fadeIn(tween(200)) + scaleIn(spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMediumLow), initialScale = 0.3f)) togetherWith
                                (fadeOut(tween(120)) + scaleOut(tween(150), targetScale = 0.3f))
                        },
                        label = "catIcon"
                    ) { id ->
                        if (id == null) {
                            NavGlyphIcon(
                                NavGlyph.CATEGORY, MaterialTheme.colorScheme.onSurface, 24.dp,
                                Modifier.graphicsLayer { val k = 1f + 0.20f * t; scaleX = k; scaleY = k; rotationZ = 90f * t },
                                colored = ThemeState.catIconStyle == 0
                            )
                        } else {
                            CategoryMiniIcon(
                                catOf(id), 26.dp, MaterialTheme.colorScheme.onSurface,
                                Modifier.graphicsLayer { val k = 1f + 0.08f * t; scaleX = k; scaleY = k }
                            )
                        }
                    }
                } else {
                    NavGlyphIcon(
                        item.glyph, MaterialTheme.colorScheme.onSurface, 24.dp,
                        colored = ThemeState.catIconStyle == 0,
                        modifier = Modifier.graphicsLayer {
                            val hop = with(density) { 4.dp.toPx() }
                            when (item.glyph) {
                                NavGlyph.HOME -> { translationY = -hop * t; val k = 1f + 0.10f * t; scaleX = k; scaleY = k }
                                NavGlyph.DISCOVER -> { rotationZ = 180f * t; val k = 1f + 0.08f * t; scaleX = k; scaleY = k }
                                NavGlyph.FAVORITE -> { val k = 1f + 0.28f * t; scaleX = k; scaleY = k }
                                NavGlyph.SETTINGS -> { rotationZ = 120f * t; val k = 1f + 0.08f * t; scaleX = k; scaleY = k }
                                else -> {}
                            }
                        }
                    )
                }
            }
        }
        Spacer(Modifier.height(3.dp))
        // 进入分类后，文字也变成当前分类名
        val label = if (item.glyph == NavGlyph.CATEGORY && activeCategory != null) catOf(activeCategory).name else item.title
        Crossfade(label, animationSpec = tween(220), label = "navLabel") { l ->
            Text(
                l, Modifier.padding(horizontal = 3.dp), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun NavGlyphIcon(g: NavGlyph, tint: Color, size: Dp, modifier: Modifier = Modifier, colored: Boolean = false) {
    if (g == NavGlyph.FAVORITE) { AppIcon(IconKind.HEART, if (colored) Color(0xFFEF4A6B) else tint, size, modifier); return }
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f
        when (g) {
            NavGlyph.HOME -> if (colored) home(Color(0xFFF59E3B), u, Color(0xFFE5484D)) else home(tint, u)
            NavGlyph.DISCOVER -> discover(if (colored) Color(0xFF3B82F6) else tint, u)
            NavGlyph.CATEGORY -> category(
                if (colored) listOf(Color(0xFF8B5CF6), Color(0xFF2DC76D), Color(0xFFF59E0B), Color(0xFFEC4899)) else listOf(tint, tint, tint, tint), u
            )
            NavGlyph.SETTINGS -> gear(u)
            else -> {}
        }
    }
}

private fun DrawScope.home(c: Color, u: Float, chimney: Color = c) {
    val body = Path().apply {
        moveTo(12f * u, 3f * u); lineTo(22.2f * u, 12.2f * u); lineTo(19.6f * u, 12.2f * u)
        lineTo(19.6f * u, 21f * u); lineTo(4.4f * u, 21f * u); lineTo(4.4f * u, 12.2f * u); lineTo(1.8f * u, 12.2f * u); close()
    }
    val door = Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(Rect(Offset(9.8f * u, 14.2f * u), Size(4.4f * u, 6.8f * u)), CornerRadius(1.2f * u))) }
    drawPath(Path.combine(PathOperation.Difference, body, door), c)
    drawRoundRect(chimney, Offset(16.2f * u, 4.2f * u), Size(2.4f * u, 4.6f * u), CornerRadius(0.8f * u))
}

private fun DrawScope.discover(c: Color, u: Float) {
    val disc = Path().apply { addOval(Rect(Offset(2.5f * u, 2.5f * u), Size(19f * u, 19f * u))) }
    val needle = Path().apply {
        moveTo(16.4f * u, 7.6f * u); lineTo(13.6f * u, 13.6f * u); lineTo(7.6f * u, 16.4f * u); lineTo(10.4f * u, 10.4f * u); close()
    }
    drawPath(Path.combine(PathOperation.Difference, disc, needle), c)
    drawCircle(c, 1.1f * u, Offset(12f * u, 12f * u))
}

private fun DrawScope.category(c: List<Color>, u: Float) {
    val r = CornerRadius(2.6f * u)
    drawRoundRect(c[0], Offset(3f * u, 3f * u), Size(8.2f * u, 8.2f * u), r)
    drawRoundRect(c[1], Offset(12.8f * u, 3f * u), Size(8.2f * u, 8.2f * u), r)
    drawRoundRect(c[2], Offset(3f * u, 12.8f * u), Size(8.2f * u, 8.2f * u), r)
    drawRoundRect(c[3], Offset(12.8f * u, 12.8f * u), Size(8.2f * u, 8.2f * u), r)
}

/** 设置：绿色齿轮 + 浅蓝环 + 深色圆心里的小机器人头，参考 Android 设置插画。 */
private fun DrawScope.gear(u: Float) {
    val green = Color(0xFF3DDC84)
    val ring = Color(0xFFD6ECFB)
    val dark = Color(0xFF08323F)
    val cx = 12f * u
    val cy = 12f * u
    val teeth = 8
    val p = Path()
    var first = true
    fun pt(a: Double, r: Float): Offset = Offset(cx + (r * u * cos(a)).toFloat(), cy + (r * u * sin(a)).toFloat())
    for (i in 0 until teeth) {
        val base = Math.toRadians(i * 360.0 / teeth - 90)
        val d = Math.toRadians(360.0 / teeth)
        listOf(base - d * 0.30 to 8.6f, base - d * 0.17 to 11.2f, base + d * 0.17 to 11.2f, base + d * 0.30 to 8.6f).forEach { (a, r) ->
            val o = pt(a, r)
            if (first) { p.moveTo(o.x, o.y); first = false } else p.lineTo(o.x, o.y)
        }
    }
    p.close()
    drawPath(p, green)
    drawCircle(ring, 6.9f * u, Offset(cx, cy))
    drawCircle(green, 5.9f * u, Offset(cx, cy))
    drawCircle(dark, 4.4f * u, Offset(cx, cy))
    // 机器人头
    val head = Path().apply { addArc(Rect(Offset(cx - 2.4f * u, cy - 1.7f * u), Size(4.8f * u, 4.8f * u)), 180f, 180f) }
    drawPath(head, green)
    drawLine(green, Offset(cx - 1.3f * u, cy - 1.1f * u), Offset(cx - 2.1f * u, cy - 2.4f * u), 0.55f * u, StrokeCap.Round)
    drawLine(green, Offset(cx + 1.3f * u, cy - 1.1f * u), Offset(cx + 2.1f * u, cy - 2.4f * u), 0.55f * u, StrokeCap.Round)
    drawCircle(dark, 0.4f * u, Offset(cx - 0.9f * u, cy + 0.0f * u))
    drawCircle(dark, 0.4f * u, Offset(cx + 0.9f * u, cy + 0.0f * u))
}

/** 当前页滑下去之后，导航图标形变成的「回到顶部」：主色圆底 + 上下轻跳的白色箭头。 */
@Composable
private fun BackToTopIcon() {
    val inf = androidx.compose.animation.core.rememberInfiniteTransition(label = "topBob")
    val dy by inf.animateFloat(
        0f, -2.2f,
        androidx.compose.animation.core.infiniteRepeatable(
            tween(620, easing = androidx.compose.animation.core.FastOutSlowInEasing),
            androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "bob"
    )
    val density = LocalDensity.current
    Box(
        Modifier.size(28.dp).clip(androidx.compose.foundation.shape.CircleShape).background(MaterialTheme.colorScheme.primary),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(16.dp).graphicsLayer { translationY = dy * density.density }) {
            val u = this.size.minDimension / 16f
            val p = Path().apply {
                moveTo(8f * u, 13f * u); lineTo(8f * u, 3.6f * u)
                moveTo(3.4f * u, 8f * u); lineTo(8f * u, 3.4f * u); lineTo(12.6f * u, 8f * u)
            }
            drawPath(p, Color.White, style = Stroke(2.2f * u, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
        }
    }
}

/** 把 [layer]（页面内容的录制）按位置对齐画在这里，并整体模糊，形成背后内容的磨砂效果（Android 12+ 才有模糊，低版本只有半透明）。 */
@Composable
private fun Modifier.glassBackdrop(layer: GraphicsLayer, origin: () -> Offset, blurPx: Float): Modifier {
    var myPos by remember { mutableStateOf(Offset.Zero) }
    return this
        .onGloballyPositioned { myPos = it.positionInRoot() }
        .graphicsLayer {
            if (blurPx > 0.5f) renderEffect = BlurEffect(blurPx, blurPx, TileMode.Clamp)
            clip = true
        }
        .drawBehind {
            val o = myPos - origin()
            translate(-o.x, -o.y) { drawLayer(layer) }
        }
}
