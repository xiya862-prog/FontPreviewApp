package com.oneuirepo.app.ui.cve

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oneuirepo.app.cve.CveEntity
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.ui.LocalNavInset
import com.oneuirepo.app.ui.ScrollTopEffect
import com.oneuirepo.app.ui.category.CategoryGlyph
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.common.SearchField
import com.oneuirepo.app.ui.common.clearFocusOnTap
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

private enum class Sev(val key: String, val label: String, val color: Color) {
    CRITICAL("CRITICAL", "严重", Color(0xFFB3261E)),
    HIGH("HIGH", "高危", Color(0xFFE5603A)),
    MEDIUM("MEDIUM", "中危", Color(0xFFE59A00)),
    LOW("LOW", "低危", Color(0xFF3FA66B)),
    UNKNOWN("UNKNOWN", "未知", Color(0xFF8A8F98))
}

private fun sevOf(s: String?): Sev = Sev.values().firstOrNull { it.key == s?.trim()?.uppercase() } ?: Sev.UNKNOWN

@Composable
fun CveScreen(db: AppDatabase) {
    var q by remember { mutableStateOf("") }
    var sev by remember { mutableStateOf<Sev?>(null) }
    val all by remember(q) { db.cveDao().search(q) }.collectAsState(initial = emptyList())
    val counts = remember(all) { all.groupingBy { sevOf(it.severity) }.eachCount() }
    val shown = remember(all, sev) { if (sev == null) all else all.filter { sevOf(it.severity) == sev } }
    val listState = rememberLazyListState()
    ScrollTopEffect(listState)

    LazyColumn(
        Modifier.fillMaxSize().clearFocusOnTap(),
        state = listState,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 16.dp + LocalNavInset.current),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { SearchField(q, { q = it }, "搜索 CVE 编号 / Samsung / One UI") }
        // 严重程度筛选
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SevChip("全部", MaterialTheme.colorScheme.primary, sev == null, all.size) { sev = null }
                Sev.values().filter { (counts[it] ?: 0) > 0 }.forEach { s ->
                    SevChip(s.label, s.color, sev == s, counts[s] ?: 0) { sev = if (sev == s) null else s }
                }
            }
        }
        item {
            Text(
                "共 ${shown.size} 条漏洞　点开卡片查看详情", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 4.dp)
            )
        }
        items(shown, key = { it.id }) { CveCard(it) }
        if (shown.isEmpty()) {
            item {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 36.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(Modifier.size(84.dp).clip(CircleShape).background(Sev.CRITICAL.color.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                        CategoryGlyph("CVE", Sev.CRITICAL.color, 40.dp)
                    }
                    Text(if (all.isEmpty() && q.isBlank()) "还没有 CVE 数据" else "没有符合条件的漏洞", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        if (all.isEmpty() && q.isBlank()) "到设置里点「立即同步 CVE」拉取" else "换个关键词或严重程度试试",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SevChip(label: String, color: Color, selected: Boolean, count: Int, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) color.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface, tween(200), label = "sevBg")
    Surface(
        onClick = onClick, shape = RoundedCornerShape(50), color = bg,
        border = if (selected) BorderStroke(1.5.dp, color) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
            Spacer(Modifier.width(6.dp))
            Text("$count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun CveCard(x: CveEntity) {
    val context = LocalContext.current
    val s = sevOf(x.severity)
    var open by remember(x.id) { mutableStateOf(false) }
    val rot by animateFloatAsState(if (open) 270f else 90f, tween(300), label = "cveChev")
    Card(
        Modifier.fillMaxWidth().animateContentSize(tween(300)),
        shape = cardShape(24.dp), border = cardBorder(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable { open = !open }.padding(14.dp),
                verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CvssRing(x.cvss, s.color)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(x.id, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                        AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onSurfaceVariant, 20.dp, Modifier.graphicsLayer { rotationZ = rot })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(Modifier.clip(RoundedCornerShape(50)).background(s.color.copy(alpha = 0.16f)).padding(horizontal = 9.dp, vertical = 2.dp)) {
                            Text(s.label, style = MaterialTheme.typography.labelMedium, color = s.color, fontWeight = FontWeight.Bold)
                        }
                        AppIcon(IconKind.CLOCK, MaterialTheme.colorScheme.onSurfaceVariant, 14.dp)
                        Text(x.publishedAt?.take(10) ?: "-", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        x.summary, style = MaterialTheme.typography.bodyMedium, lineHeight = 21.sp,
                        maxLines = if (open) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            AnimatedVisibility(
                open,
                enter = expandVertically(tween(300)) + fadeIn(tween(300)),
                exit = shrinkVertically(tween(240)) + fadeOut(tween(140))
            ) {
                Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                    if (x.affectedVersions.isNotBlank()) DetailLine("影响版本", x.affectedVersions)
                    if (x.fixedVersions.isNotBlank()) DetailLine("修复版本", x.fixedVersions)
                    DetailLine("CVSS 评分", x.cvss?.toString() ?: "暂无")
                    DetailLine("最后更新", x.modifiedAt?.take(10) ?: "-")
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(
                            onClick = {
                                val url = x.sourceUrl?.takeIf { it.isNotBlank() } ?: "https://nvd.nist.gov/vuln/detail/${x.id}"
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            },
                            Modifier.weight(1f)
                        ) { Text("查看详情") }
                        OutlinedButton(
                            onClick = {
                                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("cve", x.id))
                                Toast.makeText(context, "已复制 ${x.id}", Toast.LENGTH_SHORT).show()
                            },
                            Modifier.weight(1f)
                        ) { Text("复制编号") }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(k, Modifier.width(76.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, fontFamily = FontFamily.Default)
    }
}

/** 圆环 + 中间的 CVSS 分数，环的长度按分数 / 10，颜色按严重程度。 */
@Composable
private fun CvssRing(cvss: Double?, color: Color) {
    val frac by animateFloatAsState(((cvss ?: 0.0) / 10.0).toFloat().coerceIn(0f, 1f), tween(700), label = "cvss")
    Box(Modifier.size(54.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 5.dp.toPx()
            val tl = Offset(sw / 2, sw / 2)
            val sz = Size(this.size.width - sw, this.size.height - sw)
            drawArc(color.copy(alpha = 0.18f), 0f, 360f, false, tl, sz, style = Stroke(sw))
            drawArc(color, -90f, 360f * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
        }
        Text(
            cvss?.let { String.format("%.1f", it) } ?: "-",
            style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.ExtraBold, color = color
        )
    }
}
