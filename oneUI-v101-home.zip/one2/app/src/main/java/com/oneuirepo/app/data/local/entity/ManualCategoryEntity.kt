package com.oneuirepo.app.data.local.entity

import androidx.room.Entity

/** 用户手动放进内置分类的记录；重新自动分类时会被保留。 */
@Entity(tableName = "manual_category", primaryKeys = ["repositoryId", "categoryId"])
data class ManualCategoryEntity(val repositoryId: Long, val categoryId: String)
