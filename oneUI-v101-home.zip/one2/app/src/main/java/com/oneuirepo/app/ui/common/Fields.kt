package com.oneuirepo.app.ui.common

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** 胶囊搜索框：聚焦时描边变主色并抬起阴影，有内容时右侧出现清除按钮。 */
@Composable
fun SearchField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    leading: IconKind = IconKind.SEARCH,
    imeAction: ImeAction = ImeAction.Search,
    onSubmit: (() -> Unit)? = null,
    keyboardType: androidx.compose.ui.text.input.KeyboardType = androidx.compose.ui.text.input.KeyboardType.Text
) {
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val primary = MaterialTheme.colorScheme.primary
    val border by animateColorAsState(if (focused) primary else MaterialTheme.colorScheme.outlineVariant, tween(220), label = "sfBorder")
    val iconTint by animateColorAsState(if (focused) primary else MaterialTheme.colorScheme.onSurfaceVariant, tween(220), label = "sfIcon")
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(if (focused) 2.dp else 1.dp, border),
        shadowElevation = if (focused) 6.dp else 0.dp
    ) {
        Row(Modifier.padding(start = 16.dp, end = 10.dp).heightIn(min = 54.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(leading, iconTint, 20.dp)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    Text(placeholder, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f), maxLines = 1)
                }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = SolidColor(primary),
                    interactionSource = interaction,
                    keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
                    keyboardActions = KeyboardActions(
                        onSearch = { onSubmit?.invoke() }, onDone = { onSubmit?.invoke() }, onGo = { onSubmit?.invoke() }
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            AnimatedVisibility(value.isNotEmpty(), enter = fadeIn(tween(150)) + scaleIn(tween(150)), exit = fadeOut(tween(120)) + scaleOut(tween(120))) {
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).clickable { onValueChange("") },
                    contentAlignment = Alignment.Center
                ) { AppIcon(IconKind.CLOSE, MaterialTheme.colorScheme.onSurfaceVariant, 14.dp) }
            }
        }
    }
}

/** 排序 / 筛选胶囊：选中时填充主色渐变感，未选中是描边；带矢量小图标，不用 emoji。 */
@Composable
fun FilterPill(label: String, icon: IconKind, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface, tween(220), label = "pillBg")
    val fg by animateColorAsState(if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, tween(220), label = "pillFg")
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(50),
        color = bg,
        border = if (selected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(icon, fg, 16.dp)
            Spacer(Modifier.width(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

/** 彩色标题栏上的圆形磨砂按钮（返回等）。 */
@Composable
fun FrostedIconButton(icon: IconKind, onClick: () -> Unit, size: Dp = 42.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { AppIcon(icon, Color.White, 20.dp) }
}

/** 彩色标题栏上的胶囊磨砂按钮（图标 + 文字）。 */
@Composable
fun FrostedPill(icon: IconKind, label: String, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.22f)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(icon, Color.White, 16.dp)
        Spacer(Modifier.width(6.dp))
        Text(label, style = MaterialTheme.typography.labelLarge, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

/** 白底圆形图标按钮（返回 / 更多），带细描边和轻阴影，替代文字箭头。 */
@Composable
fun RoundIconButton(icon: IconKind, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color? = null, size: Dp = 44.dp) {
    Surface(
        onClick = onClick,
        modifier = modifier.size(size),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 3.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Box(contentAlignment = Alignment.Center) { AppIcon(icon, tint ?: MaterialTheme.colorScheme.onSurface, 20.dp) }
    }
}

/** 圆圈里显示数字（和「＋ 新建」同一种 tonal 配色），数字变化时上下滚动。 */
@Composable
fun CountBubble(count: Int, modifier: Modifier = Modifier) {
    Box(
        modifier.size(40.dp).clip(CircleShape).background(MaterialTheme.colorScheme.secondaryContainer),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.animation.AnimatedContent(
            targetState = count,
            transitionSpec = {
                (androidx.compose.animation.slideInVertically(tween(260)) { it } + fadeIn(tween(260))) togetherWith
                    (androidx.compose.animation.slideOutVertically(tween(260)) { -it } + fadeOut(tween(160)))
            },
            label = "countBubble"
        ) { n ->
            Text(
                "$n", fontWeight = FontWeight.Bold,
                style = if (n > 99) MaterialTheme.typography.labelLarge else MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            )
        }
    }
}

/** 点击空白处收起键盘并取消输入框焦点（子元素自己的点击不受影响）。 */
@OptIn(androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
fun Modifier.clearFocusOnTap(): Modifier {
    val focus = androidx.compose.ui.platform.LocalFocusManager.current
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    return this.pointerInput(Unit) {
        detectTapGestures { focus.clearFocus(); keyboard?.hide() }
    }
}

data class SegItem(val icon: IconKind, val label: String)

/** 分段选择：一整条圆角底，选中的主色胶囊带弹性滑动到新位置。 */
@Composable
fun SegmentedControl(items: List<SegItem>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    BoxWithConstraints(
        modifier.fillMaxWidth().clip(RoundedCornerShape(50))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)).padding(4.dp)
    ) {
        val w = maxWidth / items.size
        val x by androidx.compose.animation.core.animateDpAsState(
            w * selected,
            androidx.compose.animation.core.spring(dampingRatio = 0.72f, stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow),
            label = "segPill"
        )
        Box(Modifier.offset(x = x).width(w).height(40.dp).clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primary))
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, item ->
                val fg by animateColorAsState(
                    if (i == selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, tween(200), label = "segFg"
                )
                Row(
                    Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(50))
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(i) },
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(item.icon, fg, 16.dp)
                    Spacer(Modifier.width(6.dp))
                    Text(item.label, style = MaterialTheme.typography.labelLarge, color = fg, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}
