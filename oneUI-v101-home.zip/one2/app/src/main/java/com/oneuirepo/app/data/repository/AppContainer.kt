package com.oneuirepo.app.data.repository

import android.content.Context
import androidx.room.Room
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.MIGRATION_1_2
import com.oneuirepo.app.data.local.MIGRATION_2_3
import com.oneuirepo.app.data.local.MIGRATION_3_4
import com.oneuirepo.app.data.local.MIGRATION_4_5
import com.oneuirepo.app.data.local.MIGRATION_5_6
import com.oneuirepo.app.data.local.MIGRATION_6_7
import com.oneuirepo.app.data.remote.GitHubClient
import com.oneuirepo.app.domain.classifier.ClassificationEngine

class AppContainer(c:Context){
    init{ com.oneuirepo.app.auth.AuthState.init(c.applicationContext) }
    val db=Room.databaseBuilder(c,AppDatabase::class.java,"oneui_repository.db").addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7).build()
    val repository=GitHubRepository(GitHubClient.api,db,ClassificationEngine())
    val starSync=StarSync(c.applicationContext,repository,db,GitHubClient.api)
}
