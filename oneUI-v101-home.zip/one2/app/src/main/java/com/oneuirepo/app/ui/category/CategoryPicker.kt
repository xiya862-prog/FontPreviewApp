package com.oneuirepo.app.ui.category

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.data.local.entity.CategoryEntity
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind

/**
 * 手动把项目放进分类卡片：底部弹出面板，点选分类图块即可多选，选中图块带勾和描边。
 * [current] 是项目当前所在的全部分类 id。分类完全由用户手动选择。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoryPickerDialog(
    current: List<String>,
    custom: List<CategoryEntity>,
    onToggle: (id: String, on: Boolean) -> Unit,
    onNew: () -> Unit,
    onDismiss: () -> Unit
) {
    val all = categories + custom.map { c ->
        Cat(c.name, categories[(c.id.hashCode() and 0x7fffffff) % categories.size].color, c.id)
    }
    val selectedCount = all.count { it.id in current }
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("添加到分类", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("点选要放入的分类卡片，可多选", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 12.dp, vertical = 5.dp)) {
                    Text("已选 $selectedCount", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxWidth().heightIn(max = 500.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(all, key = { it.id }) { cat ->
                    val on = cat.id in current
                    CategoryTile(cat, on) { onToggle(cat.id, !on) }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).navigationBarsPadding(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(onClick = onNew, Modifier.weight(1f).height(48.dp)) { Text("＋ 新建分类") }
                Button(onClick = onDismiss, Modifier.weight(1f).height(48.dp)) { Text("完成", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun CategoryTile(cat: Cat, selected: Boolean, onClick: () -> Unit) {
    val img = categoryImage(cat.name)
    val shape = RoundedCornerShape(20.dp)
    val scale by animateFloatAsState(if (selected) 1f else 0.95f, label = "tile")
    val ring = MaterialTheme.colorScheme.primary
    Box(
        Modifier.aspectRatio(1f)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .clickable(onClick = onClick)
            .border(if (selected) 3.dp else 0.dp, if (selected) ring else Color.Transparent, shape)
    ) {
        Box(Modifier.fillMaxSize().alpha(if (selected) 1f else 0.72f)) {
            if (img != null) {
                Image(painterResource(img), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(cat.color, cat.color.deep(0.8f)))))
                CategoryArt(cat.name, cat.color.deep(), Modifier.align(Alignment.TopCenter).padding(top = 6.dp), size = 62.dp)
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.55f))
                )
            )
            Text(
                cat.name, Modifier.align(Alignment.BottomStart).padding(horizontal = 9.dp, vertical = 7.dp),
                style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
                color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        if (selected) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(7.dp).size(24.dp).clip(CircleShape).background(ring),
                contentAlignment = Alignment.Center
            ) { AppIcon(IconKind.CHECK, MaterialTheme.colorScheme.onPrimary, 15.dp) }
        }
    }
}
