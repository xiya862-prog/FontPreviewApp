package com.oneuirepo.app.ui.category

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.CategoryTagEntity
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import com.oneuirepo.app.download.AppDownloadManager
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.common.Pill
import com.oneuirepo.app.ui.detail.archOf
import com.oneuirepo.app.ui.detail.bestAsset
import com.oneuirepo.app.ui.detail.fmtSize
import com.oneuirepo.app.ui.detail.isPre
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

/**
 * 分类详情里的项目卡片：点击整张卡片展开 / 收起（箭头旋转 + 平滑展开），
 * 展开后有「版本选择 + 下载」、「标签」和「查看详情」。
 */
@Composable
internal fun ExpandableRepoCard(
    r: RepositoryEntity,
    db: AppDatabase,
    tags: List<CategoryTagEntity>,
    tagIds: Set<Long>,
    onToggleTag: (tagId: Long, on: Boolean) -> Unit,
    onNewTag: () -> Unit,
    onOpen: () -> Unit
) {
    var expanded by rememberSaveable(r.id) { mutableStateOf(false) }
    val rot by animateFloatAsState(if (expanded) 270f else 90f, tween(320), label = "chev")
    Card(
        Modifier.fillMaxWidth(),
        shape = cardShape(26.dp), border = cardBorder(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Row(
                Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    if (r.avatarUrl != null) AsyncImage(r.avatarUrl, null, Modifier.fillMaxSize())
                    else Text(r.name.take(1).uppercase(), style = MaterialTheme.typography.titleMedium)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(r.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(r.owner, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    if (!r.description.isNullOrBlank()) {
                        Text(
                            r.description, style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                    }
                    Row(Modifier.padding(top = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Pill("★ ${r.stars}"); Pill("分叉 ${r.forks}")
                        if (!r.language.isNullOrBlank()) Pill(r.language)
                    }
                }
                AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onSurfaceVariant, 22.dp, Modifier.graphicsLayer { rotationZ = rot })
            }
            AnimatedVisibility(
                expanded,
                enter = expandVertically(tween(320)) + fadeIn(tween(320)),
                exit = shrinkVertically(tween(260)) + fadeOut(tween(160))
            ) {
                ExpandedPanel(r, db, tags, tagIds, onToggleTag, onNewTag, onOpen)
            }
        }
    }
}

@Composable
private fun ExpandedPanel(
    r: RepositoryEntity, db: AppDatabase, tags: List<CategoryTagEntity>, tagIds: Set<Long>,
    onToggleTag: (Long, Boolean) -> Unit, onNewTag: () -> Unit, onOpen: () -> Unit
) {
    val context = LocalContext.current
    val downloader = remember { AppDownloadManager(context) }
    val releases by remember(r.id) { db.releaseDao().observeReleases(r.id) }.collectAsState(initial = emptyList())
    val assets by remember(r.id) { db.releaseDao().observeAssets(r.id) }.collectAsState(initial = emptyList())
    val stable = releases.filter { !isPre(it) }
    val list = if (stable.isNotEmpty()) stable else releases
    var relId by remember { mutableStateOf<Long?>(null) }
    val rel = list.firstOrNull { it.id == relId } ?: list.firstOrNull()
    val relAssets = if (rel == null) emptyList() else assets.filter { it.releaseId == rel.id }
    val asset = bestAsset(relAssets)
    var menu by remember { mutableStateOf(false) }

    Column(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)

        // ---- 版本选择 + 下载
        if (rel == null || asset == null) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    if (releases.isEmpty()) "该项目暂无 Release 安装包" else "这个版本没有可下载的文件",
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                FilledTonalButton(onClick = {
                    downloader.enqueue("https://github.com/${r.owner}/${r.name}/archive/HEAD.zip", "${r.name}-source.zip")
                    Toast.makeText(context, "已开始下载源码", Toast.LENGTH_SHORT).show()
                }) { Text("下载源码") }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(
                    onClick = { menu = true }, shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(Modifier.padding(start = 14.dp, end = 8.dp).height(44.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(rel.tagName, Modifier.widthIn(max = 96.dp), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.width(6.dp))
                        Box(Modifier.size(24.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                            AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onPrimaryContainer, 14.dp, Modifier.graphicsLayer { rotationZ = 90f })
                        }
                    }
                }
                if (menu) {
                    com.oneuirepo.app.ui.common.PickerSheet(
                        title = "选择版本",
                        options = list.take(30).mapIndexed { i, x ->
                            com.oneuirepo.app.ui.common.PickerOption(
                                x.id, x.tagName,
                                subtitle = listOfNotNull(x.publishedAt?.take(10), x.name?.takeIf { n -> n.isNotBlank() && n != x.tagName }).joinToString(" · ").ifEmpty { null },
                                badges = listOfNotNull(if (i == 0) "最新" else null, if (isPre(x)) "预发布" else null)
                            )
                        },
                        selectedKey = rel.id,
                        onSelect = { relId = it; menu = false },
                        onDismiss = { menu = false }
                    )
                }
                Button(
                    onClick = {
                        downloader.enqueue(asset.downloadUrl, asset.name)
                        Toast.makeText(context, "已开始下载，完成后在通知栏点击安装", Toast.LENGTH_SHORT).show()
                    },
                    Modifier.weight(1f).height(44.dp), shape = RoundedCornerShape(50)
                ) {
                    AppIcon(IconKind.DOWNLOAD, MaterialTheme.colorScheme.onPrimary, 18.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("下载 · ${archOf(asset)} · ${fmtSize(asset.size)}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Text(asset.name, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }

        // ---- 标签
        Text("放入标签", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tags.forEach { t ->
                TagChip(t.name, selected = t.id in tagIds) { onToggleTag(t.id, t.id !in tagIds) }
            }
            AddChip("新建标签", onNewTag)
        }

        OutlinedButton(onClick = onOpen, Modifier.fillMaxWidth()) { Text("查看项目详情") }
    }
}

@Composable
internal fun TagChip(label: String, selected: Boolean, count: Int? = null, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface, tween(200), label = "tagBg")
    Surface(
        onClick = onClick, shape = RoundedCornerShape(50), color = bg,
        border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            if (selected) {
                AppIcon(IconKind.CHECK, MaterialTheme.colorScheme.primary, 14.dp)
                Spacer(Modifier.width(4.dp))
            }
            Text(
                label, style = MaterialTheme.typography.labelLarge, maxLines = 1,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
            )
            if (count != null) {
                Spacer(Modifier.width(6.dp))
                Text("$count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
internal fun AddChip(label: String, onClick: () -> Unit) {
    Surface(
        onClick = onClick, shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f))
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            AppIcon(IconKind.PLUS, MaterialTheme.colorScheme.primary, 14.dp)
            Spacer(Modifier.width(4.dp))
            Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}
