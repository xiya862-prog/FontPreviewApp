package com.oneuirepo.app.ui.settings

import androidx.compose.foundation.border
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oneuirepo.app.auth.AuthState
import com.oneuirepo.app.cve.CveScheduler
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.settings.AppSettings
import com.oneuirepo.app.settings.DataManager
import com.oneuirepo.app.sync.SyncScheduler
import com.oneuirepo.app.ui.theme.ThemeState
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(container: AppContainer, onOpenProfile: () -> Unit = {}) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    // 直接读取已安装 APK 的版本，不再写死
    val versionText = remember {
        runCatching {
            val pi = context.packageManager.getPackageInfo(context.packageName, 0)
            "${pi.versionName}（${androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(pi)}）"
        }.getOrDefault("未知")
    }
    val scope = rememberCoroutineScope()
    val account: GitHubAccountViewModel = viewModel(factory = GitHubAccountVMFactory(context))
    val profile by account.profile.collectAsState()
    var auto by remember { mutableStateOf(settings.autoSync) }
    // 刚登录（或打开设置时已登录）且自动同步开着：同步一次星标
    LaunchedEffect(profile?.login) {
        if (profile != null && settings.autoSync) {
            val n = container.starSync.run()
            if (n > 0) android.widget.Toast.makeText(context, "已把 $n 个 GitHub 星标同步到收藏", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    var notify by remember { mutableStateOf(settings.notifications) }
    var images by remember { mutableStateOf(settings.imageLoading) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 20.dp + com.oneuirepo.app.ui.LocalNavInset.current),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("设置", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))

        GroupTitle("账号")
        GitHubAccountCard(account, onOpenProfile)

        GroupTitle("同步与通知")
        GroupCard {
            SettingSwitch("自动同步", "后台定期检查项目；登录 GitHub 后，账号里的星标会自动同步到「收藏」", auto) {
                auto = it; settings.autoSync = it
                if (it) {
                    SyncScheduler.schedule(context)
                    scope.launch {
                        val n = container.starSync.run()
                        if (n > 0) android.widget.Toast.makeText(context, "已把 $n 个 GitHub 星标同步到收藏", android.widget.Toast.LENGTH_SHORT).show()
                    }
                } else SyncScheduler.cancel(context)
            }
            RowDivider()
            SettingSwitch("通知", "新 Release 通知", notify) { notify = it; settings.notifications = it }
            RowDivider()
            SettingSwitch("图片加载", "加载 GitHub 头像和项目图片", images) { images = it; settings.imageLoading = it }
            RowDivider()
            SettingAction("立即同步项目", "手动检查所有项目的更新") { SyncScheduler.runNow(context) }
            RowDivider()
            SettingAction("立即同步 CVE", "刷新漏洞列表") { CveScheduler.runNow(context) }
        }

        GroupTitle("外观")
        GroupCard {
            SettingSwitch("Manga 漫画风", "粗描边、纸张质感的漫画面板风格", ThemeState.manga) { ThemeState.setManga(context, it) }
            RowDivider()
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("跟随系统", "日间", "夜间", "Nord").forEachIndexed { i, t ->
                    FilterChip(selected = ThemeState.mode == i, onClick = { ThemeState.setMode(context, i) }, label = { Text(t) })
                }
            }
            RowDivider()
            IconStylePicker()
            RowDivider()
            NavGlassSlider()
            RowDivider()
            LandscapeNavPicker()
            RowDivider()
            CardStylePicker()
        }

        GroupTitle("数据")
        GroupCard {
            SettingAction("导出数据", "把项目、分类和收藏导出为 JSON") { scope.launch { DataManager.share(context, DataManager.exportJson(container.db)) } }
        }

        GroupTitle("关于")
        AboutSection(
            versionText,
            if (profile != null || AuthState.token != null) "已登录，使用账号额度（5000 次/小时）" else "匿名访问（60 次/小时），登录后可提升"
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun GroupTitle(text: String) {
    Text(
        text, Modifier.padding(start = 6.dp, top = 10.dp),
        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold
    )
}

@Composable
private fun GroupCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = cardShape(22.dp), border = cardBorder(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) { Column(content = content) }
}

@Composable
private fun RowDivider() = HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)

@Composable
private fun SettingSwitch(title: String, desc: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(value, onChange)
    }
}

@Composable
private fun SettingAction(title: String, desc: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun IconStylePicker() {
    val context = LocalContext.current
    val samples = remember { listOf("模块", "KernelSU", "Watch").map { com.oneuirepo.app.ui.category.catOf(it) } }
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        MorphIntro()
        Column {
            Text("图标风格", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("彩色模式下首页、发现、分类、收藏会带色，设置齿轮保持不变", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("黑色轮廓" to 1, "彩色徽标" to 0).forEach { (label, v) ->
                val sel = ThemeState.catIconStyle == v
                Surface(
                    onClick = { ThemeState.setCatIconStyle(context, v) },
                    modifier = Modifier.weight(1f),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(if (sel) 2.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(Modifier.padding(vertical = 14.dp, horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            samples.forEach { c ->
                                if (v == 1) com.oneuirepo.app.ui.category.CategoryGlyph(c.name, MaterialTheme.colorScheme.onSurface, 28.dp)
                                else com.oneuirepo.app.ui.category.CategoryNavBadge(c, 28.dp)
                            }
                        }
                        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium)
                    }
                }
            }
        }
    }
}

/** 「形变交互式底部导航栏」介绍：标题 + 循环形变的演示图标 + 介绍文字 + 三个特性标签。 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun MorphIntro() {
    var step by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) { kotlinx.coroutines.delay(1700); step = (step + 1) % 4 }
    }
    val primary = MaterialTheme.colorScheme.primary
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxWidth()
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(22.dp))
            .background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(primary.copy(alpha = 0.16f), MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f))))
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // 演示：首页 → 分类徽标 → 回到顶部 → 收藏，循环形变
                androidx.compose.foundation.layout.Box(
                    Modifier.size(54.dp).clip(androidx.compose.foundation.shape.CircleShape).background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.animation.AnimatedContent(
                        targetState = step,
                        transitionSpec = {
                            (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(180)) +
                                androidx.compose.animation.scaleIn(
                                    androidx.compose.animation.core.spring(dampingRatio = 0.45f, stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow),
                                    initialScale = 0.3f
                                )) togetherWith
                                (androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)) +
                                    androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(140), targetScale = 0.3f))
                        },
                        label = "morphDemo"
                    ) { s ->
                        when (s) {
                            0 -> com.oneuirepo.app.ui.NavGlyphIcon(com.oneuirepo.app.ui.NavGlyph.HOME, MaterialTheme.colorScheme.onSurface, 28.dp, colored = ThemeState.catIconStyle == 0)
                            1 -> com.oneuirepo.app.ui.category.CategoryMiniIcon(com.oneuirepo.app.ui.category.catOf("模块"), 30.dp, MaterialTheme.colorScheme.onSurface)
                            2 -> androidx.compose.foundation.layout.Box(
                                Modifier.size(30.dp).clip(androidx.compose.foundation.shape.CircleShape).background(primary),
                                contentAlignment = Alignment.Center
                            ) { com.oneuirepo.app.ui.common.AppIcon(com.oneuirepo.app.ui.common.IconKind.CHEVRON, androidx.compose.ui.graphics.Color.White, 18.dp, Modifier.graphicsLayer { rotationZ = 270f }) }
                            else -> com.oneuirepo.app.ui.NavGlyphIcon(com.oneuirepo.app.ui.NavGlyph.FAVORITE, MaterialTheme.colorScheme.onSurface, 28.dp, colored = ThemeState.catIconStyle == 0)
                        }
                    }
                }
                Column(Modifier.padding(start = 14.dp)) {
                    Text("形变交互式底部导航栏", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    Text("MorphInteractiveBottomNavBar", style = MaterialTheme.typography.labelSmall, color = primary, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                }
            }
            Text(
                "形变交互式底部导航栏（MorphInteractiveBottomNavBar），原生基础导航组件之上自研交互组件，打破传统底部导航静态图标的固化模式，万物皆可形变。",
                style = MaterialTheme.typography.bodySmall, lineHeight = 20.sp
            )
            Text(
                "导航图标不再只是简单的选中切换，而是跟随页面路由、页面状态、用户操作动态产生平滑形态流转。页面切换图标变形、路由返回元素流转、隐藏交互彩蛋联动，让导航栏不再只是单纯的页面跳转工具，成为贯穿整个应用交互叙事的动态载体。",
                style = MaterialTheme.typography.bodySmall, lineHeight = 20.sp
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("页面切换图标变形", "路由返回元素流转", "隐藏交互彩蛋联动").forEach { t ->
                    androidx.compose.foundation.layout.Box(
                        Modifier.clip(androidx.compose.foundation.shape.RoundedCornerShape(50)).background(primary.copy(alpha = 0.16f)).padding(horizontal = 12.dp, vertical = 6.dp)
                    ) { Text(t, style = MaterialTheme.typography.labelMedium, color = primary, fontWeight = FontWeight.Bold) }
                }
            }
            Text(
                "整套联动交互为原创设计，将动画逻辑与页面状态深度融合。",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/** 导航栏磨砂背景：拖动调节透明度（0% 不透明白底 → 100% 最通透 + 最强模糊），拖动时底栏实时变化。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NavGlassSlider() {
    val context = LocalContext.current
    var v by remember { mutableStateOf(ThemeState.navGlass) }
    val primary = MaterialTheme.colorScheme.primary
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("导航栏磨砂背景", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text("拖动调节背景透明度，越往右越通透，并带背景模糊（Android 12 及以上）", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("${(v * 100).toInt()}%", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = primary)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            TransparencyIcon(28.dp)
            Slider(
                value = v,
                onValueChange = { v = it; ThemeState.navGlass = it },
                onValueChangeFinished = { ThemeState.setNavGlass(context, v) },
                valueRange = 0f..1f,
                modifier = Modifier.weight(1f),
                thumb = {
                    androidx.compose.foundation.layout.Box(
                        Modifier.size(24.dp).clip(androidx.compose.foundation.shape.CircleShape)
                            .background(androidx.compose.ui.graphics.Color.White)
                            .border(3.dp, primary, androidx.compose.foundation.shape.CircleShape)
                    )
                },
                colors = SliderDefaults.colors(activeTrackColor = primary, inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant)
            )
        }
    }
}

/** 灰白棋盘格圆圈：「透明度」的通用图标。 */
@Composable
private fun TransparencyIcon(size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.layout.Box(
        Modifier.size(size).clip(androidx.compose.foundation.shape.CircleShape)
            .background(androidx.compose.ui.graphics.Color.White)
            .border(1.5.dp, androidx.compose.ui.graphics.Color(0xFF9A9A9A), androidx.compose.foundation.shape.CircleShape)
    ) {
        androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
            val n = 4
            val cs = this.size.width / n
            for (i in 0 until n) for (j in 0 until n) {
                if ((i + j) % 2 == 0) drawRect(androidx.compose.ui.graphics.Color(0xFF9E9E9E), androidx.compose.ui.geometry.Offset(i * cs, j * cs), androidx.compose.ui.geometry.Size(cs, cs))
            }
        }
    }
}

/** 分类卡片风格：渐变插画 / 简约白卡 / 列表行，每项带一个小示意图。 */
@Composable
private fun CardStylePicker() {
    val context = LocalContext.current
    val primary = MaterialTheme.colorScheme.primary
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column {
            Text("分类卡片风格", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("切换分类页里卡片的外观", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("渐变插画" to 0, "简约白卡" to 1, "列表行" to 2).forEach { (label, v) ->
                val sel = ThemeState.catCardStyle == v
                Surface(
                    onClick = { ThemeState.setCatCardStyle(context, v) },
                    modifier = Modifier.weight(1f),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(if (sel) 2.dp else 1.dp, if (sel) primary else MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(Modifier.padding(vertical = 12.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        CardStyleSketch(v)
                        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun CardStyleSketch(style: Int) {
    val gray = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp)
    when (style) {
        0 -> Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf(androidx.compose.ui.graphics.Color(0xFF5B8DEF) to androidx.compose.ui.graphics.Color(0xFF3E56A8), androidx.compose.ui.graphics.Color(0xFFD9737F) to androidx.compose.ui.graphics.Color(0xFF8A4551)).forEach { (a, b) ->
                androidx.compose.foundation.layout.Box(
                    Modifier.size(width = 30.dp, height = 40.dp).clip(shape).background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(a, b)))
                ) {
                    androidx.compose.foundation.layout.Box(Modifier.align(Alignment.TopEnd).padding(4.dp).size(12.dp).clip(androidx.compose.foundation.shape.CircleShape).background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.8f)))
                }
            }
        }
        1 -> Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            repeat(2) { i ->
                androidx.compose.foundation.layout.Box(
                    Modifier.size(width = 30.dp, height = 40.dp).clip(shape).background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape).padding(4.dp)
                ) {
                    androidx.compose.foundation.layout.Box(Modifier.size(11.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(4.dp)).background(if (i == 0) androidx.compose.ui.graphics.Color(0xFF67A842) else androidx.compose.ui.graphics.Color(0xFF4FA3D1)))
                    androidx.compose.foundation.layout.Box(Modifier.align(Alignment.BottomStart).width(16.dp).height(3.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(2.dp)).background(gray))
                }
            }
        }
        else -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            repeat(3) { i ->
                Row(
                    Modifier.size(width = 65.dp, height = 11.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(5.dp)).background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, androidx.compose.foundation.shape.RoundedCornerShape(5.dp)).padding(horizontal = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    androidx.compose.foundation.layout.Box(Modifier.size(6.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(2.dp)).background(listOf(androidx.compose.ui.graphics.Color(0xFF8E6BBF), androidx.compose.ui.graphics.Color(0xFFE08B5A), androidx.compose.ui.graphics.Color(0xFF3FA77A))[i]))
                    androidx.compose.foundation.layout.Box(Modifier.padding(start = 4.dp).width(24.dp).height(2.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(1.dp)).background(gray))
                }
            }
        }
    }
}

/** 横屏 / 外屏时导航条的位置：靠左竖排、靠右竖排、保持在底部。 */
@Composable
private fun LandscapeNavPicker() {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column {
            Text("横屏导航条", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            Text("手机横过来、或折叠屏外屏旋转时，导航条自动转成竖排贴在屏幕边上", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("靠左竖排" to 0, "靠右竖排" to 1, "保持底部" to 2).forEach { (label, v) ->
                val sel = ThemeState.landscapeNav == v
                Surface(
                    onClick = { ThemeState.setLandscapeNav(context, v) },
                    modifier = Modifier.weight(1f),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    color = if (sel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(if (sel) 2.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Column(Modifier.padding(vertical = 12.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        // 小示意图：横屏屏幕 + 导航条的位置
                        androidx.compose.foundation.layout.Box(
                            Modifier.size(width = 56.dp, height = 34.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            val bar = Modifier.background(MaterialTheme.colorScheme.primary, androidx.compose.foundation.shape.RoundedCornerShape(50))
                            when (v) {
                                0 -> androidx.compose.foundation.layout.Box(Modifier.align(Alignment.CenterStart).padding(start = 4.dp).size(width = 7.dp, height = 24.dp).then(bar))
                                1 -> androidx.compose.foundation.layout.Box(Modifier.align(Alignment.CenterEnd).padding(end = 4.dp).size(width = 7.dp, height = 24.dp).then(bar))
                                else -> androidx.compose.foundation.layout.Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp).size(width = 36.dp, height = 7.dp).then(bar))
                            }
                        }
                        Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                    }
                }
            }
        }
    }
}
