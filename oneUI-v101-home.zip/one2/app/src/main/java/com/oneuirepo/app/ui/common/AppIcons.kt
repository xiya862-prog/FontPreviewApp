package com.oneuirepo.app.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class IconKind { STAR, HEART, CLOCK, SEARCH, CHEVRON, BACK, FORK, CHECK, GRID, DOWNLOAD, TAG, USER, SHIELD, CLOSE, TRASH, SPARK, LINK, PLUS, MORE, STAR_O,
    GITHUB, BELL, FILTER, CUBE, SERVER, CLOUD, STORE, PLUS_CIRCLE, WRENCH, LAYERS, PALETTE, SHIZUSTORE }

/** 纯矢量绘制的小图标，不依赖 emoji / 字体，所有机型显示一致。 */
@Composable
fun AppIcon(kind: IconKind, tint: Color, size: Dp = 20.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f
        val stroke = Stroke(2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            IconKind.STAR -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 11f else 4.7f
                    val a = -PI / 2 + i * PI / 5
                    val x = (12 + r * cos(a)).toFloat() * u
                    val y = (12.8 + r * sin(a)).toFloat() * u
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, tint)
            }
            IconKind.STAR_O -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 10f else 4.6f
                    val a = -PI / 2 + i * PI / 5
                    val x = (12 + r * cos(a)).toFloat() * u
                    val y = (12.8 + r * sin(a)).toFloat() * u
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, tint, style = stroke)
            }
            IconKind.HEART -> {
                val p = Path().apply {
                    moveTo(12f * u, 21f * u)
                    cubicTo(2f * u, 14f * u, 1.5f * u, 8f * u, 5f * u, 5f * u)
                    cubicTo(8f * u, 2.8f * u, 11f * u, 4.5f * u, 12f * u, 7f * u)
                    cubicTo(13f * u, 4.5f * u, 16f * u, 2.8f * u, 19f * u, 5f * u)
                    cubicTo(22.5f * u, 8f * u, 22f * u, 14f * u, 12f * u, 21f * u)
                    close()
                }
                drawPath(p, tint)
            }
            IconKind.CLOCK -> {
                drawCircle(tint, 9.5f * u, Offset(12f * u, 12f * u), style = stroke)
                drawLine(tint, Offset(12f * u, 6.5f * u), Offset(12f * u, 12f * u), 2f * u, StrokeCap.Round)
                drawLine(tint, Offset(12f * u, 12f * u), Offset(16f * u, 14.5f * u), 2f * u, StrokeCap.Round)
            }
            IconKind.SEARCH -> {
                drawCircle(tint, 7f * u, Offset(10.5f * u, 10.5f * u), style = stroke)
                drawLine(tint, Offset(15.8f * u, 15.8f * u), Offset(21f * u, 21f * u), 2.2f * u, StrokeCap.Round)
            }
            IconKind.CHEVRON -> {
                val p = Path().apply { moveTo(9f * u, 5f * u); lineTo(16f * u, 12f * u); lineTo(9f * u, 19f * u) }
                drawPath(p, tint, style = stroke)
            }
            IconKind.BACK -> {
                val p = Path().apply { moveTo(15f * u, 5f * u); lineTo(8f * u, 12f * u); lineTo(15f * u, 19f * u) }
                drawPath(p, tint, style = stroke)
            }
            IconKind.CHECK -> {
                val p = Path().apply { moveTo(5f * u, 12.5f * u); lineTo(10f * u, 17.5f * u); lineTo(19f * u, 7f * u) }
                drawPath(p, tint, style = Stroke(2.8f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
            IconKind.GRID -> {
                val r = androidx.compose.ui.geometry.CornerRadius(2.2f * u)
                drawRoundRect(tint, Offset(3f * u, 3f * u), Size(7.5f * u, 7.5f * u), r)
                drawRoundRect(tint, Offset(13.5f * u, 3f * u), Size(7.5f * u, 7.5f * u), r)
                drawRoundRect(tint, Offset(3f * u, 13.5f * u), Size(7.5f * u, 7.5f * u), r)
                drawRoundRect(tint, Offset(13.5f * u, 13.5f * u), Size(7.5f * u, 7.5f * u), r)
            }
            IconKind.DOWNLOAD -> {
                val p = Path().apply {
                    moveTo(12f * u, 3.5f * u); lineTo(12f * u, 14.5f * u)
                    moveTo(7.5f * u, 10.5f * u); lineTo(12f * u, 15f * u); lineTo(16.5f * u, 10.5f * u)
                    moveTo(4.5f * u, 19.5f * u); lineTo(19.5f * u, 19.5f * u)
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.TAG -> {
                val p = Path().apply {
                    moveTo(3.5f * u, 4.5f * u); lineTo(12f * u, 4.5f * u); lineTo(20.5f * u, 13f * u)
                    lineTo(13f * u, 20.5f * u); lineTo(4.5f * u, 12f * u); close()
                }
                drawPath(p, tint, style = stroke)
                drawCircle(tint, 1.6f * u, Offset(8.2f * u, 8.6f * u))
            }
            IconKind.USER -> {
                drawCircle(tint, 4f * u, Offset(12f * u, 8f * u), style = stroke)
                val p = Path().apply { moveTo(4.5f * u, 20.5f * u); cubicTo(4.5f * u, 14f * u, 19.5f * u, 14f * u, 19.5f * u, 20.5f * u) }
                drawPath(p, tint, style = stroke)
            }
            IconKind.SHIELD -> {
                val p = Path().apply {
                    moveTo(12f * u, 3f * u); lineTo(19.5f * u, 6f * u); lineTo(19.5f * u, 12f * u)
                    cubicTo(19.5f * u, 16.5f * u, 16f * u, 19.5f * u, 12f * u, 21f * u)
                    cubicTo(8f * u, 19.5f * u, 4.5f * u, 16.5f * u, 4.5f * u, 12f * u)
                    lineTo(4.5f * u, 6f * u); close()
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.GITHUB -> {
                val p = Path().apply {
                    moveTo(9.2f * u, 6.2f * u); lineTo(5.0f * u, 4.2f * u); lineTo(5.3f * u, 10.4f * u)
                    cubicTo(3.6f * u, 13.2f * u, 5.6f * u, 19.6f * u, 12f * u, 20.2f * u)
                    cubicTo(18.4f * u, 19.6f * u, 20.4f * u, 13.2f * u, 18.7f * u, 10.4f * u)
                    lineTo(19f * u, 4.2f * u); lineTo(14.8f * u, 6.2f * u)
                    quadraticBezierTo(12f * u, 5.2f * u, 9.2f * u, 6.2f * u)
                    close()
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.BELL -> {
                val p = Path().apply {
                    moveTo(6f * u, 16.8f * u); lineTo(6f * u, 11f * u)
                    cubicTo(6f * u, 7.6f * u, 8.5f * u, 5f * u, 12f * u, 5f * u)
                    cubicTo(15.5f * u, 5f * u, 18f * u, 7.6f * u, 18f * u, 11f * u)
                    lineTo(18f * u, 16.8f * u); lineTo(19.6f * u, 18.2f * u); lineTo(4.4f * u, 18.2f * u); close()
                    moveTo(10f * u, 20.6f * u); quadraticBezierTo(12f * u, 22.4f * u, 14f * u, 20.6f * u)
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.FILTER -> {
                fun ln(x1: Float, x2: Float, y: Float) = drawLine(tint, Offset(x1 * u, y * u), Offset(x2 * u, y * u), 2f * u, StrokeCap.Round)
                ln(4f, 11f, 7f); ln(15.5f, 20f, 7f); drawCircle(tint, 2.2f * u, Offset(13.2f * u, 7f * u), style = stroke)
                ln(4f, 6.5f, 12f); ln(11f, 20f, 12f); drawCircle(tint, 2.2f * u, Offset(8.7f * u, 12f * u), style = stroke)
                ln(4f, 12f, 17f); ln(16.5f, 20f, 17f); drawCircle(tint, 2.2f * u, Offset(14.2f * u, 17f * u), style = stroke)
            }
            IconKind.CUBE -> {
                val p = Path().apply {
                    moveTo(12f * u, 3f * u); lineTo(20f * u, 7.5f * u); lineTo(20f * u, 16.5f * u); lineTo(12f * u, 21f * u)
                    lineTo(4f * u, 16.5f * u); lineTo(4f * u, 7.5f * u); close()
                    moveTo(4f * u, 7.5f * u); lineTo(12f * u, 12f * u); lineTo(20f * u, 7.5f * u)
                    moveTo(12f * u, 12f * u); lineTo(12f * u, 21f * u)
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.SERVER -> {
                val r = androidx.compose.ui.geometry.CornerRadius(2.4f * u)
                drawRoundRect(tint, Offset(4f * u, 4f * u), Size(16f * u, 7f * u), r, style = stroke)
                drawRoundRect(tint, Offset(4f * u, 13f * u), Size(16f * u, 7f * u), r, style = stroke)
                drawCircle(tint, 0.9f * u, Offset(7.6f * u, 7.5f * u)); drawCircle(tint, 0.9f * u, Offset(7.6f * u, 16.5f * u))
            }
            IconKind.CLOUD -> {
                val p = Path().apply {
                    moveTo(7f * u, 18.5f * u)
                    cubicTo(3.2f * u, 18.5f * u, 2.8f * u, 12.6f * u, 6.8f * u, 12f * u)
                    cubicTo(7.4f * u, 7.6f * u, 13.6f * u, 6.8f * u, 15f * u, 11.2f * u)
                    cubicTo(19.4f * u, 10.6f * u, 21f * u, 18.5f * u, 16.8f * u, 18.5f * u)
                    close()
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.STORE -> {
                val p = Path().apply {
                    moveTo(4f * u, 9.5f * u); lineTo(5.6f * u, 4.5f * u); lineTo(18.4f * u, 4.5f * u); lineTo(20f * u, 9.5f * u); lineTo(4f * u, 9.5f * u)
                    moveTo(5.5f * u, 9.5f * u); lineTo(5.5f * u, 20f * u); lineTo(18.5f * u, 20f * u); lineTo(18.5f * u, 9.5f * u)
                    moveTo(10f * u, 20f * u); lineTo(10f * u, 14.5f * u); lineTo(14f * u, 14.5f * u); lineTo(14f * u, 20f * u)
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.PLUS_CIRCLE -> {
                drawCircle(tint, 8.6f * u, Offset(12f * u, 12f * u), style = stroke)
                drawLine(tint, Offset(12f * u, 8f * u), Offset(12f * u, 16f * u), 2f * u, StrokeCap.Round)
                drawLine(tint, Offset(8f * u, 12f * u), Offset(16f * u, 12f * u), 2f * u, StrokeCap.Round)
            }
            IconKind.WRENCH -> {
                drawCircle(tint, 3.8f * u, Offset(16.2f * u, 7.8f * u), style = stroke)
                drawLine(tint, Offset(13.5f * u, 10.5f * u), Offset(5.2f * u, 18.8f * u), 2.6f * u, StrokeCap.Round)
            }
            IconKind.LAYERS -> {
                val p = Path().apply {
                    moveTo(12f * u, 3.5f * u); lineTo(20.5f * u, 8f * u); lineTo(12f * u, 12.5f * u); lineTo(3.5f * u, 8f * u); close()
                    moveTo(3.5f * u, 12f * u); lineTo(12f * u, 16.5f * u); lineTo(20.5f * u, 12f * u)
                    moveTo(3.5f * u, 16f * u); lineTo(12f * u, 20.5f * u); lineTo(20.5f * u, 16f * u)
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.SHIZUSTORE -> {
                // 参照 ShizuStore 官方图标：紫色圆底、白色购物袋轮廓与猫头标记。
                val purple = Color(0xFF7654D6)
                drawCircle(purple, radius = 11.9f * u, center = Offset(12f * u, 12f * u))
                val bag = Path().apply {
                    // 购物袋主体
                    moveTo(5.2f * u, 8.0f * u)
                    lineTo(18.8f * u, 8.0f * u)
                    lineTo(20.0f * u, 18.3f * u)
                    cubicTo(20.1f * u, 19.3f * u, 19.3f * u, 20.0f * u, 18.3f * u, 20.0f * u)
                    lineTo(5.7f * u, 20.0f * u)
                    cubicTo(4.7f * u, 20.0f * u, 3.9f * u, 19.3f * u, 4.0f * u, 18.3f * u)
                    close()
                    // 提手
                    moveTo(8.0f * u, 9.0f * u)
                    lineTo(8.0f * u, 6.6f * u)
                    cubicTo(8.0f * u, 2.7f * u, 16.0f * u, 2.7f * u, 16.0f * u, 6.6f * u)
                    lineTo(16.0f * u, 9.0f * u)
                }
                drawPath(bag, Color.White, style = Stroke(1.45f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
                // 白色猫头剪影（尖耳、圆脸）
                val cat = Path().apply {
                    moveTo(7.0f * u, 12.3f * u)
                    lineTo(7.2f * u, 9.4f * u)
                    lineTo(10.0f * u, 10.8f * u)
                    cubicTo(11.3f * u, 10.3f * u, 12.7f * u, 10.3f * u, 14.0f * u, 10.8f * u)
                    lineTo(16.8f * u, 9.4f * u)
                    lineTo(17.0f * u, 12.3f * u)
                    cubicTo(17.8f * u, 16.0f * u, 15.0f * u, 18.0f * u, 12.0f * u, 18.0f * u)
                    cubicTo(9.0f * u, 18.0f * u, 6.2f * u, 16.0f * u, 7.0f * u, 12.3f * u)
                    close()
                }
                drawPath(cat, Color.White)
                drawCircle(purple, radius = 0.65f * u, center = Offset(10.0f * u, 13.8f * u))
                drawCircle(purple, radius = 0.65f * u, center = Offset(14.0f * u, 13.8f * u))
                // 袋口横线，保留官方图标的辨识特征。
                drawLine(Color.White, Offset(9.0f * u, 7.7f * u), Offset(15.0f * u, 7.7f * u), 1.1f * u, StrokeCap.Round)
            }
            IconKind.PALETTE -> {
                drawOval(tint, Offset(3f * u, 4f * u), Size(18f * u, 16f * u), style = stroke)
                drawCircle(tint, 1.2f * u, Offset(8f * u, 10f * u)); drawCircle(tint, 1.2f * u, Offset(12f * u, 7.8f * u))
                drawCircle(tint, 1.2f * u, Offset(16f * u, 10f * u)); drawCircle(tint, 1.2f * u, Offset(9f * u, 14.5f * u))
            }
            IconKind.MORE -> {
                drawCircle(tint, 2f * u, Offset(5f * u, 12f * u))
                drawCircle(tint, 2f * u, Offset(12f * u, 12f * u))
                drawCircle(tint, 2f * u, Offset(19f * u, 12f * u))
            }
            IconKind.CLOSE -> {
                val p = Path().apply { moveTo(6f * u, 6f * u); lineTo(18f * u, 18f * u); moveTo(18f * u, 6f * u); lineTo(6f * u, 18f * u) }
                drawPath(p, tint, style = stroke)
            }
            IconKind.PLUS -> {
                val p = Path().apply { moveTo(12f * u, 5f * u); lineTo(12f * u, 19f * u); moveTo(5f * u, 12f * u); lineTo(19f * u, 12f * u) }
                drawPath(p, tint, style = stroke)
            }
            IconKind.TRASH -> {
                val p = Path().apply {
                    moveTo(4f * u, 6.5f * u); lineTo(20f * u, 6.5f * u)
                    moveTo(9.5f * u, 6.5f * u); lineTo(9.5f * u, 4f * u); lineTo(14.5f * u, 4f * u); lineTo(14.5f * u, 6.5f * u)
                    moveTo(6f * u, 6.5f * u); lineTo(7f * u, 20f * u); lineTo(17f * u, 20f * u); lineTo(18f * u, 6.5f * u)
                    moveTo(10f * u, 10f * u); lineTo(10f * u, 16f * u); moveTo(14f * u, 10f * u); lineTo(14f * u, 16f * u)
                }
                drawPath(p, tint, style = stroke)
            }
            IconKind.SPARK -> {
                val p = Path().apply {
                    moveTo(12f * u, 2f * u); quadraticBezierTo(13.4f * u, 10.6f * u, 22f * u, 12f * u)
                    quadraticBezierTo(13.4f * u, 13.4f * u, 12f * u, 22f * u)
                    quadraticBezierTo(10.6f * u, 13.4f * u, 2f * u, 12f * u)
                    quadraticBezierTo(10.6f * u, 10.6f * u, 12f * u, 2f * u); close()
                }
                drawPath(p, tint)
            }
            IconKind.LINK -> {
                rotate(-45f, Offset(12f * u, 12f * u)) {
                    drawRoundRect(tint, Offset(1.5f * u, 8.8f * u), Size(11f * u, 6.4f * u), androidx.compose.ui.geometry.CornerRadius(3.2f * u), style = stroke)
                    drawRoundRect(tint, Offset(11.5f * u, 8.8f * u), Size(11f * u, 6.4f * u), androidx.compose.ui.geometry.CornerRadius(3.2f * u), style = stroke)
                }
            }
            IconKind.FORK -> {
                drawCircle(tint, 2.4f * u, Offset(6f * u, 5f * u), style = stroke)
                drawCircle(tint, 2.4f * u, Offset(18f * u, 5f * u), style = stroke)
                drawCircle(tint, 2.4f * u, Offset(12f * u, 20f * u), style = stroke)
                val p = Path().apply {
                    moveTo(6f * u, 7.4f * u); lineTo(6f * u, 10f * u); lineTo(18f * u, 10f * u); lineTo(18f * u, 7.4f * u)
                    moveTo(12f * u, 10f * u); lineTo(12f * u, 17.6f * u)
                }
                drawPath(p, tint, style = stroke)
            }
        }
    }
}
