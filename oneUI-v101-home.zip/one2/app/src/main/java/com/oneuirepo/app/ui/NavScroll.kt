package com.oneuirepo.app.ui

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.*

/**
 * 底部导航与页面滚动的联动：
 * 页面上滑超过几项后，[far] 变为 true，导航栏里当前页的图标会形变成「回到顶部」箭头；
 * 点击后 [tick] +1，当前页的列表平滑滚动回顶部。
 */
class NavScrollController {
    var far by mutableStateOf(false)
    var tick by mutableIntStateOf(0)
}

val LocalNavScroll = compositionLocalOf<NavScrollController?> { null }

private const val FAR_ITEMS = 3

@Composable
fun ScrollTopEffect(state: LazyListState) {
    val ctrl = LocalNavScroll.current ?: return
    val far by remember(state) { derivedStateOf { state.firstVisibleItemIndex >= FAR_ITEMS } }
    LaunchedEffect(far) { ctrl.far = far }
    DisposableEffect(Unit) { onDispose { ctrl.far = false } }
    var seen by remember { mutableIntStateOf(ctrl.tick) }
    LaunchedEffect(ctrl.tick) {
        if (ctrl.tick != seen) { seen = ctrl.tick; state.animateScrollToItem(0) }
    }
}

@Composable
fun ScrollTopEffect(state: LazyGridState) {
    val ctrl = LocalNavScroll.current ?: return
    val far by remember(state) { derivedStateOf { state.firstVisibleItemIndex >= FAR_ITEMS } }
    LaunchedEffect(far) { ctrl.far = far }
    DisposableEffect(Unit) { onDispose { ctrl.far = false } }
    var seen by remember { mutableIntStateOf(ctrl.tick) }
    LaunchedEffect(ctrl.tick) {
        if (ctrl.tick != seen) { seen = ctrl.tick; state.animateScrollToItem(0) }
    }
}
