package com.oneuirepo.app.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oneuirepo.app.R
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape
import kotlinx.coroutines.delay

private data class Feature(val icon: IconKind, val title: String, val desc: String)

private val features = listOf(
    Feature(IconKind.SEARCH, "开源项目收集", "汇集 GitHub 上与 Samsung One UI 生态相关的开源项目，帮助用户快速发现实用的玩机工具与开发资源。"),
    Feature(IconKind.GRID, "项目分类浏览", "覆盖 One UI 版本、SystemUI、RRO / 主题、字体、LSPosed、Shizuku、Root、KernelSU、Magisk、DeX、折叠屏、Watch 以及电池与性能等专区。"),
    Feature(IconKind.DOWNLOAD, "GitHub 仓库导入", "支持提交 GitHub 仓库地址，自动解析项目基本资料，并将项目导入应用或更新已有记录。"),
    Feature(IconKind.TAG, "Release 版本追踪", "获取 GitHub Releases 发布信息及可用的 APK 下载资源，方便用户查看版本变化与项目更新。"),
    Feature(IconKind.USER, "GitHub 账号连接", "支持 GitHub OAuth 登录，为账号关联及后续仓库管理功能提供基础。")
)

/** 依次淡入并上滑，进入设置页时有"逐条出现"的效果。 */
@Composable
private fun Reveal(index: Int, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(90L * index); shown = true }
    AnimatedVisibility(
        visible = shown,
        enter = fadeIn(tween(420)) + slideInVertically(tween(420, easing = FastOutSlowInEasing)) { it / 4 }
    ) { content() }
}

@Composable
fun AboutSection(versionText: String, apiStatus: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    var uid by remember { mutableStateOf(com.oneuirepo.app.settings.AppSettings(context).uid) }
    var showUid by remember { mutableStateOf(false) }
    var taps by remember { mutableIntStateOf(0) }
    var lastTap by remember { mutableLongStateOf(0L) }
    var pulse by remember { mutableIntStateOf(0) }
    // 隐藏彩蛋：连续点击应用图标 7 次（每次间隔不超过 1.8 秒），弹出 UID 登录窗口
    val onIconTap = {
        val now = System.currentTimeMillis()
        taps = if (now - lastTap > 1800) 1 else taps + 1
        lastTap = now
        pulse++
        haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.LongPress)
        if (taps == 4) android.widget.Toast.makeText(context, "再连续点击 3 次…", android.widget.Toast.LENGTH_SHORT).show()
        if (taps >= 7) { taps = 0; showUid = true }
    }
    if (showUid) {
        UidLoginDialog(
            currentUid = uid,
            onDismiss = { showUid = false },
            onLogin = {
                com.oneuirepo.app.settings.AppSettings(context).uid = it
                uid = it; showUid = false
                android.widget.Toast.makeText(context, "UID 登录成功", android.widget.Toast.LENGTH_SHORT).show()
            },
            onLogout = {
                com.oneuirepo.app.settings.AppSettings(context).uid = ""
                uid = ""; showUid = false
                android.widget.Toast.makeText(context, "已退出 UID 登录", android.widget.Toast.LENGTH_SHORT).show()
            }
        )
    }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Reveal(0) { Header(versionText, uid, pulse, onIconTap) }
        Reveal(1) {
            AboutCard {
                Text(
                    "One Store 是一款专注于 Samsung One UI 生态的开源项目收集与管理应用，致力于为 Galaxy 用户提供便捷的开源项目发现、浏览、追踪与管理体验。",
                    style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp
                )
            }
        }
        Reveal(2) {
            AboutCard {
                SectionTitle("核心功能")
                Spacer(Modifier.height(6.dp))
                features.forEach { f -> FeatureRow(f) }
            }
        }
        Reveal(3) { Disclaimer() }
        Reveal(4) {
            AboutCard {
                SectionTitle("关于我们")
                Spacer(Modifier.height(8.dp))
                Text(
                    "让 One UI 玩机资源更集中，让开源项目发现更简单。",
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary, lineHeight = 22.sp
                )
                Spacer(Modifier.height(10.dp))
                InfoLine("应用名称", "One Store")
                InfoLine("应用版本", versionText)
                InfoLine("GitHub API", apiStatus)
            }
        }
        Reveal(10) { AuthorCard() }
    }
}

@Composable
private fun Header(versionText: String, uid: String, pulse: Int, onIconTap: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "float")
    val dy by inf.animateFloat(
        -3f, 3f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy"
    )
    val density = LocalDensity.current
    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary
    // 每次点击图标时弹一下
    val bump = remember { androidx.compose.animation.core.Animatable(1f) }
    LaunchedEffect(pulse) {
        if (pulse > 0) {
            bump.snapTo(0.86f)
            bump.animateTo(1f, androidx.compose.animation.core.spring(dampingRatio = 0.35f, stiffness = 300f))
        }
    }
    Box(
        Modifier.fillMaxWidth().clip(cardShape(28.dp))
            .background(Brush.linearGradient(listOf(primary, tertiary)))
    ) {
        Box(Modifier.size(150.dp).align(Alignment.TopEnd).offset(x = 40.dp, y = (-50).dp).clip(CircleShape).background(Color.White.copy(alpha = 0.13f)))
        Box(Modifier.size(90.dp).align(Alignment.BottomStart).offset(x = (-30).dp, y = 36.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)))
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(76.dp)
                    .graphicsLayer { translationY = dy * density.density; scaleX = bump.value; scaleY = bump.value }
                    .clip(RoundedCornerShape(22.dp))
                    .clickable(interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, indication = null, onClick = onIconTap)
            ) {
                Image(painterResource(R.drawable.ic_launcher_bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Image(painterResource(R.drawable.ic_launcher_fg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            }
            Column(Modifier.padding(start = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("One Store", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, color = Color.White)
                Text("Samsung One UI 开源项目收集与管理", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.88f))
                Box(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.24f)).padding(horizontal = 10.dp, vertical = 3.dp)) {
                    Text("版本 $versionText", style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.SemiBold)
                }
                if (uid.isNotEmpty()) {
                    Box(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.24f)).padding(horizontal = 10.dp, vertical = 3.dp)) {
                        Text("UID $uid", style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.SemiBold, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
private fun AboutCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = cardShape(24.dp), border = cardBorder(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) { Column(Modifier.padding(18.dp), content = content) }
}

@Composable
private fun SectionTitle(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(5.dp).height(18.dp).clip(RoundedCornerShape(3.dp)).background(MaterialTheme.colorScheme.primary))
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun FeatureRow(f: Feature) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) { AppIcon(f.icon, MaterialTheme.colorScheme.onPrimaryContainer, 22.dp) }
        Column(Modifier.padding(start = 14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(f.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
            Text(f.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun Disclaimer() {
    var open by remember { mutableStateOf(false) }
    val rot by animateFloatAsState(if (open) 270f else 90f, tween(300), label = "chev")
    AboutCard {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { open = !open },
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIcon(IconKind.SHIELD, MaterialTheme.colorScheme.primary, 22.dp)
            Spacer(Modifier.width(10.dp))
            Text("开源与免责声明", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
            AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onSurfaceVariant, 20.dp, Modifier.graphicsLayer { rotationZ = rot })
        }
        AnimatedVisibility(
            open,
            enter = expandVertically(tween(320)) + fadeIn(tween(320)),
            exit = shrinkVertically(tween(260)) + fadeOut(tween(200))
        ) {
            Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(
                    "One Store 旨在整理和展示公开的开源项目信息，为用户提供集中、便捷的项目发现入口。",
                    "本应用不拥有所收录第三方项目的知识产权。相关项目的版权、开源许可证及维护责任均归原作者或相应权利人所有。",
                    "One Store 与 Samsung、GitHub 及所收录的第三方项目作者不存在默认的官方隶属、授权或背书关系。第三方项目的内容、更新与下载资源由各自维护者负责。用户在安装或使用相关项目之前，应自行核实项目来源、许可证、权限要求及安全性。"
                ).forEach {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 19.sp)
                }
            }
        }
    }
}

@Composable
private fun InfoLine(k: String, v: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(k, Modifier.width(88.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(v, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
    }
}

/** 原作者：头像字 + 名字 + 个性签名 + 联系方式（一键复制）。 */
@Composable
private fun AuthorCard() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val primary = MaterialTheme.colorScheme.primary
    AboutCard {
        SectionTitle("原作者")
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(R.drawable.author_avatar), null,
                Modifier.size(64.dp).clip(CircleShape), contentScale = ContentScale.Crop
            )
            Column(Modifier.padding(start = 14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("时倾", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Box(Modifier.clip(RoundedCornerShape(50)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 10.dp, vertical = 2.dp)) {
                    Text("原作者", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        // 个性签名
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(primary.copy(alpha = 0.10f)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(4.dp).height(40.dp).clip(RoundedCornerShape(2.dp)).background(primary))
            Column(Modifier.padding(start = 12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("个性签名", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "愿用我的全部时间，倾你一人的心。",
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, lineHeight = 22.sp
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        // 联系方式
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Color(0xFF12B7F5)), contentAlignment = Alignment.Center) {
                AppIcon(IconKind.USER, Color.White, 22.dp)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text("联系方式", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("862373373", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
            }
            FilledTonalButton(onClick = {
                val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("contact", "862373373"))
                android.widget.Toast.makeText(context, "已复制", android.widget.Toast.LENGTH_SHORT).show()
            }) { Text("复制") }
        }
    }
}
