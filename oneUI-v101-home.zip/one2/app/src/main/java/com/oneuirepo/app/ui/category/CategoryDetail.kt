package com.oneuirepo.app.ui.category

import com.oneuirepo.app.ui.ScrollTopEffect
import android.app.Activity
import android.content.ContextWrapper
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.CategoryTagEntity
import com.oneuirepo.app.data.local.entity.RepoTagEntity
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import com.oneuirepo.app.ui.common.FrostedIconButton
import com.oneuirepo.app.ui.common.FrostedPill
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.common.SearchField
import com.oneuirepo.app.ui.common.SegItem
import com.oneuirepo.app.ui.common.SegmentedControl
import com.oneuirepo.app.ui.common.clearFocusOnTap
import com.oneuirepo.app.ui.cve.CveScreen
import kotlinx.coroutines.launch

@Composable
internal fun CategoryDetail(db: AppDatabase, name: String, onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val cat = catOf(name)
    val title = name.removePrefix("c:")
    val isCustom = name.startsWith("c:")
    var confirmDelete by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val isCve = name == "CVE"
    var cveTab by remember { mutableStateOf(0) }
    val repos by db.categoryDao().observeRepos(name).collectAsState(initial = emptyList())

    // 彩色头图延伸到状态栏下面：请求白色状态栏图标，离开时还原为跟随主题
    DisposableEffect(Unit) {
        com.oneuirepo.app.ui.theme.ThemeState.statusIconsLight = true
        onDispose { com.oneuirepo.app.ui.theme.ThemeState.statusIconsLight = null }
    }

    Column(Modifier.fillMaxSize().clearFocusOnTap()) {
        DetailHeader(
            cat = cat, title = title, count = repos.size, stars = repos.sumOf { it.stars.toLong() },
            isCustom = isCustom, onBack = onBack, onDelete = { confirmDelete = true }
        )
        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text("删除分类「$title」？") },
                text = { Text("只会删除这个分类和它的标签，里面的项目不会被删除。") },
                confirmButton = {
                    TextButton(onClick = {
                        confirmDelete = false
                        scope.launch {
                            db.tagDao().deleteLinksOfCategory(name)
                            db.tagDao().deleteTagsOfCategory(name)
                            db.categoryDao().deleteCategoryLinks(name)
                            db.categoryDao().deleteCategory(name)
                        }
                        onBack()
                    }) { Text("删除") }
                },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("取消") } }
            )
        }
        if (isCve) {
            SegmentedControl(
                listOf(SegItem(IconKind.SHIELD, "漏洞列表"), SegItem(IconKind.GRID, "相关项目")), cveTab, { cveTab = it },
                Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )
            if (cveTab == 0) CveScreen(db) else RepoList(db, cat, name, repos, onOpen)
        } else {
            RepoList(db, cat, name, repos, onOpen)
        }
    }
}

private fun fmtStars(n: Long): String = if (n >= 10000) String.format("%.1f万", n / 10000.0) else n.toString()

/** 彩色渐变头图：圆角底边、延伸到状态栏下面；左上返回，中间是大徽标 + 名称 + 统计。 */
@Composable
private fun DetailHeader(cat: Cat, title: String, count: Int, stars: Long, isCustom: Boolean, onBack: () -> Unit, onDelete: () -> Unit) {
    val accent = cat.color
    Box(
        Modifier.fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 34.dp, bottomEnd = 34.dp))
            .background(Brush.linearGradient(listOf(accent, accent.deep(0.74f))))
    ) {
        Box(Modifier.size(180.dp).align(Alignment.TopEnd).offset(x = 56.dp, y = (-46).dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)))
        if (categoryImage(cat.name) == null) {
            // 大号半透明插画做水印
            CategoryArt(cat.name, accent.deep(), Modifier.align(Alignment.BottomEnd).padding(end = 18.dp, bottom = 16.dp).alpha(0.32f), size = 112.dp)
        }
        Column(
            Modifier.statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FrostedIconButton(IconKind.BACK, onBack)
                Spacer(Modifier.weight(1f))
                if (isCustom) FrostedPill(IconKind.TRASH, "删除分类", onDelete)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                CategoryBadge(cat, 64.dp)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatChip("$count 个项目")
                        if (stars > 0) StatChip("★ ${fmtStars(stars)}")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatChip(text: String) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.24f)).padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun RepoList(db: AppDatabase, cat: Cat, name: String, repos: List<RepositoryEntity>, onOpen: (Long) -> Unit) {
    val tags by db.tagDao().observeTags(name).collectAsState(initial = emptyList())
    val links by db.tagDao().observeLinks(name).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(0) }
    var selectedTag by remember { mutableStateOf<Long?>(null) }
    var showNewTag by remember { mutableStateOf(false) }
    var confirmDeleteTag by remember { mutableStateOf(false) }

    // 选中的标签被删掉后回到「全部」
    LaunchedEffect(tags) { if (selectedTag != null && tags.none { it.id == selectedTag }) selectedTag = null }

    val tagsOfRepo = remember(links) { links.groupBy({ it.repositoryId }, { it.tagId }).mapValues { it.value.toSet() } }
    val tagCounts = remember(tagsOfRepo, repos, tags) {
        val inCat = repos.map { it.id }.toSet()
        tags.associate { t -> t.id to tagsOfRepo.count { (rid, ts) -> rid in inCat && t.id in ts } }
    }
    val shown = remember(repos, q, sort, selectedTag, tagsOfRepo) {
        var f = repos.filter { q.isBlank() || it.fullName.contains(q, true) || it.description.orEmpty().contains(q, true) }
        selectedTag?.let { tid -> f = f.filter { tid in (tagsOfRepo[it.id] ?: emptySet()) } }
        when (sort) {
            0 -> f.sortedByDescending { it.stars }
            1 -> f.sortedByDescending { it.updatedAt.orEmpty() }
            else -> f.sortedByDescending { it.createdAt.orEmpty() }
        }
    }
    val selectedTagEntity = tags.firstOrNull { it.id == selectedTag }

    val gridState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    ScrollTopEffect(gridState)
    // 手机一列；折叠屏 / 平板展开后自动变成两列、三列
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 300.dp),
        modifier = Modifier.fillMaxSize(),
        state = gridState,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 16.dp + com.oneuirepo.app.ui.LocalNavInset.current),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { SearchField(q, { q = it }, "在「${name.removePrefix("c:")}」中搜索") }
        item(span = { GridItemSpan(maxLineSpan) }) {
            SegmentedControl(
                listOf(SegItem(IconKind.STAR, "Star"), SegItem(IconKind.CLOCK, "最近更新"), SegItem(IconKind.SPARK, "最新")),
                sort, { sort = it }
            )
        }
        // ---- 自定义标签栏：项目多的时候按标签筛选
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("标签", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TagChip("全部", selected = selectedTag == null, count = repos.size) { selectedTag = null }
                    tags.forEach { t ->
                        TagChip(t.name, selected = selectedTag == t.id, count = tagCounts[t.id] ?: 0) {
                            selectedTag = if (selectedTag == t.id) null else t.id
                        }
                    }
                    AddChip("新建标签") { showNewTag = true }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (selectedTagEntity != null) "标签「${selectedTagEntity.name}」· ${shown.size} 个项目"
                        else "共 ${shown.size} 个项目　点开卡片可下载、放入标签",
                        Modifier.weight(1f).padding(start = 4.dp), style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (selectedTagEntity != null) {
                        TextButton(onClick = { confirmDeleteTag = true }) { Text("删除标签", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
        if (shown.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) { EmptyCategory(cat, filtered = q.isNotBlank() || selectedTag != null) }
        }
        items(shown, key = { it.id }) { r ->
            ExpandableRepoCard(
                r = r, db = db, tags = tags, tagIds = tagsOfRepo[r.id] ?: emptySet(),
                onToggleTag = { tid, on ->
                    scope.launch {
                        if (on) db.tagDao().addLink(RepoTagEntity(r.id, tid)) else db.tagDao().removeLink(r.id, tid)
                    }
                },
                onNewTag = { showNewTag = true },
                onOpen = { onOpen(r.id) }
            )
        }
    }

    if (showNewTag) {
        NewTagDialog(existing = tags.map { it.name }.toSet(), onDismiss = { showNewTag = false }) { tagName ->
            scope.launch { db.tagDao().insertTag(CategoryTagEntity(categoryId = name, name = tagName)) }
            showNewTag = false
        }
    }
    if (confirmDeleteTag && selectedTagEntity != null) {
        AlertDialog(
            onDismissRequest = { confirmDeleteTag = false },
            title = { Text("删除标签「${selectedTagEntity.name}」？") },
            text = { Text("只会删除这个标签，项目仍然留在分类里。") },
            confirmButton = {
                TextButton(onClick = {
                    val id = selectedTagEntity.id
                    confirmDeleteTag = false
                    scope.launch { db.tagDao().deleteTagLinks(id); db.tagDao().deleteTag(id) }
                }) { Text("删除") }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteTag = false }) { Text("取消") } }
        )
    }
}

@Composable
private fun EmptyCategory(cat: Cat, filtered: Boolean) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.size(88.dp).clip(CircleShape).background(cat.color.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            CategoryGlyph(cat.name, cat.color.deep(0.8f), 42.dp)
        }
        Text(if (filtered) "没有找到项目" else "这个分类还没有项目", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(
            if (filtered) "换个关键词或标签试试" else "在项目详情页点「＋ 添加到分类」，\n或先到 GitHub 页导入仓库再放进来",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun NewTagDialog(existing: Set<String>, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    com.oneuirepo.app.ui.common.NameInputDialog(
        title = "新建标签",
        subtitle = "在分类里再分组，项目多时更好找",
        placeholder = "标签名，例如：汉化 / 常用",
        leading = IconKind.TAG,
        existing = existing,
        duplicateMessage = "已经有同名标签了",
        maxLen = 12,
        onDismiss = onDismiss,
        onConfirm = onConfirm
    ) { name -> TagChip(name.ifEmpty { "标签名" }, selected = true) {} }
}
