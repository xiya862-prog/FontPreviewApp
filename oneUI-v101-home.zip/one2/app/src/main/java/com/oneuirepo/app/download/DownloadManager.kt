package com.oneuirepo.app.download

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment

class AppDownloadManager(private val context: Context){
    fun enqueue(url:String,fileName:String):Long{
        val request=DownloadManager.Request(Uri.parse(url))
            .setTitle(fileName)
            .setDescription("One Store")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"One Store/$fileName")
        return (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    }
}
