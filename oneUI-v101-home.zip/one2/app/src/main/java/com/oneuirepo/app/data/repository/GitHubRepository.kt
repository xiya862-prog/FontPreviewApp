package com.oneuirepo.app.data.repository

import android.util.Base64
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.*
import com.oneuirepo.app.data.remote.*
import com.oneuirepo.app.domain.classifier.ClassificationEngine
import com.oneuirepo.app.domain.model.ImportResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

class GitHubRepository(
    private val api: GitHubApi,
    private val db: AppDatabase,
    private val c: ClassificationEngine
) {
    /** 用户手动导入：一定会出现在首页推荐里。 */
    suspend fun import(owner: String, repo: String): ImportResult = withContext(Dispatchers.IO) {
        val r = importDto(api.getRepository(owner, repo))
        db.historyDao().unmarkDiscovered(r.repository.id)
        r
    }

    suspend fun syncExisting(repositoryId: Long): SyncOutcome = withContext(Dispatchers.IO) {
        val local = db.repositoryDao().findById(repositoryId) ?: return@withContext SyncOutcome(false, null)
        val parts = local.fullName.split('/', limit = 2)
        if (parts.size != 2) return@withContext SyncOutcome(false, null)
        val state = db.syncStateDao().find(repositoryId)
        val response = api.getRepositoryResponse(parts[0], parts[1], state?.etag)
        if (response.code() == 304) {
            db.syncStateDao().upsert(SyncStateEntity(repositoryId, state?.etag, System.currentTimeMillis()))
            return@withContext SyncOutcome(false, null)
        }
        val dto = response.body() ?: return@withContext SyncOutcome(false, null)
        val oldLatest = db.releaseDao().findLatest(repositoryId)?.tagName
        val result = importDto(dto)
        db.syncStateDao().upsert(SyncStateEntity(repositoryId, response.headers()["ETag"], System.currentTimeMillis()))
        val newLatest = db.releaseDao().findLatest(repositoryId)?.tagName
        SyncOutcome(oldLatest != null && newLatest != null && oldLatest != newLatest, newLatest)
    }

    suspend fun searchRemote(q: String, sort: String?, page: Int, perPage: Int = 20): List<GitHubRepositoryDto> = withContext(Dispatchers.IO) {
        api.searchRepositories(q, sort, "desc", perPage, page).items
    }

    /** 从发现页 / 星标列表点开：入库用于详情展示，但不进首页推荐。已经在库里的项目保持原状。 */
    suspend fun importRemote(dto: GitHubRepositoryDto): ImportResult = withContext(Dispatchers.IO) {
        val existed = db.repositoryDao().findById(dto.id) != null
        val r = importDto(dto)
        if (!existed) db.historyDao().markDiscovered(DiscoveredEntity(dto.id))
        r
    }

    private suspend fun importDto(r: GitHubRepositoryDto): ImportResult {
        // These endpoints are independent. Fetch them concurrently so import/update waits
        // for the slowest request instead of summing all three network latencies.
        val (topics, readmeDto, releases) = coroutineScope {
            val topicsTask = async { safely(r.topics) { api.getTopics(r.owner.login, r.name).names } }
            val readmeTask = async { safely<GitHubReadmeDto?>(null) { api.getReadme(r.owner.login, r.name) } }
            val releasesTask = async { safely(emptyList<GitHubReleaseDto>()) { api.getReleases(r.owner.login, r.name) } }
            Triple(topicsTask.await(), readmeTask.await(), releasesTask.await())
        }
        val readme = readmeDto?.let { decode(it) }
        val text = listOf(r.name, r.description.orEmpty(), topics.joinToString(" "), readme.orEmpty(), releases.joinToString(" ") { it.name.orEmpty() }).joinToString(" ")
        val cats = c.classify(text)
        val e = RepositoryEntity(
            r.id, r.owner.login, r.name, r.fullName, r.description, r.htmlUrl, r.owner.avatarUrl, null,
            r.stars, r.forks, r.watchers, r.language, r.license?.name ?: r.license?.key,
            topics.joinToString("\n"), readme,
            cats.filter { it.startsWith("One UI") }.joinToString("\n"),
            c.androidVersions(text).joinToString("\n"), c.devices(text).joinToString("\n"), c.requirements(readme),
            r.createdAt, r.updatedAt, System.currentTimeMillis(), r.archived, r.visibility
        )
        db.repositoryDao().upsert(e)
        db.categoryDao().upsertAll(c.allCategories.map { CategoryEntity(it, it) })
        // 分类完全由用户手动选择，导入 / 同步时不再自动归类
        db.releaseDao().deleteAssets(r.id)
        db.releaseDao().deleteReleases(r.id)
        db.releaseDao().upsertAll(releases.map { rel -> ReleaseEntity(rel.id, r.id, rel.tagName, rel.name, rel.body, rel.publishedAt, rel.htmlUrl) })
        db.releaseDao().upsertAssets(releases.flatMap { rel -> rel.assets.map { a ->
            val n = a.name.lowercase()
            ReleaseAssetEntity(a.id, rel.id, a.name, a.size, a.browserDownloadUrl, a.contentType, a.downloadCount, a.digest,
                when { n.endsWith(".apk") -> "APK"; n.endsWith(".zip") -> "ZIP"; n.endsWith(".jar") -> "JAR"; else -> "OTHER" })
        } })
        val cveIds = Regex("CVE-\\d{4}-\\d{4,7}", RegexOption.IGNORE_CASE).findAll(text).map { it.value.uppercase() }.distinct().toList()
        if (cveIds.isNotEmpty()) db.cveDao().existingIds(cveIds).forEach { db.cveDao().link(com.oneuirepo.app.cve.RepositoryCveCrossRef(r.id, it)) }
        return ImportResult(e, emptyList(), releases.size)
    }

    private suspend fun <T> safely(fallback: T, block: suspend () -> T): T = try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (_: Exception) {
        fallback
    }

    private fun decode(x: GitHubReadmeDto): String? = x.content?.let {
        if (x.encoding.equals("base64", true)) runCatching {
            Base64.decode(it.replace("\n", ""), Base64.DEFAULT).toString(Charsets.UTF_8)
        }.getOrNull() else it
    }
}

data class SyncOutcome(val changed: Boolean, val latestReleaseTag: String?)
