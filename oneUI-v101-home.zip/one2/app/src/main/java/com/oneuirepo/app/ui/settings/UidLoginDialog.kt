package com.oneuirepo.app.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.common.SearchField

/** 隐藏入口：在「关于」里连续点击应用图标触发的 UID 登录窗口（UID 只保存在本机）。 */
@Composable
fun UidLoginDialog(currentUid: String, onDismiss: () -> Unit, onLogin: (String) -> Unit, onLogout: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val uid = text.trim()
    val digits = uid.all { it.isDigit() }
    val error = when {
        uid.isNotEmpty() && !digits -> "UID 只能是数字"
        uid.isNotEmpty() && uid.length !in 4..12 -> "UID 需要 4–12 位数字"
        else -> null
    }
    val can = uid.length in 4..12 && digits
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.padding(horizontal = 24.dp).fillMaxWidth(),
            shape = RoundedCornerShape(30.dp), color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) { AppIcon(IconKind.USER, MaterialTheme.colorScheme.onPrimaryContainer, 24.dp) }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("UID 登录", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("隐藏入口 · 连续点击应用图标触发", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (currentUid.isNotEmpty()) {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)).padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text("当前已登录", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("UID $currentUid", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = onLogout, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(50)) {
                            Text("退出登录", color = MaterialTheme.colorScheme.error)
                        }
                        Button(onClick = onDismiss, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(50)) { Text("关闭", fontWeight = FontWeight.Bold) }
                    }
                } else {
                    SearchField(
                        text, { text = it }, "请输入 UID（4–12 位数字）", leading = IconKind.USER,
                        imeAction = ImeAction.Done, onSubmit = { if (can) onLogin(uid) }, keyboardType = KeyboardType.Number
                    )
                    Box(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
                        if (error != null) Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        else Text("UID 仅保存在本机，用于本地标识，不会上传，也不会向服务器验证。", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(50)) { Text("取消") }
                        Button(onClick = { onLogin(uid) }, enabled = can, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(50)) {
                            Text("登录", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
