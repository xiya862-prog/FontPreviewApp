package com.oneuirepo.app.ui.home

import androidx.compose.foundation.lazy.rememberLazyListState
import com.oneuirepo.app.ui.ScrollTopEffect
import androidx.compose.foundation.background
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape
import coil3.compose.AsyncImage
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.common.PickerOption
import com.oneuirepo.app.ui.common.PickerSheet
import com.oneuirepo.app.ui.common.SegItem
import com.oneuirepo.app.ui.common.SegmentedControl
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    onSearch: () -> Unit,
    onExplore: () -> Unit,
    onCategory: (String?) -> Unit,
    onOpen: (Long) -> Unit,
    onFdroid: () -> Unit,
    onShizuStore: () -> Unit
) {
    var hotAll by rememberSaveable { mutableStateOf(false) }
    var moreSources by rememberSaveable { mutableStateOf(false) }
    var showStores by remember { mutableStateOf(false) }
    val context = LocalContext.current
    fun openUrl(url: String) {
        runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
    val listState = rememberLazyListState()
    ScrollTopEffect(listState)
    val primary = MaterialTheme.colorScheme.primary
    val liquidTransition = rememberInfiniteTransition(label = "homeLiquidBackground")
    val liquidX by liquidTransition.animateFloat(
        initialValue = 0.12f, targetValue = 0.88f,
        animationSpec = infiniteRepeatable(tween(7200), RepeatMode.Reverse), label = "liquidX"
    )
    val liquidY by liquidTransition.animateFloat(
        initialValue = 0.18f, targetValue = 0.82f,
        animationSpec = infiniteRepeatable(tween(9300), RepeatMode.Reverse), label = "liquidY"
    )

    LazyColumn(
        Modifier.fillMaxSize().drawBehind {
            // Subtle moving liquid-glass glow behind the existing content.
            // Keep it in drawBehind so it does not add composables to each list row.
            val radius = size.width * 0.72f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x2676B9FF), Color(0x0D8C78FF), Color.Transparent),
                    center = Offset(size.width * liquidX, size.height * liquidY),
                    radius = radius
                ),
                radius = radius,
                center = Offset(size.width * liquidX, size.height * liquidY)
            )
            // Slow morphing fluid form: a single path behind the lazy list content.
            val fluid = Path().apply {
                moveTo(size.width * .18f, size.height * (.16f + liquidY * .04f))
                cubicTo(size.width * (.42f + liquidX * .08f), size.height * .02f, size.width * .72f, size.height * (.08f + liquidY * .08f), size.width * .82f, size.height * .25f)
                cubicTo(size.width * .96f, size.height * (.43f + liquidX * .06f), size.width * .72f, size.height * .57f, size.width * .50f, size.height * (.51f - liquidY * .04f))
                cubicTo(size.width * .28f, size.height * .47f, size.width * .05f, size.height * .36f, size.width * .18f, size.height * (.16f + liquidY * .04f))
                close()
            }
            drawPath(fluid, Brush.linearGradient(listOf(Color(0x1676B9FF), Color(0x129D8BFF), Color(0x0876B9FF))))
            drawPath(fluid, Color(0x0DFFFFFF), style = Stroke(width = 1.dp.toPx()))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x1A9D8BFF), Color.Transparent),
                    center = Offset(size.width * (1f - liquidX * 0.55f), size.height * (1f - liquidY * 0.35f)),
                    radius = radius * 0.78f
                ),
                radius = radius * 0.78f,
                center = Offset(size.width * (1f - liquidX * 0.55f), size.height * (1f - liquidY * 0.35f))
            )
        },
        state = listState,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 16.dp + com.oneuirepo.app.ui.LocalNavInset.current),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ---- 顶部：应用源动态小图标 + 通知入口
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AnimatedSourceButton { android.widget.Toast.makeText(context, "GitHub 仓库推荐与克隆功能即将开放", android.widget.Toast.LENGTH_SHORT).show() }
                Spacer(Modifier.weight(1f))
                SquareButton(IconKind.BELL) {
                    android.widget.Toast.makeText(context, "通知功能即将开放", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
        // ---- 搜索框
        item {
            Surface(
                onClick = onSearch, modifier = Modifier.fillMaxWidth(),
                shape = cardShape(22.dp), color = MaterialTheme.colorScheme.surface, border = cardBorder()
            ) {
                Row(Modifier.padding(horizontal = 18.dp).heightIn(min = 56.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppIcon(IconKind.SEARCH, MaterialTheme.colorScheme.onSurfaceVariant, 22.dp)
                    Spacer(Modifier.width(12.dp))
                    Text("搜索应用或开源项目", Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    AppIcon(IconKind.FILTER, MaterialTheme.colorScheme.onSurfaceVariant, 22.dp)
                }
            }
        }
        // ---- 探索新体验
        item {
            val heroTransition = rememberInfiniteTransition(label = "homeHeroLiquid")
            val heroShift by heroTransition.animateFloat(
                initialValue = -10f, targetValue = 10f,
                animationSpec = infiniteRepeatable(tween(3200), RepeatMode.Reverse), label = "heroLiquidShift"
            )
            Box(
                Modifier.fillMaxWidth().clip(cardShape(28.dp))
                    .background(Brush.linearGradient(
                        colors = listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.76f), Color(0xFFEAF4FF)),
                        start = Offset(heroShift, 0f), end = Offset(620f + heroShift, 520f)
                    ))
                    .clickable { android.widget.Toast.makeText(context, "探索功能即将开放", android.widget.Toast.LENGTH_SHORT).show() }.padding(22.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf(0xFF4F7CF7, 0xFF9B5CF0, 0xFFF5A33B, 0xFF2FC08A, 0xFFEE6FA0).forEach { c ->
                            Box(Modifier.size(15.dp).clip(CircleShape).background(Color(c)))
                        }
                    }
                    Text("探索新体验", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("发现优质开源项目与实用工具", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("立即探索", style = MaterialTheme.typography.titleSmall, color = primary, fontWeight = FontWeight.Bold)
                }
            }
        }
        // ---- 应用源：收起时固定展示原有六张卡片；展开后在最底部显示添加来源。
        item { SectionHeader("应用", if (moreSources) "收起" else "更多") { moreSources = !moreSources } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SourceTile("GitHub", IconKind.GITHUB, MaterialTheme.colorScheme.onSurface, false, Modifier.weight(1f)) { android.widget.Toast.makeText(context, "GitHub 仓库推荐与克隆功能即将开放", android.widget.Toast.LENGTH_SHORT).show() }
                    SourceTile("F-Droid", IconKind.CUBE, Color(0xFF2FA866), false, Modifier.weight(1f), onFdroid)
                    SourceTile("OneStore", IconKind.SERVER, primary, false, Modifier.weight(1f)) { android.widget.Toast.makeText(context, "oneStore 即将开放", android.widget.Toast.LENGTH_SHORT).show() }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SourceTile("Cloud Drive", IconKind.CLOUD, Color(0xFF4F8CF7), false, Modifier.weight(1f)) {
                        android.widget.Toast.makeText(context, "云盘源即将支持", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    SourceTile("ShizuStore", IconKind.SHIZUSTORE, Color(0xFF7654D6), false, Modifier.weight(1f), onShizuStore)
                    SourceTile("Other Stores", IconKind.STORE, Color(0xFF9B5CF0), false, Modifier.weight(1f)) { showStores = true }
                }
                if (moreSources) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SourceTile("添加来源", IconKind.PLUS_CIRCLE, MaterialTheme.colorScheme.onSurfaceVariant, false, Modifier.weight(1f)) {
                            android.widget.Toast.makeText(context, "添加来源功能即将开放", android.widget.Toast.LENGTH_SHORT).show()
                        }
                        Spacer(Modifier.weight(1f))
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        // ---- 工具
        // 工具区只展示工具入口卡片，不再复用热门仓库列表。
        // GitHub 登录后同步到数据库/收藏的普通应用不会被渲染到这里。
        item { SectionHeader("工具", if (hotAll) "收起" else "更多") { hotAll = !hotAll } }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                ShortcutRow(IconKind.DOWNLOAD, Color(0xFF2E9B5B), "热门工具", "工具推荐 · 版本与下载入口", false) {
                    android.widget.Toast.makeText(context, "工具入口即将开放", android.widget.Toast.LENGTH_SHORT).show()
                }
                ShortcutRow(IconKind.WRENCH, Color(0xFF4F6EF7), "实用工具", "独立工具 · 更新信息", false) {
                    android.widget.Toast.makeText(context, "工具入口即将开放", android.widget.Toast.LENGTH_SHORT).show()
                }
                if (hotAll) {
                    ShortcutRow(IconKind.SHIELD, Color(0xFF9B5CF0), "系统模块", "Shizuku · Magisk · LSPosed", false) {
                        android.widget.Toast.makeText(context, "系统模块入口即将开放", android.widget.Toast.LENGTH_SHORT).show()
                    }
                    ShortcutRow(IconKind.LAYERS, Color(0xFFF5A33B), "设备工具", "One UI · DeX · Fold", false) {
                        android.widget.Toast.makeText(context, "设备工具入口即将开放", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

    }

    if (showStores) {
        PickerSheet(
            title = "其他商店",
            options = listOf(
                PickerOption(0, "APKMirror · 三星应用", subtitle = "三星官方及相关应用的 APK 与历史版本", leading = "APK"),
                PickerOption(1, "APKMirror · 最新上传", subtitle = "最近上传的应用与版本", leading = "NEW")
            ),
            selectedKey = null,
            onSelect = {
                showStores = false
                when (it) {
                    0 -> openUrl("https://www.apkmirror.com/apk/samsung-electronics-co-ltd/")
                    1 -> openUrl("https://www.apkmirror.com/uploads/")
                }
            },
            onDismiss = { showStores = false }
        )
    }
}

@Composable
private fun AnimatedSourceButton(onClick: () -> Unit) {
    val sourceIcons = listOf(
        IconKind.GITHUB,
        IconKind.CUBE,
        IconKind.SERVER,
        IconKind.CLOUD,
        IconKind.STORE,
        IconKind.SHIZUSTORE,
        IconKind.PLUS_CIRCLE
    )
    var iconIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1350)
            iconIndex = (iconIndex + 1) % sourceIcons.size
        }
    }
    val transition = rememberInfiniteTransition(label = "sourceIconPulse")
    val scale by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(animation = tween(650), repeatMode = RepeatMode.Reverse),
        label = "sourceIconScale"
    )
    val rotation by transition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(animation = tween(900), repeatMode = RepeatMode.Reverse),
        label = "sourceIconRotation"
    )
    Surface(
        onClick = onClick, modifier = Modifier.size(52.dp), shape = cardShape(18.dp),
        color = MaterialTheme.colorScheme.surface, border = cardBorder(), shadowElevation = 1.dp
    ) {
        Box(contentAlignment = Alignment.Center) {
            AppIcon(
                sourceIcons[iconIndex],
                when (sourceIcons[iconIndex]) {
                    IconKind.CUBE -> Color(0xFF2FA866)
                    IconKind.SERVER -> Color(0xFF2E9B5B)
                    IconKind.CLOUD -> Color(0xFF4F8CF7)
                    IconKind.STORE -> Color(0xFF9B5CF0)
                    IconKind.PLUS_CIRCLE -> MaterialTheme.colorScheme.onSurfaceVariant
                    else -> MaterialTheme.colorScheme.onSurface
                },
                26.dp,
                Modifier.graphicsLayer { scaleX = scale; scaleY = scale; rotationZ = rotation }
            )
        }
    }
}

@Composable
private fun SquareButton(icon: IconKind, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = Modifier.size(52.dp), shape = cardShape(18.dp),
        color = MaterialTheme.colorScheme.surface, border = cardBorder(), shadowElevation = 1.dp
    ) { Box(contentAlignment = Alignment.Center) { AppIcon(icon, MaterialTheme.colorScheme.onSurface, 26.dp) } }
}

@Composable
private fun SectionHeader(title: String, link: String, onLink: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onBackground)
        Row(
            Modifier.clip(RoundedCornerShape(50)).clickable(onClick = onLink).padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(link, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.primary, 16.dp)
        }
    }
}

@Composable
private fun SourceTile(label: String, icon: IconKind, tint: Color, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Surface(
        onClick = onClick, modifier = modifier, shape = cardShape(20.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else MaterialTheme.colorScheme.surface,
        border = if (selected) androidx.compose.foundation.BorderStroke(1.5.dp, primary) else cardBorder()
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            AppIcon(icon, tint, 28.dp)
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

/** 一行：左边带色的图标块 + 标题 + 副标题（可选三个小圆点）+ 右箭头。 */
@Composable
private fun RowShell(tile: @Composable () -> Unit, title: String, subtitle: String, dots: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = cardShape(24.dp),
        color = MaterialTheme.colorScheme.surface, border = cardBorder()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            tile()
            Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                if (dots) {
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 2.dp)) {
                        listOf(0xFF4F7CF7, 0xFF9B5CF0, 0xFFF5A33B).forEach { c -> Box(Modifier.size(7.dp).clip(CircleShape).background(Color(c))) }
                    }
                }
            }
            AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onSurfaceVariant, 22.dp)
        }
    }
}

@Composable
private fun ShortcutRow(icon: IconKind, tint: Color, title: String, subtitle: String, dots: Boolean, onClick: () -> Unit) {
    RowShell(
        tile = {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(tint.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                AppIcon(icon, tint, 26.dp)
            }
        },
        title = title, subtitle = subtitle, dots = dots, onClick = onClick
    )
}

@Composable
private fun RepoRow(r: RepositoryEntity, dots: Boolean, onClick: () -> Unit) {
    RowShell(
        tile = {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                if (r.avatarUrl != null) AsyncImage(r.avatarUrl, null, Modifier.fillMaxSize())
                else Text(r.name.take(1).uppercase(), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        },
        title = r.name,
        subtitle = "★ ${r.stars} · " + (if (!r.language.isNullOrBlank()) r.language else r.owner),
        dots = dots, onClick = onClick
    )
}
