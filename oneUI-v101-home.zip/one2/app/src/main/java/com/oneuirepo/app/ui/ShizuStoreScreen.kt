package com.oneuirepo.app.ui

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import coil3.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private const val SHIZU_API_BASE = "https://shizustore.timschneeberger.me"
private const val SHIZU_SITE_BASE = "https://shizustore.com"
private val shizuJson = Json { ignoreUnknownKeys = true; coerceInputValues = true }

@Serializable
private data class ShizuApiPage(val items: List<ShizuApiApp> = emptyList(), val total: Int = 0)

@Serializable
private data class ShizuApiApp(
    val slug: String,
    val name: String = "",
    val description: String = "",
    val versionName: String? = null,
    val iconHash: String? = null,
    val categorySlug: String = "",
    val updatedAt: String = "",
    val url: String? = null,
    val sourceUrl: String? = null,
    val stars: Int? = null,
    val downloadTotal: Long? = null,
    val fullDescription: String? = null,
    val downloads: List<ShizuApiDownload> = emptyList(),
    val categoryPath: List<ShizuApiCategory> = emptyList(),
    val changelog: String? = null,
    val changelogUrl: String? = null,
    val screenshots: List<String> = emptyList(),
    val authorUrl: String? = null,
    val readmeUrl: String? = null,
    val license: String? = null,
    val author: String? = null,
    val downloadCount: Long? = null
)

@Serializable
private data class ShizuApiDownload(
    val apkUrl: String,
    val versionName: String? = null,
    val primary: Boolean = false
)

@Serializable
private data class ShizuApiCategory(val slug: String, val name: String = "", val children: List<ShizuApiCategory> = emptyList())

private data class ShizuApp(
    val name: String,
    val description: String,
    val url: String,
    val icon: String = "",
    val stars: String = "",
    val category: String = "",
    val updated: String = "",
    val downloadUrl: String = "",
    val downloadTotal: Long? = null
)

private data class ShizuDetail(
    val app: ShizuApp,
    val longDescription: String,
    val repositoryUrl: String,
    val downloadUrl: String,
    val websiteUrl: String,
    val version: String,
    val changelog: String,
    val screenshots: List<String> = emptyList(),
    val license: String = "",
    val author: String = "",
    val updated: String = "",
    val downloads: List<ShizuApiDownload> = emptyList()
)

/** Native Compose catalog UI. Content is read from ShizuStore's public server-rendered catalog. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShizuStoreScreen(onClose: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    DisposableEffect(view) {
        var ctx = view.context
        while (ctx is android.content.ContextWrapper && ctx !is android.app.Activity) ctx = ctx.baseContext
        val window = (ctx as? android.app.Activity)?.window
        val oldStatusColor = window?.statusBarColor
        val oldDecorBackground = window?.decorView?.background
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        val oldLightStatusIcons = controller?.isAppearanceLightStatusBars
        // Keep the system status-bar inset and the ShizuStore canvas on the same white surface.
        // On edge-to-edge Android versions, statusBarColor alone may be ignored, so also paint
        // the window decor background to avoid a contrasting strip above the app bar.
        if (window != null) {
            window.statusBarColor = android.graphics.Color.WHITE
            window.decorView.setBackgroundColor(android.graphics.Color.WHITE)
        }
        if (controller != null) controller.isAppearanceLightStatusBars = true
        onDispose {
            if (window != null && oldStatusColor != null) window.statusBarColor = oldStatusColor
            if (window != null && oldDecorBackground != null) window.decorView.background = oldDecorBackground
            if (controller != null && oldLightStatusIcons != null) controller.isAppearanceLightStatusBars = oldLightStatusIcons
        }
    }
    val scope = rememberCoroutineScope()
    val wide = LocalConfiguration.current.screenWidthDp >= 700
    var apps by remember { mutableStateOf<List<ShizuApp>>(emptyList()) }
    var availableCategories by remember { mutableStateOf<List<String>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var categoryQuery by remember { mutableStateOf("") }
    var showCategoryDrawer by remember { mutableStateOf(false) }
    var category by remember { mutableStateOf("全部") }
    var sort by remember { mutableStateOf("热门") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<ShizuDetail?>(null) }
    var detailLoading by remember { mutableStateOf(false) }
    var detailError by remember { mutableStateOf("") }

    fun loadCatalog() {
        scope.launch {
            loading = true; error = ""
            try {
                val result = withContext(Dispatchers.IO) { fetchShizuCatalog() }
                apps = result
                availableCategories = withContext(Dispatchers.IO) { runCatching { fetchShizuCategoryNames() }.getOrDefault(emptyList()) }
                if (apps.isEmpty()) error = "暂时没有读取到应用列表，请检查网络后刷新。"
            }
            catch (_: Exception) { error = "加载失败，请检查网络后重试。" }
            finally { loading = false }
        }
    }
    fun openDetail(app: ShizuApp) {
        scope.launch {
            selected = ShizuDetail(app, app.description, "", "", "", "", "")
            detailLoading = true; detailError = ""
            try { selected = withContext(Dispatchers.IO) { fetchShizuDetail(app) } }
            catch (_: Exception) { detailError = "详情暂时无法加载，仍可查看应用的上游页面。" }
            finally { detailLoading = false }
        }
    }
    LaunchedEffect(Unit) { loadCatalog() }
    BackHandler(enabled = selected != null || showCategoryDrawer) {
        if (showCategoryDrawer) showCategoryDrawer = false else selected = null
    }

    val categories = remember(apps, availableCategories) {
        listOf("全部") + (availableCategories.ifEmpty { apps.map { it.category }.filter { it.isNotBlank() }.distinct() }).distinct().sorted()
    }
    val shown = remember(apps, query, category, sort) {
        val filtered = apps.filter { (query.isBlank() || (it.name + " " + it.description + " " + it.category).contains(query, true)) && (category == "全部" || it.category == category) }
        when (sort) {
            "名称" -> filtered.sortedBy { it.name.lowercase() }
            "最近更新" -> filtered.sortedByDescending { it.updated }
            else -> filtered.sortedByDescending { parseStars(it.stars) }
        }
    }
    val shownRows = remember(shown) { shown.chunked(2) }

    Scaffold(
        containerColor = Color.White,
        topBar = {
            if (selected != null) {
                TopAppBar(
                    title = { Text(selected!!.app.name, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color(0xFF202124), fontWeight = FontWeight.SemiBold) },
                    navigationIcon = {
                        IconButton(onClick = { selected = null }) {
                            Text("‹", color = Color(0xFF202124), style = MaterialTheme.typography.headlineMedium)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White),
                    windowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp)
                )
            }
        },
        bottomBar = {
            val detail = selected
            if (detail != null) {
                Surface(color = Color.White, shadowElevation = 10.dp, tonalElevation = 0.dp) {
                    Column(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = if (wide) 28.dp else 16.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (detail.downloadUrl.isNotBlank()) {
                                Button(
                                    onClick = { downloadShizuApk(context, detail.downloadUrl, detail.app.name, detail.version) },
                                    modifier = Modifier.weight(1f).heightIn(min = 50.dp),
                                    shape = RoundedCornerShape(16.dp)
                                ) { Text("下载 APK", fontWeight = FontWeight.SemiBold) }
                            }
                            OutlinedButton(
                                onClick = { openUrl(context, detail.app.url) },
                                modifier = Modifier.weight(1f).heightIn(min = 50.dp),
                                shape = RoundedCornerShape(16.dp),
                                border = BorderStroke(1.dp, Color(0xFFE2E5EA))
                            ) { Text("查看官方详情", maxLines = 1) }
                        }
                        Text(
                            if (detail.downloadUrl.isBlank()) "该项目暂未提供直接 APK 下载，请通过官方详情页获取。" else "APK 由上游项目提供，请确认来源与权限。",
                            modifier = Modifier.fillMaxWidth(), style = MaterialTheme.typography.labelSmall, color = Color(0xFF858A92)
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize()) {
        if (selected != null) {
            val detail = selected!!
            LazyColumn(Modifier.fillMaxSize().background(Color.White).padding(padding), contentPadding = PaddingValues(horizontal = if (wide) 28.dp else 16.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(28.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE8EAEE)),
                        tonalElevation = 0.dp
                    ) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                AppIcon(detail.app.icon, Modifier.size(88.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    Text(detail.app.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                                    if (detail.app.category.isNotBlank()) {
                                        Surface(shape = RoundedCornerShape(50), color = Color(0xFFF0F3F8)) {
                                            Text(detail.app.category, Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium, color = Color(0xFF536273), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        if (detail.app.stars.isNotBlank()) Text("★ ${detail.app.stars}", style = MaterialTheme.typography.labelMedium, color = Color(0xFF777B82))
                                        if (detail.version.isNotBlank()) Text("版本 ${detail.version}", style = MaterialTheme.typography.labelMedium, color = Color(0xFF777B82))
                                    }
                                }
                            }
                            HorizontalDivider(color = Color(0xFFF0F1F3))
                            Text(detail.app.description.ifBlank { "查看应用介绍、版本信息与上游下载来源。" }, style = MaterialTheme.typography.bodyLarge, color = Color(0xFF555B65))
                        }
                    }
                }
                if (detailLoading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                if (detailError.isNotBlank()) item { Text(detailError, color = Color(0xFFB3261E)) }
                if (detail.screenshots.isNotEmpty()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("应用截图", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(end = 4.dp)) {
                            items(detail.screenshots) { screenshot ->
                                Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFF4F5F7), border = BorderStroke(1.dp, Color(0xFFE8EAEE)), modifier = Modifier.width(if (wide) 260.dp else 220.dp).height(if (wide) 340.dp else 300.dp).clickable { openUrl(context, screenshot) }) {
                                    AsyncImage(model = screenshot, contentDescription = "${detail.app.name} 应用截图", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                }
                            }
                        }
                        Text("左右滑动查看截图，点击可打开原图。", style = MaterialTheme.typography.labelSmall, color = Color(0xFF858A92))
                    }
                }
                if (detail.version.isNotBlank() || detail.updated.isNotBlank() || detail.license.isNotBlank() || detail.author.isNotBlank()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("应用信息", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                        Surface(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), color = Color(0xFFF7F8FA), border = BorderStroke(1.dp, Color(0xFFE8EAEE))) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                if (detail.version.isNotBlank()) DetailInfoRow("当前版本", detail.version)
                                if (detail.updated.isNotBlank()) DetailInfoRow("最近更新", detail.updated.take(10))
                                if (detail.author.isNotBlank()) DetailInfoRow("开发者", detail.author)
                                if (detail.license.isNotBlank()) DetailInfoRow("开源许可证", detail.license)
                            }
                        }
                    }
                }
                if (detail.app.downloadTotal != null || detail.app.stars.isNotBlank()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("项目数据", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (detail.app.downloadTotal != null) DetailStatCard("ShizuStore 下载", formatShizuCount(detail.app.downloadTotal), Modifier.weight(1f))
                            if (detail.app.stars.isNotBlank()) DetailStatCard("GitHub Stars", detail.app.stars, Modifier.weight(1f))
                        }
                    }
                }
                if (detail.longDescription.isNotBlank()) item { DetailSection("应用介绍", detail.longDescription.take(1400).let { if (detail.longDescription.length > 1400) "$it\n\n…内容已精简，请查看官方页面了解完整介绍。" else it }) }
                if (detail.changelog.isNotBlank()) item { DetailSection("更新日志", detail.changelog.take(800).let { if (detail.changelog.length > 800) "$it\n\n…更多更新内容请查看官方页面。" else it }) }
                if (false && detail.downloads.isNotEmpty()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("下载版本与渠道", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                        detail.downloads.forEachIndexed { index, source ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                color = Color(0xFFF7F8FA),
                                border = BorderStroke(1.dp, Color(0xFFE8EAEE))
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Text(source.versionName?.takeIf { it.isNotBlank() } ?: "版本 ${index + 1}", fontWeight = FontWeight.SemiBold, color = Color(0xFF202124))
                                        Text(if (source.primary) "推荐下载 · 官方主版本" else "上游提供的安装包", style = MaterialTheme.typography.labelSmall, color = Color(0xFF777B82))
                                    }
                                    Button(
                                        onClick = { downloadShizuApk(context, source.apkUrl, detail.app.name, source.versionName.orEmpty()) },
                                        enabled = source.apkUrl.isNotBlank(),
                                        shape = RoundedCornerShape(12.dp),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                    ) { Text(if (source.primary) "下载" else "选择") }
                                }
                            }
                        }
                    }
                }
                if (detail.repositoryUrl.isNotBlank() || detail.websiteUrl.isNotBlank()) item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("相关链接", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                        if (detail.websiteUrl.isNotBlank()) OutlinedButton(onClick = { openUrl(context, detail.websiteUrl) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("打开项目主页") }
                        if (detail.repositoryUrl.isNotBlank()) OutlinedButton(onClick = { openUrl(context, detail.repositoryUrl) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("查看开源仓库") }
                    }
                }
                item { Spacer(Modifier.height(4.dp)) }
            }
        } else {
            val pageHorizontal = if (wide) 28.dp else 16.dp
            LazyColumn(
                modifier = Modifier.fillMaxSize().background(Color.White).padding(padding),
                contentPadding = PaddingValues(start = pageHorizontal, end = pageHorizontal, top = 8.dp, bottom = 112.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = onClose,
                            shape = RoundedCornerShape(50),
                            color = Color(0xFFF5F6F8),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("‹", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF202124))
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color(0xFFF5F6F8),
                            border = BorderStroke(1.dp, Color(0xFFE7E9ED)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(9.dp)
                            ) {
                                Text("⌕", style = MaterialTheme.typography.titleLarge, color = Color(0xFF777B82))
                                Box(Modifier.weight(1f)) {
                                    if (query.isBlank()) Text("搜索应用或分类", color = Color(0xFF8A8F98), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                                    BasicTextField(
                                        value = query,
                                        onValueChange = { query = it },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF202124))
                                    )
                                }
                                if (query.isNotBlank()) {
                                    Text("×", modifier = Modifier.clickable { query = "" }.padding(horizontal = 2.dp), color = Color(0xFF315D9B), style = MaterialTheme.typography.titleMedium)
                                }
                            }
                        }
                        Surface(
                            onClick = { showCategoryDrawer = true },
                            shape = RoundedCornerShape(50),
                            color = Color(0xFFE7EFFB),
                            border = BorderStroke(1.dp, Color(0xFFD6E2F4)),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("☷", style = MaterialTheme.typography.titleLarge, color = Color(0xFF244B82))
                            }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(if (category == "全部") "全部应用" else category, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                            Text("从右上角分类按钮切换分类", style = MaterialTheme.typography.bodySmall, color = Color(0xFF777B82))
                        }
                        Text("${shown.size} 个应用", style = MaterialTheme.typography.labelMedium, color = Color(0xFF777B82))
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("应用列表", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF202124), modifier = Modifier.weight(1f))
                        listOf("热门", "最近更新", "名称").forEach { option ->
                            val active = sort == option
                            Surface(
                                onClick = { sort = option },
                                shape = RoundedCornerShape(12.dp),
                                color = if (active) Color(0xFFE7EFFB) else Color(0xFFF5F6F8),
                                border = BorderStroke(1.dp, if (active) Color(0xFFB9CBE7) else Color(0xFFE7E9ED))
                            ) {
                                Text(option, Modifier.padding(horizontal = 10.dp, vertical = 8.dp), style = MaterialTheme.typography.labelSmall, color = if (active) Color(0xFF244B82) else Color(0xFF555B65), fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
                            }
                        }
                    }
                }
                when {
                    loading && apps.isEmpty() -> item { Box(Modifier.fillMaxWidth().height(340.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color(0xFF315D9B)) } }
                    error.isNotBlank() && apps.isEmpty() -> item { Box(Modifier.fillMaxWidth().padding(vertical = 30.dp), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) { Text(error, color = Color(0xFF5F6368)); Button(onClick = { loadCatalog() }) { Text("重新加载") } } } }
                    shown.isEmpty() -> item { Box(Modifier.fillMaxWidth().height(180.dp), contentAlignment = Alignment.Center) { Text("没有找到匹配的应用", color = Color(0xFF777B82)) } }
                    else -> {
                        // Render only visible rows. Previously every card was composed inside one item,
                        // causing the entire catalog to build at once and making scrolling stutter.
                        items(
                            items = shownRows,
                            key = { group -> group.joinToString(separator = "|") { it.url } }
                        ) { group ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                group.forEach { app ->
                                    AppCard(
                                        app = app,
                                        modifier = Modifier.weight(1f),
                                        onClick = ::openDetail,
                                        onDownload = { item ->
                                            // Keep the card's download action independent from the card click.
                                            // Resolve the detail endpoint when the catalog has no direct APK URL.
                                            if (item.downloadUrl.isNotBlank()) {
                                                downloadShizuApk(context, item.downloadUrl, item.name, "")
                                            } else {
                                                scope.launch {
                                                    try {
                                                        val detail = withContext(Dispatchers.IO) { fetchShizuDetail(item) }
                                                        if (detail.downloadUrl.isNotBlank()) {
                                                            downloadShizuApk(context, detail.downloadUrl, item.name, detail.version)
                                                        } else {
                                                            openUrl(context, item.url)
                                                        }
                                                    } catch (_: Exception) {
                                                        openUrl(context, item.url)
                                                    }
                                                }
                                            }
                                        }
                                    )
                                }
                                if (group.size == 1) Spacer(Modifier.weight(1f))
                            }
                        }
                        item {
                            Text("上下滑动浏览应用 · 点击下载获取 APK", modifier = Modifier.fillMaxWidth().padding(top = 2.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A8F98))
                        }
                    }
                }
            }
        }
        if (selected == null) {
            Box(Modifier.fillMaxSize()) {
                AnimatedVisibility(visible = showCategoryDrawer, enter = fadeIn(), exit = fadeOut()) {
                    Box(
                        Modifier.fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.30f))
                            .clickable { showCategoryDrawer = false }
                    )
                }
                AnimatedVisibility(
                    visible = showCategoryDrawer,
                    enter = slideInHorizontally(initialOffsetX = { it }),
                    exit = slideOutHorizontally(targetOffsetX = { it }),
                    modifier = Modifier.align(Alignment.CenterEnd)
                ) {
                    Surface(
                        modifier = Modifier.fillMaxHeight().width(if (wide) 340.dp else 300.dp),
                        shape = RoundedCornerShape(topStart = 26.dp, bottomStart = 26.dp),
                        color = Color(0xF2FFFFFF),
                        border = BorderStroke(1.dp, Color(0xD9FFFFFF)),
                        tonalElevation = 0.dp,
                        shadowElevation = 16.dp
                    ) {
                        Column(Modifier.fillMaxSize().background(Color(0xDFFFFFFF)).statusBarsPadding().navigationBarsPadding()) {
                            Row(
                                Modifier.fillMaxWidth().padding(start = 20.dp, end = 12.dp, top = 18.dp, bottom = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text("全部分类", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
                                    Text("${(categories.size - 1).coerceAtLeast(0)} 个分类", style = MaterialTheme.typography.bodySmall, color = Color(0xFF777B82))
                                }
                                IconButton(onClick = { loadCatalog() }) { Text("↻", color = Color(0xFF315D9B), style = MaterialTheme.typography.titleLarge) }
                                IconButton(onClick = { showCategoryDrawer = false }) { Text("×", color = Color(0xFF202124), style = MaterialTheme.typography.titleLarge) }
                            }
                            Surface(
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                                shape = RoundedCornerShape(16.dp),
                                color = Color(0xFFF5F6F8),
                                border = BorderStroke(1.dp, Color(0xFFE7E9ED))
                            ) {
                                Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("⌕", style = MaterialTheme.typography.titleMedium, color = Color(0xFF777B82))
                                    Box(Modifier.weight(1f)) {
                                        if (categoryQuery.isBlank()) Text("搜索分类", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF8A8F98))
                                        BasicTextField(categoryQuery, { categoryQuery = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), textStyle = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF202124)))
                                    }
                                    if (categoryQuery.isNotBlank()) Text("×", Modifier.clickable { categoryQuery = "" }, color = Color(0xFF315D9B))
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                val drawerCategories = categories.filter { categoryQuery.isBlank() || it.contains(categoryQuery, true) }
                                items(drawerCategories) { item ->
                                    val active = category == item
                                    val count = if (item == "全部") apps.size else apps.count { it.category == item }
                                    Surface(
                                        onClick = {
                                            category = item
                                            categoryQuery = ""
                                            showCategoryDrawer = false
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(14.dp),
                                        color = if (active) Color(0xFFE7EFFB) else Color.Transparent
                                    ) {
                                        Row(
                                            Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(horizontal = 12.dp, vertical = 9.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            Box(
                                                Modifier.size(34.dp).clip(RoundedCornerShape(11.dp)).background(if (active) Color(0xFFD3E2F8) else Color(0xFFF1F2F4)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(if (item == "全部") "▦" else item.take(1), color = if (active) Color(0xFF244B82) else Color(0xFF555B65), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                            }
                                            Text(item, modifier = Modifier.weight(1f), color = if (active) Color(0xFF244B82) else Color(0xFF30343A), style = MaterialTheme.typography.bodyMedium, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                            Text(count.toString(), color = Color(0xFF8A8F98), style = MaterialTheme.typography.labelSmall)
                                            if (active) Text("✓", color = Color(0xFF315D9B), style = MaterialTheme.typography.titleSmall)
                                        }
                                    }
                                }
                                if (drawerCategories.isEmpty()) item { Text("没有匹配的分类", Modifier.fillMaxWidth().padding(24.dp), color = Color(0xFF777B82)) }
                            }
                        }
                    }
                }
            }
        }
        }
    }
}

@Composable
private fun AppCard(app: ShizuApp, modifier: Modifier = Modifier, onClick: (ShizuApp) -> Unit, onDownload: (ShizuApp) -> Unit) {
    Surface(
        modifier = modifier.clickable { onClick(app) },
        shape = RoundedCornerShape(20.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFE8EAEE)),
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppIcon(app.icon, Modifier.size(44.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(app.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Color(0xFF202124), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (app.category.isNotBlank()) {
                        Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFFF0F3F8)) {
                            Text(app.category, Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, color = Color(0xFF536273), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            Text(app.description.ifBlank { "查看应用介绍、版本信息与上游下载来源" }, style = MaterialTheme.typography.bodySmall, color = Color(0xFF686D75), minLines = 1, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (app.stars.isNotBlank()) Text("★ ${app.stars}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF777B82), maxLines = 1)
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = { onDownload(app) },
                    modifier = Modifier.heightIn(min = 36.dp),
                    contentPadding = PaddingValues(horizontal = 11.dp, vertical = 5.dp),
                    shape = RoundedCornerShape(11.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFE7EFFB),
                        contentColor = Color(0xFF244B82)
                    )
                ) {
                    Text("下载", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun AppIcon(url: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(15.dp), color = Color(0xFFF0F3F8)) {
        if (url.isNotBlank()) AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxSize().padding(4.dp).clip(RoundedCornerShape(15.dp)))
        else Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("S", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = Color(0xFF315D9B)) }
    }
}

private data class MarkdownBlock(val type: String, val text: String)

private fun parseMarkdown(content: String): List<MarkdownBlock> {
    val result = mutableListOf<MarkdownBlock>()
    val code = mutableListOf<String>()
    var inCode = false
    content.replace("\r\n", "\n").lines().forEach { raw ->
        val line = raw.trimEnd()
        val value = line.trim()
        when {
            value.startsWith("```") -> {
                if (inCode && code.isNotEmpty()) result += MarkdownBlock("code", code.joinToString("\n"))
                code.clear()
                inCode = !inCode
            }
            inCode -> code += line
            value.isBlank() -> Unit
            value.matches(Regex("^!\\[[^]]*]\\(.*\\)$")) -> Unit
            value.startsWith("# ") -> result += MarkdownBlock("h1", value.removePrefix("# ").trim())
            value.startsWith("## ") -> result += MarkdownBlock("h2", value.removePrefix("## ").trim())
            value.startsWith("### ") -> result += MarkdownBlock("h3", value.removePrefix("### ").trim())
            value.matches(Regex("^[-*_]{3,}$")) -> result += MarkdownBlock("divider", "")
            value.startsWith(">") -> result += MarkdownBlock("quote", cleanMarkdown(value.removePrefix(">").trim()))
            value.startsWith("- ") || value.startsWith("* ") || value.startsWith("+ ") -> result += MarkdownBlock("bullet", cleanMarkdown(value.drop(2)))
            value.matches(Regex("^\\d+[.)]\\s+.*")) -> result += MarkdownBlock("bullet", cleanMarkdown(value.replaceFirst(Regex("^\\d+[.)]\\s+"), "")))
            else -> result += MarkdownBlock("text", cleanMarkdown(value))
        }
    }
    if (code.isNotEmpty()) result += MarkdownBlock("code", code.joinToString("\n"))
    return result
}

@Composable
private fun DetailStatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFF7F8FA),
        border = BorderStroke(1.dp, Color(0xFFE8EAEE))
    ) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF202124), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF777B82), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun formatShizuCount(value: Long): String = when {
    value >= 1_000_000 -> String.format(java.util.Locale.ROOT, "%.1fM", value / 1_000_000.0)
    value >= 1_000 -> String.format(java.util.Locale.ROOT, "%.1fk", value / 1_000.0)
    else -> value.toString()
}

@Composable
private fun DetailInfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.Top) {
        Text(label, modifier = Modifier.width(88.dp), style = MaterialTheme.typography.bodyMedium, color = Color(0xFF777B82))
        Text(value, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = Color(0xFF303640), fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DetailSection(title: String, content: String) {
    val blocks = remember(content) { parseMarkdown(content) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124))
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(22.dp),
            color = Color(0xFFF7F8FA),
            border = BorderStroke(1.dp, Color(0xFFE8EAEE))
        ) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                blocks.forEach { block ->
                    when (block.type) {
                        "h1" -> Text(block.text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color(0xFF202124), modifier = Modifier.padding(top = 6.dp))
                        "h2" -> Text(block.text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF303640), modifier = Modifier.padding(top = 6.dp))
                        "h3" -> Text(block.text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Color(0xFF303640), modifier = Modifier.padding(top = 4.dp))
                        "divider" -> HorizontalDivider(color = Color(0xFFE0E4E9))
                        "quote" -> Text(block.text, modifier = Modifier.fillMaxWidth().padding(start = 10.dp), style = MaterialTheme.typography.bodyMedium, color = Color(0xFF626B77))
                        "bullet" -> Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.Top) {
                            Text("•", color = Color(0xFF536D91), fontWeight = FontWeight.Bold)
                            Text(block.text, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4F5661))
                        }
                        "code" -> Surface(shape = RoundedCornerShape(12.dp), color = Color(0xFFECEFF3)) {
                            Text(block.text, Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(12.dp), style = MaterialTheme.typography.bodySmall, color = Color(0xFF39424E))
                        }
                        else -> Text(block.text, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF4F5661), lineHeight = MaterialTheme.typography.bodyMedium.lineHeight * 1.15f)
                    }
                }
            }
        }
    }
}

private fun cleanMarkdown(value: String): String = value
    .replace(Regex("\\[!\\[([^]]*)]\\([^)]*\\)]\\([^)]*\\)"), "")
    .replace(Regex("!\\[([^]]*)]\\([^)]*\\)"), "")
    .replace(Regex("\\[([^]]+)]\\(([^)]+)\\)"), "$1 ($2)")
    .replace(Regex("`([^`]+)`"), "$1")
    .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
    .replace(Regex("(?<!\\*)\\*([^*]+)\\*"), "$1")
    .trim()

private fun openUrl(context: Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

private fun downloadShizuApk(context: Context, url: String, appName: String, version: String) {
    runCatching {
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("$appName${version.takeIf { it.isNotBlank() }?.let { " $it" }.orEmpty()}")
            .setDescription("从 ShizuStore 上游来源下载 APK")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setMimeType("application/vnd.android.package-archive")
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        manager.enqueue(request)
        Toast.makeText(context, "已加入下载队列，可在通知栏查看进度", Toast.LENGTH_LONG).show()
    }.onFailure {
        Toast.makeText(context, "下载启动失败：${it.message ?: "请检查下载链接"}", Toast.LENGTH_LONG).show()
    }
}

private fun parseStars(value: String): Double {
    val normalized = value.trim().replace(",", "")
    val number = normalized.removeSuffix("k").removeSuffix("K").toDoubleOrNull() ?: return 0.0
    return if (normalized.endsWith("k", true)) number * 1000.0 else number
}

private fun apiGet(path: String): String {
    val connection = (URL(SHIZU_API_BASE + path).openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 15000
        readTimeout = 20000
        setRequestProperty("Accept", "application/json")
        setRequestProperty("User-Agent", "OneStore-Android/ShizuStore")
        instanceFollowRedirects = true
    }
    try {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("ShizuStore API HTTP $code${body.take(160).takeIf { it.isNotBlank() }?.let { ": $it" }.orEmpty()}")
        return body
    } finally { connection.disconnect() }
}

private fun fetchShizuCategoryNames(): List<String> {
    val roots = shizuJson.decodeFromString<List<ShizuApiCategory>>(apiGet("/v1/categories"))
    val leaves = mutableListOf<String>()
    fun collect(nodes: List<ShizuApiCategory>) {
        nodes.forEach { node ->
            if (node.children.isEmpty()) leaves += node.name.ifBlank { node.slug }
            else collect(node.children)
        }
    }
    collect(roots)
    return leaves.filter { it.isNotBlank() }.distinct().sorted()
}

private fun fetchShizuCatalog(): List<ShizuApp> {
    val categoryNames = mutableMapOf<String, String>()
    runCatching {
        val roots = shizuJson.decodeFromString<List<ShizuApiCategory>>(apiGet("/v1/categories"))
        fun add(nodes: List<ShizuApiCategory>) { nodes.forEach { node -> categoryNames[node.slug] = node.name.ifBlank { node.slug }; add(node.children) } }
        add(roots)
    }
    val all = mutableListOf<ShizuApiApp>()
    var page = 1
    var total = Int.MAX_VALUE
    while (all.size < total && page <= 100) {
        val response = shizuJson.decodeFromString<ShizuApiPage>(apiGet("/v1/apps?page=$page&pageSize=100&sort=name&order=asc"))
        total = response.total
        if (response.items.isEmpty()) break
        all += response.items
        page++
    }
    if (all.isEmpty()) throw IllegalStateException("官方服务器返回了空应用列表")
    return all.distinctBy { it.slug }.map { app ->
        val category = categoryNames[app.categorySlug].orEmpty().ifBlank { app.categorySlug.replace('-', ' ').replaceFirstChar { it.uppercase() } }
        ShizuApp(
            name = app.name.ifBlank { app.slug },
            description = app.description,
            url = "$SHIZU_SITE_BASE/apps/${app.slug}",
            icon = app.iconHash?.takeIf { it.isNotBlank() }?.let { "$SHIZU_API_BASE/icons/$it.png" }.orEmpty(),
            stars = app.stars?.toString().orEmpty(),
            category = category,
            updated = app.updatedAt,
            downloadUrl = (app.downloads.firstOrNull { it.primary } ?: app.downloads.firstOrNull())?.apkUrl.orEmpty(),
            downloadTotal = app.downloadTotal ?: app.downloadCount
        )
    }
}

private fun normalizeShizuMediaUrl(value: String): String? {
    val candidate = value.trim()
    if (candidate.isBlank()) return null
    return when {
        candidate.startsWith("https://") || candidate.startsWith("http://") -> candidate
        candidate.startsWith("/") -> SHIZU_API_BASE + candidate
        else -> "$SHIZU_API_BASE/$candidate"
    }
}

private fun fetchShizuDetail(app: ShizuApp): ShizuDetail {
    val slug = Uri.parse(app.url).lastPathSegment?.takeIf { it.isNotBlank() }
        ?: throw IllegalArgumentException("无效的应用标识")
    val encodedSlug = URLEncoder.encode(slug, "UTF-8").replace("+", "%20")
    val dto = shizuJson.decodeFromString<ShizuApiApp>(apiGet("/v1/apps/$encodedSlug"))
    val category = dto.categoryPath.joinToString(" / ") { it.name }.ifBlank { app.category }
    val merged = app.copy(
        name = dto.name.ifBlank { app.name },
        description = dto.description.ifBlank { app.description },
        icon = dto.iconHash?.takeIf { it.isNotBlank() }?.let { "$SHIZU_API_BASE/icons/$it.png" }.orEmpty().ifBlank { app.icon },
        category = category,
        stars = dto.stars?.toString().orEmpty().ifBlank { app.stars },
        downloadTotal = dto.downloadTotal ?: dto.downloadCount ?: app.downloadTotal
    )
    val download = dto.downloads.firstOrNull { it.primary }?.apkUrl
        ?: dto.downloads.firstOrNull()?.apkUrl.orEmpty()
    val repo = dto.sourceUrl.orEmpty()
    val website = dto.url.orEmpty().takeIf { it != repo && it.startsWith("http") }.orEmpty()
    val version = dto.versionName.orEmpty().ifBlank { dto.downloads.firstOrNull { it.primary }?.versionName.orEmpty() }
    return ShizuDetail(
        app = merged,
        longDescription = dto.fullDescription?.takeIf { it.isNotBlank() } ?: dto.description,
        repositoryUrl = repo,
        downloadUrl = download,
        websiteUrl = website,
        version = version,
        changelog = dto.changelog.orEmpty().ifBlank { dto.changelogUrl.orEmpty() },
        screenshots = dto.screenshots.mapNotNull { normalizeShizuMediaUrl(it) }.distinct(),
        license = dto.license.orEmpty(),
        author = dto.author.orEmpty(),
        updated = dto.updatedAt.ifBlank { app.updated },
        downloads = dto.downloads
    )
}
