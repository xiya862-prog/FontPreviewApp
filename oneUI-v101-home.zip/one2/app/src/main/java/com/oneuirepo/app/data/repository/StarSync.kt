package com.oneuirepo.app.data.repository

import android.content.Context
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.FavoriteEntity
import com.oneuirepo.app.data.remote.GitHubApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext

/**
 * 把登录账号在 GitHub 上的星标仓库自动同步进本地「收藏」（只增不减）。
 * 已经同步过的仓库 id 记在本机，所以你之后手动取消的收藏不会被再次加回来。
 */
class StarSync(
    private val ctx: Context,
    private val repo: GitHubRepository,
    private val db: AppDatabase,
    private val api: GitHubApi
) {
    /** 返回这次新加入收藏的数量；正在同步中或网络出错返回 0。 */
    suspend fun run(maxPages: Int = 5): Int = withContext(Dispatchers.IO) {
        if (!lock.tryLock()) return@withContext 0
        try {
            val prefs = ctx.getSharedPreferences("star_sync", Context.MODE_PRIVATE)
            val done = HashSet(prefs.getStringSet("ids", emptySet()) ?: emptySet())
            var added = 0
            var page = 1
            while (page <= maxPages) {
                val list = api.getStarred(100, page)
                for (d in list) {
                    val key = d.id.toString()
                    if (key in done) continue
                    if (db.repositoryDao().findById(d.id) == null) {
                        try { repo.importRemote(d) } catch (_: Exception) { continue }
                    }
                    db.favoriteDao().add(FavoriteEntity(d.id, System.currentTimeMillis()))
                    done.add(key)
                    added++
                    prefs.edit().putStringSet("ids", HashSet(done)).apply()
                }
                if (list.size < 100) break
                page++
            }
            added
        } catch (_: Exception) {
            0
        } finally {
            lock.unlock()
        }
    }

    companion object { private val lock = Mutex() }
}
