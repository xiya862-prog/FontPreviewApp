package com.oneuirepo.app.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sync_states (repositoryId INTEGER NOT NULL PRIMARY KEY, etag TEXT, lastCheckedAt INTEGER NOT NULL)")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS cves (id TEXT NOT NULL PRIMARY KEY, summary TEXT NOT NULL, severity TEXT, cvss REAL, publishedAt TEXT, modifiedAt TEXT, affectedVersions TEXT NOT NULL, fixedVersions TEXT NOT NULL, `references` TEXT NOT NULL, sourceUrl TEXT, syncedAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS repository_cve_cross_ref (repositoryId INTEGER NOT NULL, cveId TEXT NOT NULL, PRIMARY KEY(repositoryId,cveId))")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS view_history (repositoryId INTEGER NOT NULL PRIMARY KEY, viewedAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS discovered (repositoryId INTEGER NOT NULL PRIMARY KEY)")
    }
}

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS manual_category (repositoryId INTEGER NOT NULL, categoryId TEXT NOT NULL, PRIMARY KEY(repositoryId, categoryId))")
        // 「折叠屏」分类改名为 Fold
        db.execSQL("UPDATE OR REPLACE repository_category_cross_ref SET categoryId='Fold' WHERE categoryId='折叠屏'")
        db.execSQL("DELETE FROM categories WHERE id='折叠屏'")
    }
}

val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        // 取消自动识别：清掉自动归类产生的内置分类，只保留用户手动选择的（manual_category）和自建分类（c:）
        db.execSQL("DELETE FROM repository_category_cross_ref WHERE categoryId NOT LIKE 'c:%' AND NOT EXISTS (SELECT 1 FROM manual_category m WHERE m.repositoryId = repository_category_cross_ref.repositoryId AND m.categoryId = repository_category_cross_ref.categoryId)")
    }
}

val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS category_tag (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, categoryId TEXT NOT NULL, name TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS repo_tag (repositoryId INTEGER NOT NULL, tagId INTEGER NOT NULL, PRIMARY KEY(repositoryId, tagId))")
    }
}
