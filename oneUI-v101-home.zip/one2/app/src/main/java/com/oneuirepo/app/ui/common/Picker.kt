package com.oneuirepo.app.ui.common

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

data class PickerOption<T>(
    val key: T,
    val title: String,
    val subtitle: String? = null,
    val badges: List<String> = emptyList(),
    /** 左侧方块里的短文字（例如文件扩展名 APK）；为空时显示标签图标。 */
    val leading: String? = null
)

/**
 * 「资源 / 版本」选择：字段本身是带圆形箭头的卡片，点开后从底部弹出选择面板，
 * 每一项是圆角行（左侧类型方块 + 标题 + 副标题 + 徽标），当前项高亮并带对勾。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> PickerField(
    label: String,
    value: String,
    sheetTitle: String,
    options: List<PickerOption<T>>,
    selectedKey: T?,
    modifier: Modifier = Modifier,
    onSelect: (T) -> Unit
) {
    var open by remember { mutableStateOf(false) }
    val rot by animateFloatAsState(if (open) 270f else 90f, tween(250), label = "pickerChev")
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
        Surface(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth(),
            shape = cardShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            border = cardBorder() ?: BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp).heightIn(min = 56.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(value, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Box(Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                    AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onPrimaryContainer, 16.dp, Modifier.graphicsLayer { rotationZ = rot })
                }
            }
        }
    }
    if (open) {
        PickerSheet(sheetTitle, options, selectedKey, onSelect = { onSelect(it); open = false }, onDismiss = { open = false })
    }
}

/** 底部弹出的选择面板（标题 + 数量徽标 + 圆角选项行）；字段样式不同的地方（比如卡片里的版本胶囊）也直接复用。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun <T> PickerSheet(
    title: String,
    options: List<PickerOption<T>>,
    selectedKey: T?,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("共 ${options.size} 项，点选后自动关闭", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                    Text("${options.size}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                }
            }
            LazyColumn(
                Modifier.fillMaxWidth().heightIn(max = 480.dp),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(options, key = { it.key.toString() }) { option ->
                    PickerRow(option, selected = option.key == selectedKey) { onSelect(option.key) }
                }
            }
            Spacer(Modifier.navigationBarsPadding().height(8.dp))
        }
    }
}

@Composable
private fun <T> PickerRow(o: PickerOption<T>, selected: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        border = if (selected) BorderStroke(1.5.dp, primary) else null
    ) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(RoundedCornerShape(15.dp))
                    .background(if (selected) primary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surface),
                contentAlignment = Alignment.Center
            ) {
                if (o.leading != null) {
                    Text(o.leading, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Black, color = if (selected) primary else MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                } else {
                    AppIcon(IconKind.TAG, if (selected) primary else MaterialTheme.colorScheme.onSurfaceVariant, 22.dp)
                }
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(o.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (!o.subtitle.isNullOrBlank()) {
                    Text(o.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (o.badges.isNotEmpty()) {
                    Row(Modifier.padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        o.badges.forEach { b ->
                            Box(Modifier.clip(RoundedCornerShape(50)).background(primary.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                                Text(b, style = MaterialTheme.typography.labelSmall, color = primary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            if (selected) {
                Box(Modifier.size(26.dp).clip(CircleShape).background(primary), contentAlignment = Alignment.Center) {
                    AppIcon(IconKind.CHECK, MaterialTheme.colorScheme.onPrimary, 16.dp)
                }
            }
        }
    }
}
