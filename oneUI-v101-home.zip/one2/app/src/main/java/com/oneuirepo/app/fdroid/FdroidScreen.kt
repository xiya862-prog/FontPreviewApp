package com.oneuirepo.app.fdroid

import android.app.DownloadManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONArray
import org.json.JSONObject
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import coil3.compose.AsyncImage
import kotlinx.coroutines.launch

@Composable
fun FdroidScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val installer = remember { FdroidInstaller(context) }
    var apps by remember { mutableStateOf<List<FdroidApp>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("全部玩机资源") }
    var sort by remember { mutableStateOf("最新版本优先") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var selectedApp by remember { mutableStateOf<FdroidApp?>(null) }
    var categoryExpanded by remember { mutableStateOf(false) }
    var sortExpanded by remember { mutableStateOf(false) }
    var showMissingIconsOnly by remember { mutableStateOf(false) }
    var missingIconPackages by remember { mutableStateOf<Set<String>>(emptySet()) }
    var pendingExportJson by remember { mutableStateOf("{}") }
    val exportMissingIconsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(pendingExportJson.toByteArray(Charsets.UTF_8))
                } ?: error("无法创建导出文件")
            }.onSuccess {
                Toast.makeText(context, "缺失图标数据已导出", Toast.LENGTH_LONG).show()
            }.onFailure { e ->
                Toast.makeText(context, "导出失败：${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Keep this page focused on Android power-user resources only. General-purpose
    // apps outside these classifications are intentionally omitted from the F-Droid view.
    // VPN clients and VPN/proxy tunnelling tools remain excluded as before.
    val visibleApps = remember(apps) {
        apps.filterNot(::isVpnRelated).filter { classifyPlayCategory(it) != null }
    }
    val categories = remember {
        listOf(
            "全部玩机资源", "应用管理", "ADB 与高级工具", "系统定制",
            "文件与安装", "网络与安全", "外观与个性化", "自动化与效率", "游戏与性能"
        )
    }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(1500)
            refresh++
        }
    }

    LaunchedEffect(apps) {
        val metadataMissing = apps.filter { it.iconUrl.isNullOrBlank() }.map { it.packageName }.toSet()
        if (metadataMissing.isNotEmpty()) missingIconPackages = missingIconPackages + metadataMissing
    }

    LaunchedEffect(Unit) {
        loading = true
        try {
            apps = FdroidRepository.load()
            error = null
        } catch (e: Exception) {
            error = e.message ?: "无法加载 F-Droid 索引"
        } finally {
            loading = false
        }
    }

    val filtered = remember(visibleApps, query, category, sort, refresh, showMissingIconsOnly, missingIconPackages) {
        val list = visibleApps.filter { app ->
            (query.isBlank() || app.name.contains(query, true) ||
                app.packageName.contains(query, true) || app.summary.contains(query, true) ||
                app.description.contains(query, true)) &&
                (category == "全部玩机资源" || classifyPlayCategory(app) == category) &&
                if (showMissingIconsOnly) app.packageName in missingIconPackages
                else app.packageName !in missingIconPackages
        }
        when (sort) {
            "名称 A-Z" -> list.sortedBy { it.name.lowercase() }
            "包名 A-Z" -> list.sortedBy { it.packageName.lowercase() }
            else -> list.sortedByDescending { it.versionCode }
        }
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
    ) {
        // Redesigned F-Droid header: compact navigation plus a clear source overview.
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    onClick = onBack,
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Box(Modifier.size(width = 66.dp, height = 42.dp), contentAlignment = Alignment.Center) {
                        Text("返回", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("F-Droid", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("自由 · 开源 · Android", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalButton(
                    enabled = !loading,
                    onClick = {
                        scope.launch {
                            loading = true
                            try {
                                apps = FdroidRepository.load()
                                error = null
                            } catch (e: Exception) {
                                error = e.message ?: "刷新失败，请稍后重试"
                            } finally {
                                loading = false
                            }
                        }
                    },
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text(if (loading) "加载中" else "刷新") }
            }
            Spacer(Modifier.height(14.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.primaryContainer
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 17.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("玩机开源资源", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Spacer(Modifier.height(4.dp))
                        Text("仅展示系统管理、ADB、定制与效率工具", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${visibleApps.size}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("款应用", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
        }

        // Search panel: rounded container, clear affordance and a compact filter row.
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            tonalElevation = 0.dp
        ) {
            Column(Modifier.padding(12.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    placeholder = { Text("搜索应用名称、简介或包名") },
                    leadingIcon = { Text("⌕", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { query = "" }) { Text("×", style = MaterialTheme.typography.titleLarge) }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedContainerColor = MaterialTheme.colorScheme.surface
                    )
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.weight(1.15f)) {
                        FilledTonalButton(
                            onClick = { categoryExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 11.dp)
                        ) {
                            Text("分类 · ${translateFdroidCategory(category)}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        FilledTonalButton(
                            onClick = { sortExpanded = true },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 11.dp)
                        ) {
                            Text("排序 · ${if (sort == "最新版本优先") "最新版本" else sort}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        FilledTonalButton(
                            onClick = { showMissingIconsOnly = !showMissingIconsOnly },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 11.dp),
                            colors = if (showMissingIconsOnly) ButtonDefaults.filledTonalButtonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ) else ButtonDefaults.filledTonalButtonColors()
                        ) {
                            Text("无图标 ${visibleApps.count { it.packageName in missingIconPackages }}", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (showMissingIconsOnly) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            val missingApps = visibleApps.filter { it.packageName in missingIconPackages }
                            val items = JSONArray()
                            missingApps.forEach { app ->
                                items.put(JSONObject().apply {
                                    put("name", app.name)
                                    put("packageName", app.packageName)
                                    put("summary", app.summary)
                                    put("description", app.description)
                                    put("categories", JSONArray(app.categories))
                                    put("playCategory", classifyPlayCategory(app) ?: JSONObject.NULL)
                                    put("versionName", app.versionName)
                                    put("versionCode", app.versionCode)
                                    put("iconUrlFromIndex", app.iconUrl ?: JSONObject.NULL)
                                    put("iconCandidatesTried", JSONArray(fdroidIconCandidates(app.iconUrl)))
                                    put("reason", if (app.iconUrl.isNullOrBlank()) "index_icon_metadata_missing" else "all_icon_urls_failed")
                                })
                            }
                            pendingExportJson = JSONObject().apply {
                                put("generatedAtEpochMillis", System.currentTimeMillis())
                                put("source", "F-Droid index-v1.json")
                                put("missingIconCount", missingApps.size)
                                put("apps", items)
                            }.toString(2)
                            exportMissingIconsLauncher.launch("fdroid-missing-icons.json")
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("导出缺失图标数据（${visibleApps.count { it.packageName in missingIconPackages }}）") }
                }
            }
        }

        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (error != null && apps.isEmpty()) {
            Column(
                Modifier.fillMaxWidth().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("暂时无法加载 F-Droid", style = MaterialTheme.typography.titleMedium)
                Text(error.orEmpty(), color = MaterialTheme.colorScheme.error)
                Button(onClick = {
                    scope.launch {
                        loading = true
                        try {
                            apps = FdroidRepository.load()
                            error = null
                        } catch (e: Exception) {
                            error = e.message ?: "加载失败"
                        } finally {
                            loading = false
                        }
                    }
                }) { Text("重试") }
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 8.dp, bottom = 2.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("玩机资源", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                        Text("${filtered.size}", Modifier.padding(horizontal = 8.dp, vertical = 3.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.weight(1f))
                    Text(translateFdroidCategory(category), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.packageName }) { app ->
                    val installed = installer.installedVersionCode(app.packageName)
                    val updateAvailable = installed != null && app.versionCode > installed
                    var downloadStatus by remember(app.packageName, refresh) {
                        mutableIntStateOf(installer.downloadStatus(app.packageName) ?: -1)
                    }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                    ) {
                        Column(Modifier.fillMaxWidth().padding(15.dp)) {
                            Row(verticalAlignment = Alignment.Top) {
                                FdroidAppIcon(
                                    iconUrl = app.iconUrl,
                                    name = app.name,
                                    modifier = Modifier.size(62.dp),
                                    textStyle = MaterialTheme.typography.headlineSmall,
                                    onLoadFailed = { missingIconPackages = missingIconPackages + app.packageName },
                                    onLoadSucceeded = { missingIconPackages = missingIconPackages - app.packageName }
                                )
                                Column(Modifier.weight(1f).padding(start = 12.dp, end = 6.dp)) {
                                    Text(app.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(app.summary.ifBlank { app.packageName }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Spacer(Modifier.height(5.dp))
                                    Text(
                                        "${app.versionName.ifBlank { "版本未知" }} · ${app.license.ifBlank { "许可证未知" }}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                if (updateAvailable) {
                                    AssistChip(onClick = { selectedApp = app }, label = { Text("可更新") })
                                } else if (installed != null) {
                                    AssistChip(onClick = { selectedApp = app }, label = { Text("已安装") })
                                }
                            }
                            if (classifyPlayCategory(app) != null) {
                                Text(
                                    classifyPlayCategory(app).orEmpty(),
                                    Modifier.padding(top = 9.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row(
                                Modifier.fillMaxWidth().padding(top = 8.dp),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { selectedApp = app }) { Text("查看详情") }
                                Spacer(Modifier.width(4.dp))
                                if (downloadStatus == DownloadManager.STATUS_SUCCESSFUL) {
                                    Button(onClick = {
                                        if (!installer.installDownloaded(app.packageName, app.hash)) {
                                            Toast.makeText(context, "安装文件不可用，请重新下载", Toast.LENGTH_SHORT).show()
                                        }
                                    }, shape = RoundedCornerShape(14.dp)) { Text("安装") }
                                } else {
                                    Button(onClick = {
                                        try {
                                            installer.download(app)
                                            downloadStatus = DownloadManager.STATUS_PENDING
                                            Toast.makeText(context, "已加入下载，完成后可点击安装", Toast.LENGTH_SHORT).show()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "下载失败：${e.message}", Toast.LENGTH_LONG).show()
                                        }
                                    }, shape = RoundedCornerShape(14.dp)) {
                                        Text(if (downloadStatus == DownloadManager.STATUS_RUNNING || downloadStatus == DownloadManager.STATUS_PENDING) "下载中" else if (updateAvailable) "下载更新" else "下载 APK")
                                    }
                                }
                            }
                        }
                    }
                }
                if (!loading && filtered.isEmpty() && error == null) {
                    item {
                        Column(
                            Modifier.fillMaxWidth().padding(vertical = 36.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("⌕", style = MaterialTheme.typography.displaySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("没有找到匹配的应用", style = MaterialTheme.typography.titleMedium)
                            Text("试试其他关键词或切换分类", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }

    if (categoryExpanded) {
        Dialog(onDismissRequest = { categoryExpanded = false }) {
            Surface(
                modifier = Modifier.fillMaxWidth().widthIn(max = 460.dp),
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("应用分类", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("选择分类后，只显示该类型的应用", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    Column(
                        Modifier.fillMaxWidth().heightIn(max = 440.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        categories.forEach { item ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                color = if (category == item) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
                                onClick = { category = item; categoryExpanded = false }
                            ) {
                                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(translateFdroidCategory(item), modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge, fontWeight = if (category == item) FontWeight.SemiBold else FontWeight.Medium)
                                    if (category == item) Text("✓", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    TextButton(onClick = { categoryExpanded = false }, modifier = Modifier.align(Alignment.End)) { Text("完成") }
                }
            }
        }
    }

    if (sortExpanded) {
        Dialog(onDismissRequest = { sortExpanded = false }) {
            Surface(
                modifier = Modifier.fillMaxWidth().widthIn(max = 420.dp),
                shape = RoundedCornerShape(28.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("排序方式", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("选择应用列表的排列顺序", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    listOf("最新版本优先", "名称 A-Z", "包名 A-Z").forEachIndexed { index, item ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = if (sort == item) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerLow,
                            onClick = { sort = item; sortExpanded = false }
                        ) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        when (item) { "名称 A-Z" -> "应用名称（A-Z）"; "包名 A-Z" -> "应用包名（A-Z）"; else -> "最新版本优先" },
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = if (sort == item) FontWeight.SemiBold else FontWeight.Medium
                                    )
                                    Text(
                                        when (index) { 0 -> "按仓库版本号从高到低排列"; 1 -> "按应用名称的字母顺序排列"; else -> "按应用包名的字母顺序排列" },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                if (sort == item) Text("✓", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { sortExpanded = false }, modifier = Modifier.align(Alignment.End)) { Text("完成") }
                }
            }
        }
    }

    selectedApp?.let { app ->
        val installed = installer.installedVersionCode(app.packageName)
        val updateAvailable = installed != null && app.versionCode > installed
        var detailDownloadStatus by remember(app.packageName, refresh) {
            mutableIntStateOf(installer.downloadStatus(app.packageName) ?: -1)
        }
        Dialog(onDismissRequest = { selectedApp = null }) {
            Surface(
                modifier = Modifier.fillMaxWidth().widthIn(max = 520.dp),
                shape = RoundedCornerShape(26.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Row(verticalAlignment = Alignment.Top) {
                        FdroidAppIcon(
                            iconUrl = app.iconUrl,
                            name = app.name,
                            modifier = Modifier.size(68.dp),
                            textStyle = MaterialTheme.typography.headlineMedium
                        )
                        Column(Modifier.weight(1f).padding(start = 14.dp, end = 4.dp)) {
                            Text(app.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text(app.summary.ifBlank { "暂无简介" }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (updateAvailable) AssistChip(onClick = {}, label = { Text("发现更新") })
                                else if (installed != null) AssistChip(onClick = {}, label = { Text("已安装") })
                                else AssistChip(onClick = {}, label = { Text("开源应用") })
                            }
                        }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 14.dp), color = MaterialTheme.colorScheme.outlineVariant)
                    Column(
                        Modifier.weight(1f, fill = false).heightIn(max = 300.dp).verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        DetailField("版本", "${app.versionName.ifBlank { "未知" }}  (${app.versionCode})")
                        DetailField("许可证", app.license.ifBlank { "未知" })
                        DetailField("应用包名", app.packageName)
                        DetailField("玩机分类", classifyPlayCategory(app) ?: "未分类")
                        Text("应用介绍", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                        Text(
                            app.description.ifBlank { app.summary.ifBlank { "暂无详细介绍" } },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (updateAvailable) {
                            Text("当前已安装版本：$installed。仓库提供了较新版本。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { selectedApp = null },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(15.dp)
                        ) { Text("关闭") }
                        if (detailDownloadStatus == DownloadManager.STATUS_SUCCESSFUL) {
                            Button(
                                onClick = {
                                    if (installer.installDownloaded(app.packageName, app.hash)) selectedApp = null
                                },
                                modifier = Modifier.weight(1.2f),
                                shape = RoundedCornerShape(15.dp)
                            ) { Text("安装应用") }
                        } else {
                            Button(
                                onClick = {
                                    try {
                                        installer.download(app)
                                        detailDownloadStatus = DownloadManager.STATUS_PENDING
                                        Toast.makeText(context, "已加入下载，完成后返回详情点击安装", Toast.LENGTH_SHORT).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "下载失败：${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.weight(1.2f),
                                shape = RoundedCornerShape(15.dp)
                            ) { Text(if (updateAvailable) "下载更新" else "下载 APK") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailField(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}

/**
 * Maps repository apps into the curated one Store power-user categories.
 * This is a local discovery taxonomy; it does not alter upstream F-Droid metadata.
 */
private fun classifyPlayCategory(app: FdroidApp): String? {
    val text = (listOf(app.name, app.packageName, app.summary, app.description) + app.categories)
        .joinToString(" ").lowercase()
    fun has(vararg words: String) = words.any { it in text }

    return when {
        has("shizuku", "appops", "app ops", "permission manager", "package manager", "app manager", "canta", "debloat", "uninstall system", "freeze app", "component manager") -> "应用管理"
        has("adb", "shell", "root", "superuser", "debug bridge", "logcat", "system monitor", "device info", "diagnostic", "terminal", "developer tool") -> "ADB 与高级工具"
        has("systemui", "system ui", "quick settings", "status bar", "refresh rate", "display density", "dpi", "system setting", "customization", "tweak", "one ui", "samsung settings") -> "系统定制"
        has("file manager", "file explorer", "file picker", "apk installer", "apks", "split apk", "backup app", "app backup", "storage access", "android/data", "archive manager") -> "文件与安装"
        has("firewall", "dns", "network analyzer", "packet capture", "network monitor", "privacy", "tracker blocker", "ad blocker", "hosts file", "certificate", "security") -> "网络与安全"
        has("theme", "theming", "icon pack", "launcher", "wallpaper", "font", "appearance", "widget", "lockscreen", "lock screen", "material you", "personalization") -> "外观与个性化"
        has("automation", "automate", "tasker", "macro", "workflow", "shortcut", "scheduled task", "background service", "quick tile", "quick tile") -> "自动化与效率"
        has("game", "gaming", "gamepad", "controller mapping", "performance mode", "gpu", "fps monitor", "frame rate", "benchmark", "game tool") -> "游戏与性能"
        app.categories.any { it.equals("Theming", true) || it.equals("Icon Pack", true) || it.equals("Launcher", true) } -> "外观与个性化"
        else -> null
    }
}

private fun isVpnRelated(app: FdroidApp): Boolean {
    val searchable = listOf(app.name, app.packageName, app.summary, app.description)
        .plus(app.categories)
        .joinToString(" ")
        .lowercase()
    val patterns = listOf(
        Regex("\\bvpn\\b"), Regex("\\bopenvpn\\b"), Regex("\\bwireguard\\b"),
        Regex("\\bproxy\\b"), Regex("\\bshadowsocks\\b"), Regex("\\bv2ray\\b"),
        Regex("\\bsing[ -]?box\\b"), Regex("\\bclash\\b"), Regex("\\btunnel(ing)?\\b"),
        Regex("\\btailscale\\b"), Regex("\\bzerotier\\b"), Regex("\\bhysteria\\b"),
        Regex("\\boutline\\s+(vpn|client)\\b"), Regex("\\bproxy\\s*client\\b"),
        Regex("\\bgeph\\b"), Regex("\\btor\\s*(browser|proxy)\\b"),
        Regex("\\bnaiveproxy\\b"), Regex("\\bbrook\\b")
    )
    return patterns.any { it.containsMatchIn(searchable) }
}


/** Build fallback URLs from the actual index value instead of assuming one icon size. */
private fun fdroidIconCandidates(iconUrl: String?): List<String> {
    if (iconUrl.isNullOrBlank()) return emptyList()
    val raw = iconUrl.trim()
    val resolutions = listOf("icons-640", "icons-160", "icons")
    val candidates = linkedSetOf<String>()

    val isAbsolute = raw.startsWith("https://", ignoreCase = true) || raw.startsWith("http://", ignoreCase = true)
    if (isAbsolute) {
        candidates += raw
        // Only rewrite URLs belonging to the official F-Droid host. Do not turn
        // third-party repository URLs into guessed f-droid.org URLs.
        val official = raw.startsWith("https://f-droid.org/", ignoreCase = true) ||
            raw.startsWith("http://f-droid.org/", ignoreCase = true)
        if (!official) return candidates.toList()
    }

    var path = if (isAbsolute) raw.substringAfter("f-droid.org/", raw).substringBefore('?') else raw.substringBefore('?')
    path = path.trimStart('/')
    path = path.removePrefix("repo/").removePrefix("archive/")
    val currentResolution = resolutions.firstOrNull { path.startsWith("$it/") }
    val filename = if (currentResolution != null) path.removePrefix("$currentResolution/") else path
    if (filename.isBlank()) return candidates.toList()

    // The v1 index normally stores a bare filename. Some repository indexes store
    // a path including the icon directory, so try both the original and each known size.
    if (currentResolution == null && (path.contains('/'))) {
        candidates += "https://f-droid.org/repo/$path"
        candidates += "https://f-droid.org/archive/$path"
    }
    for (resolution in resolutions) {
        candidates += "https://f-droid.org/repo/$resolution/$filename"
    }
    for (resolution in resolutions) {
        candidates += "https://f-droid.org/archive/$resolution/$filename"
    }
    return candidates.toList()
}

@Composable
private fun FdroidAppIcon(
    iconUrl: String?,
    name: String,
    modifier: Modifier = Modifier,
    textStyle: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.headlineSmall,
    onLoadFailed: () -> Unit = {},
    onLoadSucceeded: () -> Unit = {}
) {
    var attempt by remember(iconUrl) { mutableIntStateOf(0) }
    val candidates = remember(iconUrl) { fdroidIconCandidates(iconUrl) }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        if (attempt < candidates.size) {
            AsyncImage(
                model = candidates[attempt],
                contentDescription = "$name 应用图标",
                modifier = Modifier.fillMaxSize(),
                onSuccess = { onLoadSucceeded() },
                onError = {
                    if (attempt < candidates.lastIndex) {
                        attempt++
                    } else {
                        attempt = candidates.size
                        onLoadFailed()
                    }
                }
            )
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    name.trim().take(1).uppercase().ifBlank { "?" },
                    style = textStyle,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

private fun translateFdroidCategory(raw: String): String {
    return when (raw.trim().lowercase().replace('_', ' ').replace('-', ' ')) {
        "all", "all categories", "全部分类" -> "全部分类"
        "connectivity" -> "连接与通信"
        "development" -> "开发工具"
        "security & privacy", "security and privacy" -> "安全与隐私"
        "internet & communication", "internet and communication" -> "网络与通信"
        "games & entertainment", "games and entertainment" -> "游戏与娱乐"
        "money & business", "money and business" -> "金融与商务"
        "navigation & location", "navigation and location" -> "导航与定位"
        "games", "game" -> "游戏"
        "graphics" -> "图像与绘图"
        "internet" -> "网络与互联网"
        "money", "finance" -> "金融与支付"
        "multimedia" -> "多媒体"
        "navigation" -> "导航与地图"
        "phone & sms", "phone and sms", "phone" -> "电话与短信"
        "reading", "books" -> "阅读与图书"
        "science & education", "science and education" -> "科学与教育"
        "security" -> "安全与隐私"
        "sports & health", "sports and health", "health & fitness", "health and fitness" -> "健康与健身"
        "system" -> "系统工具"
        "theming", "personalization" -> "主题与个性化"
        "time" -> "时间与日历"
        "writing", "productivity" -> "写作与效率"
        "audio" -> "音频"
        "video" -> "视频"
        "social" -> "社交"
        "utilities", "utility" -> "实用工具"
        "lifestyle" -> "生活方式"
        "communication" -> "通讯"
        "food" -> "美食"
        "travel" -> "旅行"
        "weather" -> "天气"
        "sports" -> "体育运动"
        "science" -> "科学"
        "education" -> "教育"
        "photography" -> "摄影"
        "health" -> "健康"
        else -> raw.trim().replace('_', ' ').replace('-', ' ')
    }
}
