package com.oneuirepo.app.ui

import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.ui.home.*
import com.oneuirepo.app.ui.github.*
import com.oneuirepo.app.ui.category.CategoryScreen
import com.oneuirepo.app.ui.favorite.FavoriteScreen
import com.oneuirepo.app.ui.settings.SettingsScreen
import com.oneuirepo.app.ui.detail.RepositoryDetailScreen

private enum class Tab(val title:String,val icon:String){HOME("首页","⌂"),DISCOVER("发现","✦"),CATEGORY("分类","▦"),FAVORITE("收藏","♡"),SETTINGS("设置","⚙"),GITHUB("GitHub","G"),FDROID("F-Droid","F"),SHIZUSTORE("ShizuStore","S")}

@Composable fun OneUIRepoApp(c:AppContainer){
    // 进入详情页再返回时，各页面的滚动位置、展开状态都要还在（不然列表会跑回顶部）
    val holder=rememberSaveableStateHolder()
    val navScroll=remember{NavScrollController()}
    val backdrop=androidx.compose.ui.graphics.rememberGraphicsLayer()
    var contentOrigin by remember{mutableStateOf(androidx.compose.ui.geometry.Offset.Zero)}
    var tab by remember{mutableStateOf(Tab.HOME)}
    var category by remember{mutableStateOf<String?>(null)}
    var selectedRepoId by remember{mutableStateOf<Long?>(null)}
    val authCb by com.oneuirepo.app.auth.AuthState.callback.collectAsState()
    LaunchedEffect(authCb){ if(authCb!=null){ selectedRepoId=null; tab=Tab.SETTINGS } }
    var showProfile by remember{mutableStateOf(false)}
    val appCtx=androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit){
        // 自动同步开着、已登录：把 GitHub 星标自动放进收藏
        if(com.oneuirepo.app.settings.AppSettings(appCtx).autoSync && com.oneuirepo.app.auth.AuthState.token!=null){
            val n=c.starSync.run()
            if(n>0) android.widget.Toast.makeText(appCtx,"已把 $n 个 GitHub 星标同步到收藏",android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    LaunchedEffect(selectedRepoId){ selectedRepoId?.let{ c.db.historyDao().upsertView(com.oneuirepo.app.data.local.entity.ViewHistoryEntity(it,System.currentTimeMillis())) } }
    if(selectedRepoId!=null){
        RepositoryDetailScreen(selectedRepoId!!,c.db){selectedRepoId=null}
        return
    }
    if(showProfile){
        com.oneuirepo.app.ui.profile.ProfileScreen(c,{showProfile=false}){selectedRepoId=it}
        return
    }
    val st:com.oneuirepo.app.ui.discover.StoreViewModel=viewModel(factory=com.oneuirepo.app.ui.discover.StoreVMFactory(c.repository))
    if(tab==Tab.GITHUB || tab==Tab.FDROID || tab==Tab.SHIZUSTORE) androidx.activity.compose.BackHandler{tab=Tab.HOME}
    val g:GitHubViewModel=viewModel(factory=GitHubViewModelFactory(c))
    val navTabs=Tab.entries.filter{it!=Tab.GITHUB && it!=Tab.FDROID && it!=Tab.SHIZUSTORE}
    val navItems=navTabs.map{ NavItem(it.title, when(it){ Tab.HOME->NavGlyph.HOME; Tab.DISCOVER->NavGlyph.DISCOVER; Tab.CATEGORY->NavGlyph.CATEGORY; Tab.FAVORITE->NavGlyph.FAVORITE; else->NavGlyph.SETTINGS }) }
    val navBottom=WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    // 横屏 / 外屏：导航条自动旋转成竖排，贴在左边或右边（设置里可选，也可保持底部）
    val conf=androidx.compose.ui.platform.LocalConfiguration.current
    val railMode=com.oneuirepo.app.ui.theme.ThemeState.landscapeNav
    val vertical=conf.screenWidthDp>conf.screenHeightDp && railMode!=2
    val railAtEnd=railMode==1
    Box(Modifier.fillMaxSize()){
        CompositionLocalProvider(LocalNavInset provides (if(vertical) 16.dp+navBottom else 92.dp+navBottom), LocalNavScroll provides navScroll){
            val inCategoryDetail=tab==Tab.CATEGORY&&category!=null
            Box(
                Modifier.fillMaxSize().then(if(inCategoryDetail) Modifier else Modifier.statusBarsPadding())
                    .padding(start=if(vertical&&!railAtEnd) 104.dp else 0.dp, end=if(vertical&&railAtEnd) 104.dp else 0.dp)
                    .onGloballyPositioned{ contentOrigin=it.positionInRoot() }
                    .drawWithContent{
                        // 把页面内容录制下来：既正常显示，也交给底栏做磨砂背景
                        backdrop.record{ this@drawWithContent.drawContent() }
                        drawLayer(backdrop)
                    }
            ){when(tab){
                Tab.HOME->holder.SaveableStateProvider("home"){HomeScreen({tab=Tab.GITHUB},{tab=Tab.DISCOVER},{id->category=id;tab=Tab.CATEGORY},{selectedRepoId=it},{tab=Tab.FDROID},{tab=Tab.SHIZUSTORE})}
                Tab.DISCOVER->holder.SaveableStateProvider("discover"){com.oneuirepo.app.ui.discover.DiscoverScreen(st){selectedRepoId=it}}
                Tab.CATEGORY->holder.SaveableStateProvider("cat:"+(category?:"list")){CategoryScreen(c.db,category,{category=it}){selectedRepoId=it}}
                Tab.GITHUB->holder.SaveableStateProvider("github"){GitHubScreen(g,c){selectedRepoId=it}}
                Tab.FDROID->holder.SaveableStateProvider("fdroid"){com.oneuirepo.app.fdroid.FdroidScreen{tab=Tab.HOME}}
                Tab.SHIZUSTORE->holder.SaveableStateProvider("shizustore"){ShizuStoreScreen{tab=Tab.HOME}}
                Tab.FAVORITE->holder.SaveableStateProvider("fav"){FavoriteScreen(c.db){selectedRepoId=it}}
                Tab.SETTINGS->holder.SaveableStateProvider("settings"){SettingsScreen(c){showProfile=true}}
            }}
        }
        if(tab!=Tab.FDROID && tab!=Tab.SHIZUSTORE) Box(Modifier.align(if(vertical) (if(railAtEnd) Alignment.CenterEnd else Alignment.CenterStart) else Alignment.BottomCenter)){
            FloatingNavBar(navItems, navTabs.indexOf(tab).coerceAtLeast(0), if(tab==Tab.CATEGORY) category else null, navScroll.far, backdrop, { contentOrigin }, vertical, railAtEnd){ i->
                val t=navTabs[i]
                when{
                    // 当前页已经滑下去一段：点自己的图标 = 平滑回到顶部
                    t==tab && navScroll.far -> navScroll.tick++
                    t==Tab.CATEGORY && tab==Tab.CATEGORY && category!=null -> category=null
                    else -> tab=t
                }
            }
        }
    }
}
