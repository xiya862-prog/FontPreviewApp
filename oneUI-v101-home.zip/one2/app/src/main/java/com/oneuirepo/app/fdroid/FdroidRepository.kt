package com.oneuirepo.app.fdroid

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.app.DownloadManager
import android.content.Intent
import android.database.Cursor
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Reads the public F-Droid v1 repository index. */
data class FdroidApp(
    val packageName: String,
    val name: String,
    val summary: String,
    val description: String,
    val categories: List<String>,
    val license: String,
    val iconUrl: String?,
    val versionName: String,
    val versionCode: Long,
    val apkName: String,
    val apkUrl: String,
    val hash: String?
)

object FdroidRepository {
    private const val INDEX_URL = "https://f-droid.org/repo/index-v1.json"
    private const val REPO_BASE = "https://f-droid.org/repo/"

    suspend fun load(): List<FdroidApp> = withContext(Dispatchers.IO) {
        val connection = (URL(INDEX_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000; readTimeout = 30000
            setRequestProperty("User-Agent", "oneStore/1.0 (F-Droid repository client)")
        }
        try {
            if (connection.responseCode !in 200..299) error("F-Droid 索引请求失败：HTTP ${connection.responseCode}")
            val root = Json.parseToJsonElement(connection.inputStream.bufferedReader().use { it.readText() }).jsonObject
            val appElements: List<Pair<String, JsonElement>> = when (val appsElement = root["apps"]) {
                is JsonArray -> appsElement.mapNotNull { element ->
                    val obj = runCatching { element.jsonObject }.getOrNull() ?: return@mapNotNull null
                    val packageName = obj.stringValue("packageName") ?: return@mapNotNull null
                    packageName to element
                }
                is JsonObject -> appsElement.entries.map { it.key to it.value }
                else -> emptyList()
            }
            val packages = root["packages"]?.jsonObject ?: emptyMap()
            val result = ArrayList<FdroidApp>(appElements.size)
            for ((pkg, appElement) in appElements) {
                val app = appElement.jsonObject
                val versions = packages[pkg]?.jsonArray ?: continue
                val latest = versions.mapNotNull { runCatching { it.jsonObject }.getOrNull() }
                    .maxByOrNull { it["versionCode"]?.jsonPrimitive?.longOrNull ?: 0L } ?: continue
                val apk = latest["apkName"]?.jsonPrimitive?.contentOrNull ?: continue
                val name = app.stringValue("name")?.takeIf { it.isNotBlank() } ?: pkg.substringAfterLast('.')
                // Icon metadata can be stored directly on the app or inside localized
                // metadata. Prefer English, then any available locale, and accept both
                // a string and a locale -> filename object.
                val icon = app.iconValue()?.trim()?.takeIf { it.isNotBlank() }?.let(::normalizeIconUrl)
                result += FdroidApp(
                    packageName = pkg,
                    name = name,
                    summary = app.stringValue("summary").orEmpty().ifBlank { app.stringValue("description")?.take(180).orEmpty() },
                    description = app.stringValue("description").orEmpty().replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim(),
                    categories = app["categories"]?.jsonArray?.mapNotNull { it.jsonPrimitive.contentOrNull } ?: emptyList(),
                    license = app.stringValue("license").orEmpty(),
                    iconUrl = icon,
                    versionName = latest["versionName"]?.jsonPrimitive?.contentOrNull.orEmpty(),
                    versionCode = latest["versionCode"]?.jsonPrimitive?.longOrNull ?: 0L,
                    apkName = apk,
                    apkUrl = REPO_BASE + apk.split('/').joinToString("/") { segment -> java.net.URLEncoder.encode(segment, "UTF-8").replace("+", "%20") },
                    hash = latest["hash"]?.jsonPrimitive?.contentOrNull
                )
            }
            result.sortedBy { it.name.lowercase() }
        } finally { connection.disconnect() }
    }

    private fun normalizeIconUrl(raw: String): String {
        val value = raw.trim()
        if (value.startsWith("https://", ignoreCase = true) || value.startsWith("http://", ignoreCase = true)) return value
        var path = value.substringBefore('?').trim().trimStart('/')
        path = path.removePrefix("repo/").removePrefix("archive/")
        return if (path.startsWith("icons-640/") || path.startsWith("icons-160/") || path.startsWith("icons/")) {
            REPO_BASE + path
        } else {
            REPO_BASE + "icons-640/" + path
        }
    }

    private fun JsonObject.iconValue(): String? {
        fun valueOf(element: JsonElement?): String? = when (element) {
            is JsonPrimitive -> element.contentOrNull?.takeIf { it.isNotBlank() }
            is JsonObject -> {
                val preferred = listOf("en-US", "en", "en-GB", "default")
                preferred.firstNotNullOfOrNull { key -> valueOf(element[key]) }
                    ?: element.values.firstNotNullOfOrNull { valueOf(it) }
            }
            else -> null
        }

        valueOf(this["icon"])?.let { return it }
        val localized = this["localized"] as? JsonObject ?: return null
        val preferredLocales = listOf("en-US", "en", "en-GB", "en-CA")
        for (locale in preferredLocales) {
            val localeObject = localized[locale] as? JsonObject ?: continue
            valueOf(localeObject["icon"])?.let { return it }
        }
        return localized.values.firstNotNullOfOrNull { localeElement ->
            (localeElement as? JsonObject)?.let { valueOf(it["icon"]) }
        }
    }

    private fun JsonObject.stringValue(key: String): String? = this[key]?.let { element ->
        when (element) {
            is JsonPrimitive -> element.contentOrNull
            is JsonObject -> element.values.firstNotNullOfOrNull { value ->
                (value as? JsonPrimitive)?.contentOrNull
            }
            else -> null
        }
    }
}

class FdroidInstaller(private val context: Context) {
    private val prefs = context.getSharedPreferences("fdroid_downloads", Context.MODE_PRIVATE)
    private val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    @Suppress("DEPRECATION")
    private fun packageInfo(packageName: String) = if (Build.VERSION.SDK_INT >= 33)
        context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
    else context.packageManager.getPackageInfo(packageName, 0)

    fun isInstalled(packageName: String): Boolean = try { packageInfo(packageName); true } catch (_: Exception) { false }

    @Suppress("DEPRECATION")
    fun installedVersionCode(packageName: String): Long? = try {
        val info = packageInfo(packageName)
        if (Build.VERSION.SDK_INT >= 28) info.longVersionCode else info.versionCode.toLong()
    } catch (_: Exception) { null }

    fun download(app: FdroidApp): Long {
        val request = DownloadManager.Request(Uri.parse(app.apkUrl))
            .setTitle(app.name).setDescription("F-Droid · ${app.versionName}")
            .setMimeType("application/vnd.android.package-archive")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, "fdroid-${app.packageName}-${app.versionCode}.apk")
        val id = manager.enqueue(request)
        prefs.edit().putLong(app.packageName, id).apply()
        return id
    }

    fun downloadStatus(packageName: String): Int? {
        val id = prefs.getLong(packageName, -1L); if (id < 0) return null
        val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return null
        cursor.use { if (!it.moveToFirst()) return null; return it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) }
    }

    fun installDownloaded(packageName: String, expectedSha256: String?): Boolean {
        val id = prefs.getLong(packageName, -1L); if (id < 0) return false
        val cursor = manager.query(DownloadManager.Query().setFilterById(id)) ?: return false
        val status = cursor.use { if (!it.moveToFirst()) return false; it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) }
        if (status != DownloadManager.STATUS_SUCCESSFUL) return false
        val uri = manager.getUriForDownloadedFile(id) ?: return false
        if (!expectedSha256.isNullOrBlank()) {
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            context.contentResolver.openInputStream(uri)?.use { input ->
                val buffer = ByteArray(64 * 1024)
                while (true) { val count = input.read(buffer); if (count < 0) break; digest.update(buffer, 0, count) }
            } ?: return false
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actual.equals(expectedSha256, ignoreCase = true)) {
                android.widget.Toast.makeText(context, "APK 校验失败，已阻止安装", android.widget.Toast.LENGTH_LONG).show()
                return false
            }
        }
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return try {
            context.startActivity(intent)
            true
        } catch (e: SecurityException) {
            val settingsIntent = Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { context.startActivity(settingsIntent) }
            android.widget.Toast.makeText(context, "请允许 One Store 安装未知应用后，再点安装", android.widget.Toast.LENGTH_LONG).show()
            false
        }
    }
}
