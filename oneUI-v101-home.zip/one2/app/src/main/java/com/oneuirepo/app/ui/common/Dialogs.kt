package com.oneuirepo.app.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * 通用「输入名称」对话框：顶部图标 + 标题，中间是随输入实时变化的预览，
 * 下面是胶囊输入框、错误提示 / 字数、取消 + 创建两个大按钮。
 */
@Composable
fun NameInputDialog(
    title: String,
    subtitle: String,
    placeholder: String,
    leading: IconKind,
    existing: Set<String>,
    duplicateMessage: String,
    maxLen: Int,
    confirmText: String = "创建",
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
    preview: @Composable (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    val name = text.trim()
    val error = when {
        name.length > maxLen -> "名称最多 $maxLen 个字"
        name in existing -> duplicateMessage
        else -> null
    }
    val canConfirm = name.isNotEmpty() && error == null
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.padding(horizontal = 24.dp).fillMaxWidth(),
            shape = RoundedCornerShape(30.dp),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 12.dp
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) { AppIcon(leading, MaterialTheme.colorScheme.onPrimaryContainer, 24.dp) }
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Box(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)).padding(vertical = 18.dp),
                    contentAlignment = Alignment.Center
                ) { preview(name) }
                SearchField(
                    text, { text = it }, placeholder, leading = leading,
                    imeAction = ImeAction.Done, onSubmit = { if (canConfirm) onConfirm(name) }
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) {
                        // 不用 AnimatedVisibility：它在 Row 里再套 Box 时会同时匹配到外层 RowScope，编译报错
                        if (error != null) {
                            Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                        }
                    }
                    Text(
                        "${name.length}/$maxLen", style = MaterialTheme.typography.labelMedium,
                        color = if (name.length > maxLen) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(50)) { Text("取消") }
                    Button(
                        onClick = { onConfirm(name) }, enabled = canConfirm,
                        modifier = Modifier.weight(1f).height(48.dp), shape = RoundedCornerShape(50)
                    ) { Text(confirmText, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}
