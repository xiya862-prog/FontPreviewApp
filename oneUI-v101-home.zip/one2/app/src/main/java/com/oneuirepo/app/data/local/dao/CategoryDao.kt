package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

data class CategoryCount(val categoryId: String, val cnt: Int)

/** 分类总览只需要这几列；一次查询取出所有分类的项目，替代原来每张卡片各查一次。 */
data class CategoryRow(val categoryId: String, val id: Long, val stars: Int, val name: String, val avatarUrl: String?)

@Dao
interface CategoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(x: List<CategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addLinks(x: List<RepositoryCategoryCrossRef>)

    @Query("DELETE FROM repository_category_cross_ref WHERE repositoryId=:id AND categoryId NOT LIKE 'c:%'")
    suspend fun deleteLinks(id: Long)

    @Query("SELECT categoryId AS categoryId, COUNT(*) AS cnt FROM repository_category_cross_ref GROUP BY categoryId")
    fun observeCounts(): Flow<List<CategoryCount>>

    @Query("SELECT " + REPO_LIST_COLS_R + " FROM repositories r INNER JOIN repository_category_cross_ref x ON r.id=x.repositoryId WHERE x.categoryId=:categoryId ORDER BY r.stars DESC")
    fun observeRepos(categoryId: String): Flow<List<RepositoryEntity>>

    @Query("SELECT x.categoryId AS categoryId, r.id AS id, r.stars AS stars, r.name AS name, r.avatarUrl AS avatarUrl FROM repository_category_cross_ref x INNER JOIN repositories r ON r.id=x.repositoryId ORDER BY r.stars DESC")
    fun observeCategoryRows(): Flow<List<CategoryRow>>

    @Query("SELECT categoryId FROM repository_category_cross_ref WHERE repositoryId=:repoId")
    fun observeForRepo(repoId: Long): Flow<List<String>>

    @Query("SELECT * FROM categories WHERE id LIKE 'c:%' ORDER BY name")
    fun observeCustom(): Flow<List<CategoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addLink(x: RepositoryCategoryCrossRef)

    @Query("DELETE FROM repository_category_cross_ref WHERE repositoryId=:repoId AND categoryId=:catId")
    suspend fun removeLink(repoId: Long, catId: String)

    @Query("DELETE FROM repository_category_cross_ref WHERE categoryId=:catId")
    suspend fun deleteCategoryLinks(catId: String)

    @Query("DELETE FROM categories WHERE id=:catId")
    suspend fun deleteCategory(catId: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addManual(x: ManualCategoryEntity)

    @Query("DELETE FROM manual_category WHERE repositoryId=:repoId AND categoryId=:catId")
    suspend fun removeManual(repoId: Long, catId: String)

    @Query("SELECT categoryId FROM manual_category WHERE repositoryId=:repoId")
    suspend fun manualFor(repoId: Long): List<String>

    @Query("SELECT categoryId FROM manual_category WHERE repositoryId=:repoId")
    fun observeManual(repoId: Long): Flow<List<String>>
}
