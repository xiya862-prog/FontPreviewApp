package com.oneuirepo.app.ui.github

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oneuirepo.app.ui.common.AppIcon
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.common.SearchField
import com.oneuirepo.app.ui.common.clearFocusOnTap
import com.oneuirepo.app.ui.search.*
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape
import androidx.compose.ui.text.input.ImeAction

@Composable fun GitHubScreen(vm:GitHubViewModel,container:AppContainer,onOpen:(Long)->Unit){
    val s:SearchViewModel=viewModel(factory=SearchVMFactory(container.db.repositoryDao()))
    var url by remember{mutableStateOf("")}; var query by remember{mutableStateOf("")}
    // 输入停顿 250ms 后才真正查询，避免每敲一个字就扫一遍数据库
    var debounced by remember{mutableStateOf("")}
    LaunchedEffect(query){ kotlinx.coroutines.delay(250); debounced=query }
    val results by remember(debounced){ s.results(debounced) }.collectAsState(initial=emptyList())
    val state by vm.state.collectAsState()
    val listState=androidx.compose.foundation.lazy.rememberLazyListState()
    com.oneuirepo.app.ui.ScrollTopEffect(listState)
    LazyColumn(Modifier.fillMaxSize().clearFocusOnTap(),state=listState,contentPadding=PaddingValues(start=16.dp,end=16.dp,top=16.dp,bottom=16.dp+com.oneuirepo.app.ui.LocalNavInset.current),verticalArrangement=Arrangement.spacedBy(12.dp)){
        item{
            Column(verticalArrangement=Arrangement.spacedBy(2.dp)){
                Text("GitHub",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
                Text("粘贴仓库地址导入，或搜索已导入的项目",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        // ---- 导入
        item{
            Card(Modifier.fillMaxWidth(),shape=cardShape(26.dp),border=cardBorder(),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){
                Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer),contentAlignment=Alignment.Center){
                            AppIcon(IconKind.DOWNLOAD,MaterialTheme.colorScheme.onPrimaryContainer,18.dp)
                        }
                        Spacer(Modifier.width(10.dp))
                        Text("导入仓库",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
                    }
                    SearchField(url,{url=it},"https://github.com/作者/仓库",leading=IconKind.LINK,imeAction=ImeAction.Go,onSubmit={ if(url.isNotBlank()) vm.import(url) })
                    Button(onClick={vm.import(url)},enabled=url.isNotBlank(),modifier=Modifier.fillMaxWidth().height(50.dp),shape=RoundedCornerShape(50)){
                        Text("自动导入 / 更新",fontWeight=FontWeight.Bold)
                    }
                    AnimatedVisibility(state!=ImportState.Idle){
                        val (txt,isErr)=when(val x=state){
                            is ImportState.Success->"导入成功：${x.value.repository.fullName} · ${x.value.releaseCount} 个 Release" to false
                            is ImportState.Error->"导入失败：${x.message}" to true
                            ImportState.Loading->"正在读取 GitHub..." to false
                            else->"" to false
                        }
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if(isErr) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer).padding(12.dp),verticalAlignment=Alignment.CenterVertically){
                            if(state==ImportState.Loading) CircularProgressIndicator(Modifier.size(16.dp),strokeWidth=2.dp)
                            else AppIcon(if(isErr) IconKind.CLOSE else IconKind.CHECK,if(isErr) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,16.dp)
                            Spacer(Modifier.width(10.dp))
                            Text(txt,style=MaterialTheme.typography.bodySmall,color=if(isErr) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer)
                        }
                    }
                }
            }
        }
        // ---- 搜索
        item{SearchField(query,{query=it},"搜索已导入的项目")}
        items(results,key={it.id}){r->com.oneuirepo.app.ui.common.RepoCard(r){onOpen(r.id)}}
    }
}
