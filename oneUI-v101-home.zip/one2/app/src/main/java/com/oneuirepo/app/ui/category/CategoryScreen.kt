package com.oneuirepo.app.ui.category

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.CategoryEntity
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import kotlinx.coroutines.launch
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

internal data class Cat(val name: String, val color: Color, val id: String = name)

internal val categories = listOf(
    Cat("One UI 9", Color(0xFF5B8DEF)),
    Cat("One UI 8.5", Color(0xFF6C7A89)),
    Cat("One UI 8.0", Color(0xFF3FA77A)),
    Cat("SystemUI", Color(0xFF6F8FB8)),
    Cat("RRO", Color(0xFF4FA3D1)),
    Cat("主题", Color(0xFFD9737F)),
    Cat("字体", Color(0xFFD99A45)),
    Cat("模块", Color(0xFF67A842)),
    Cat("LSPosed", Color(0xFFFF7FA6)),
    Cat("Shizuku", Color(0xFF3F51B5)),
    Cat("Root", Color(0xFF8E6BBF)),
    Cat("KernelSU", Color(0xFF51423F)),
    Cat("Magisk", Color(0xFFE8315B)),
    Cat("DeX", Color(0xFF4F7DB5)),
    Cat("Fold", Color(0xFFB07CC6)),
    Cat("Watch", Color(0xFFE08B5A)),
    Cat("CVE", Color(0xFFC0504D))
)

@Composable
fun CategoryScreen(db: AppDatabase, selected: String?, onSelect: (String?) -> Unit, onOpen: (Long) -> Unit) {
    if (selected == null) {
        CategoryList(db, onSelect)
    } else {
        BackHandler { onSelect(null) }
        CategoryDetail(db, selected, { onSelect(null) }, onOpen)
    }
}

@Composable
private fun CategoryList(db: AppDatabase, onSelect: (String?) -> Unit) {
    val custom by remember { db.categoryDao().observeCustom() }.collectAsState(initial = emptyList())
    val rows by remember { db.categoryDao().observeCategoryRows() }.collectAsState(initial = emptyList())
    val summaries = remember(rows) {
        rows.groupBy { it.categoryId }.mapValues { (_, v) ->
            CategorySummary(v.size, v.sumOf { it.stars.toLong() }, v.take(2).map { Avatar(it.name, it.avatarUrl) })
        }
    }
    val scope = rememberCoroutineScope()
    var showNew by remember { mutableStateOf(false) }
    val customCats = custom.map { e -> Cat(e.name, categories[(e.id.hashCode() and 0x7fffffff) % categories.size].color, e.id) }
    val all = categories + customCats
    val gridState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    com.oneuirepo.app.ui.ScrollTopEffect(gridState)
    val cardStyle = com.oneuirepo.app.ui.theme.ThemeState.catCardStyle
    LazyVerticalGrid(
        columns = if (cardStyle == 2) GridCells.Adaptive(minSize = 300.dp) else GridCells.Adaptive(minSize = 150.dp),
        state = gridState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 16.dp + com.oneuirepo.app.ui.LocalNavInset.current),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                // 底部导航已经写着「分类」，这里只保留一个数字圆圈
                Box(Modifier.weight(1f)) { com.oneuirepo.app.ui.common.CountBubble(all.size) }
                FilledTonalButton(onClick = { showNew = true }) { Text("＋ 新建") }
            }
        }
        items(all, key = { it.id }) { cat ->
            val sm = summaries[cat.id] ?: EMPTY_SUMMARY
            when (cardStyle) {
                1 -> SimpleCard(cat, sm) { onSelect(cat.id) }
                2 -> RowCard(cat, sm) { onSelect(cat.id) }
                else -> CollectionCard(cat, sm) { onSelect(cat.id) }
            }
        }
    }
    if (showNew) {
        NewCategoryDialog(
            existing = (categories.map { it.name } + custom.map { it.name }).toSet(),
            onDismiss = { showNew = false }
        ) { name ->
            scope.launch { db.categoryDao().upsertAll(listOf(CategoryEntity("c:" + name, name))) }
            showNew = false
        }
    }
}

private data class Avatar(val name: String, val url: String?)
private data class CategorySummary(val count: Int, val stars: Long, val avatars: List<Avatar>)
private val EMPTY_SUMMARY = CategorySummary(0, 0L, emptyList())

private fun fmt(n: Long): String = if (n >= 10000) String.format("%.1f万", n / 10000.0) else n.toString()

@Composable
private fun CollectionCard(cat: Cat, summary: CategorySummary, onClick: () -> Unit) {
    val stars = summary.stars
    val img = categoryImage(cat.name)
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(164.dp),
        shape = cardShape(26.dp),
        border = cardBorder(),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(Modifier.fillMaxSize()) {
            if (img != null) {
                // 参考图作为整张卡片的封面
                Image(painterResource(img), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(cat.color.lighten(), cat.color.deep(0.82f)))))
                // 柔光
                Box(
                    Modifier.size(150.dp).offset(x = 70.dp, y = (-50).dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.10f))
                )
                CategoryArt(cat.name, cat.color.deep(), Modifier.align(Alignment.TopEnd).padding(top = 12.dp, end = 12.dp), size = 84.dp)
            }
            // 底部压暗，保证文字清晰
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0.45f to Color.Transparent,
                        1f to Color.Black.copy(alpha = if (img != null) 0.62f else 0.30f)
                    )
                )
            )
            AvatarStack(summary, Modifier.align(Alignment.TopStart).padding(12.dp))
            Column(Modifier.align(Alignment.BottomStart).padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(
                    cat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CountChip(if (cat.name == "CVE") "${summary.count} 个相关" else "${summary.count} 个项目")
                    if (cat.name != "CVE" && stars > 0) {
                        Text("★", color = Color(0xFFFFD54F), style = MaterialTheme.typography.labelMedium)
                        Text(fmt(stars), style = MaterialTheme.typography.labelMedium, color = Color.White, maxLines = 1)
                    }
                }
            }
        }
    }
}

private fun Color.lighten(f: Float = 0.18f) = Color(red + (1 - red) * f, green + (1 - green) * f, blue + (1 - blue) * f, alpha)

@Composable
private fun CountChip(text: String) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.22f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = Color.White, maxLines = 1)
    }
}

@Composable
private fun AvatarStack(summary: CategorySummary, modifier: Modifier) {
    val shown = summary.avatars
    val extra = summary.count - shown.size
    val count = shown.size + (if (extra > 0) 1 else 0)
    if (count == 0) return
    val step = 15
    Box(modifier.width((step * (count - 1) + 24).dp).height(24.dp)) {
        shown.forEachIndexed { i, r ->
            Box(
                Modifier.offset(x = (i * step).dp).size(24.dp).clip(CircleShape)
                    .background(Color.White).border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val a = r.url
                if (a != null) {
                    AsyncImage(model = a, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape))
                } else {
                    Text(r.name.take(1).uppercase(), color = Color.Black, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        if (extra > 0) {
            Box(
                Modifier.offset(x = (shown.size * step).dp).size(24.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.28f)).border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("+$extra", color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

/** 风格 1：简约白卡——白底 + 彩色小徽标，数量大字号，更干净。 */
@Composable
private fun SimpleCard(cat: Cat, summary: CategorySummary, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(128.dp),
        shape = cardShape(26.dp),
        border = cardBorder(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                CategoryNavBadge(cat, 46.dp)
                Spacer(Modifier.weight(1f))
                Text(
                    "${summary.count}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black,
                    color = if (summary.count > 0) cat.color.deep(0.9f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(cat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (cat.name == "CVE") "个相关" else if (summary.stars > 0) "个项目 · ★ ${fmt(summary.stars)}" else "个项目",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                )
            }
        }
    }
}

/** 风格 2：列表行——一行一个分类，左徽标 + 名称 + 统计 + 头像 + 箭头，适合分类很多时快速找。 */
@Composable
private fun RowCard(cat: Cat, summary: CategorySummary, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = cardShape(22.dp),
        border = cardBorder(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            CategoryNavBadge(cat, 52.dp)
            Column(Modifier.weight(1f).padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(cat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    (if (cat.name == "CVE") "${summary.count} 个相关" else "${summary.count} 个项目") + (if (cat.name != "CVE" && summary.stars > 0) " · ★ ${fmt(summary.stars)}" else ""),
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1
                )
            }
            AvatarStack(summary, Modifier.padding(end = 10.dp))
            com.oneuirepo.app.ui.common.AppIcon(com.oneuirepo.app.ui.common.IconKind.CHEVRON, MaterialTheme.colorScheme.onSurfaceVariant, 20.dp)
        }
    }
}
