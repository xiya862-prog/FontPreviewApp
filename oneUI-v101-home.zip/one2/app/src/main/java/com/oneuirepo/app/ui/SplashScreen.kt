package com.oneuirepo.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlinx.coroutines.delay

/** Minimal liquid-only splash: no app icon, wordmark, tagline, or loading dots. */
@Composable
fun OneStoreSplash(onFinished: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "liquidOnlySplash")
    val morph = transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1250, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "liquidMorph"
    ).value
    val drift = transition.animateFloat(
        initialValue = -0.045f,
        targetValue = 0.045f,
        animationSpec = infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "liquidDrift"
    ).value

    LaunchedEffect(Unit) {
        delay(850)
        onFinished()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFFF7FAFF), Color(0xFFEAF1FF), Color(0xFFF5F0FF)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawCircle(
                Brush.radialGradient(listOf(Color(0x557AC4FF), Color.Transparent), Offset(w * .08f, h * .2f), w * .72f),
                radius = w * .72f,
                center = Offset(w * .08f, h * .2f)
            )
            drawCircle(
                Brush.radialGradient(listOf(Color(0x447D6BFF), Color.Transparent), Offset(w * .92f, h * .82f), w * .66f),
                radius = w * .66f,
                center = Offset(w * .92f, h * .82f)
            )

            // One large liquid silhouette continuously stretches and rounds; no branding elements.
            val cx = w * (.5f + drift)
            val cy = h * .48f
            val rw = w * (.245f + morph * .025f)
            val rh = rw * (1.02f + morph * .10f)
            val p = Path().apply {
                moveTo(cx, cy - rh * (1.02f + morph * .08f))
                cubicTo(cx + rw * (.78f + morph * .18f), cy - rh * 1.02f, cx + rw * 1.2f, cy - rh * .35f, cx + rw * (.92f - morph * .08f), cy + rh * .12f)
                cubicTo(cx + rw * 1.14f, cy + rh * .72f, cx + rw * .45f, cy + rh * (1.02f + morph * .05f), cx - rw * .05f, cy + rh * .92f)
                cubicTo(cx - rw * .72f, cy + rh * 1.06f, cx - rw * (1.18f - morph * .08f), cy + rh * .48f, cx - rw * .91f, cy - rh * .05f)
                cubicTo(cx - rw * 1.12f, cy - rh * .64f, cx - rw * .42f, cy - rh * (1.08f - morph * .05f), cx, cy - rh * (1.02f + morph * .08f))
                close()
            }
            drawPath(
                p,
                Brush.linearGradient(
                    colors = listOf(Color(0x6686D8FF), Color(0x777E9BFF), Color(0x669E7BFF), Color(0x33FFFFFF)),
                    start = Offset(cx - rw, cy - rh),
                    end = Offset(cx + rw, cy + rh)
                )
            )
            drawPath(p, Brush.linearGradient(listOf(Color(0xCCFFFFFF), Color(0x2283BFFF), Color(0x77FFFFFF))), style = Stroke(width = 2.2f))
            drawCircle(
                Brush.radialGradient(listOf(Color(0x77FFFFFF), Color(0x11FFFFFF), Color.Transparent), Offset(cx - rw * .35f, cy - rh * .48f), rw * .68f),
                radius = rw * .68f,
                center = Offset(cx - rw * .35f, cy - rh * .48f)
            )
            // A small detached droplet merges visually with the main shape as it drifts.
            drawCircle(
                Brush.linearGradient(listOf(Color(0x99FFFFFF), Color(0x6686BFFF), Color(0x449B85FF))),
                radius = w * .027f,
                center = Offset(cx + rw * (1.12f + morph * .12f), cy - rh * (.66f + morph * .10f))
            )
        }
    }
}
