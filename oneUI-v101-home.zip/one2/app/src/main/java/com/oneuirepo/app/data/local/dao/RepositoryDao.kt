package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import kotlinx.coroutines.flow.Flow

/** 列表页不需要 README（可能几十 KB），用 NULL 占位，避免每次查询都把所有 README 读进内存。 */
const val REPO_LIST_COLS = "id, owner, name, fullName, description, htmlUrl, avatarUrl, iconUrl, stars, forks, watchers, language, license, topics, NULL AS readme, oneUiVersions, androidVersions, deviceCompatibility, requirements, createdAt, updatedAt, syncedAt, archived, visibility"
const val REPO_LIST_COLS_R = "r.id, r.owner, r.name, r.fullName, r.description, r.htmlUrl, r.avatarUrl, r.iconUrl, r.stars, r.forks, r.watchers, r.language, r.license, r.topics, NULL AS readme, r.oneUiVersions, r.androidVersions, r.deviceCompatibility, r.requirements, r.createdAt, r.updatedAt, r.syncedAt, r.archived, r.visibility"

@Dao
interface RepositoryDao {
    @Query("SELECT " + REPO_LIST_COLS + " FROM repositories WHERE id NOT IN (SELECT repositoryId FROM discovered) ORDER BY stars DESC")
    fun observePopular(): Flow<List<RepositoryEntity>>
    @Query("SELECT id FROM repositories")
    suspend fun getAllIds(): List<Long>
    @Query("SELECT " + REPO_LIST_COLS + " FROM repositories WHERE id NOT IN (SELECT repositoryId FROM discovered) ORDER BY createdAt DESC")
    fun observeNewest(): Flow<List<RepositoryEntity>>
    @Query("SELECT " + REPO_LIST_COLS + " FROM repositories WHERE id NOT IN (SELECT repositoryId FROM discovered) ORDER BY updatedAt DESC")
    fun observeRecentlyUpdated(): Flow<List<RepositoryEntity>>
    @Query("SELECT * FROM repositories WHERE id=:id LIMIT 1")
    fun observeById(id: Long): Flow<RepositoryEntity?>
    @Query("SELECT * FROM repositories WHERE id=:id LIMIT 1")
    suspend fun findById(id: Long): RepositoryEntity?
    @Query("SELECT " + REPO_LIST_COLS + " FROM repositories WHERE fullName LIKE '%' || :q || '%' OR name LIKE '%' || :q || '%' OR owner LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%' OR topics LIKE '%' || :q || '%' OR (LENGTH(:q) >= 3 AND readme LIKE '%' || :q || '%') ORDER BY stars DESC")
    fun search(q: String): Flow<List<RepositoryEntity>>
    @Query("SELECT " + REPO_LIST_COLS_R + " FROM repositories r INNER JOIN favorites f ON r.id=f.repositoryId ORDER BY f.createdAt DESC")
    fun observeFavorites(): Flow<List<RepositoryEntity>>
    @Insert(onConflict=OnConflictStrategy.REPLACE)
    suspend fun upsert(e: RepositoryEntity)
    @Query("SELECT * FROM repositories WHERE fullName=:fullName LIMIT 1")
    suspend fun findByFullName(fullName: String): RepositoryEntity?
}
