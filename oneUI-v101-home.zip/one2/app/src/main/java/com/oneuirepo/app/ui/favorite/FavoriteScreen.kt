package com.oneuirepo.app.ui.favorite

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.ui.ScrollTopEffect
import com.oneuirepo.app.ui.common.EmptyHint
import com.oneuirepo.app.ui.common.RepoCard

@Composable
fun FavoriteScreen(db: AppDatabase, onOpen: (Long) -> Unit) {
    val items by remember { db.repositoryDao().observeFavorites() }.collectAsState(initial = emptyList())
    val gridState = rememberLazyGridState()
    ScrollTopEffect(gridState)
    // 手机一列；折叠屏 / 平板展开后自动变成多列
    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 300.dp),
        modifier = Modifier.fillMaxSize(),
        state = gridState,
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 16.dp + com.oneuirepo.app.ui.LocalNavInset.current),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) { Text("收藏", style = MaterialTheme.typography.headlineMedium) }
        if (items.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { EmptyHint("还没有收藏项目，在项目详情页点「收藏」") }
        items(items, key = { it.id }) { r -> RepoCard(r) { onOpen(r.id) } }
    }
}
