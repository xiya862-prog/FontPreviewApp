package com.oneuirepo.app.ui.category

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.oneuirepo.app.ui.theme.ThemeState
import kotlin.math.cos
import kotlin.math.sin

/**
 * 一套单色「黑色轮廓」分类小图标：和底部导航栏的首页 / 发现 / 收藏图标同一种实心 + 粗描边风格，
 * 只用一个颜色（[tint]），镂空是真正的透明，放在任何底色上都清晰。
 */
@Composable
fun CategoryGlyph(name: String, tint: Color, size: Dp, modifier: Modifier = Modifier) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().drawWithCache {
                // 外层有同名的 Dp 参数 size，这里必须用 this.size 取画布尺寸
                val u = this.size.minDimension / 24f
                val fill = glyphFill(name, u)
                onDrawBehind {
                    if (fill != null) drawPath(fill, tint)
                    glyphExtras(name, tint, u)
                }
            }
        )
        when {
            name.startsWith("One UI") -> {
                val v = name.removePrefix("One UI").trim()
                Text(v, color = tint, fontWeight = FontWeight.Black, fontSize = (size.value * if (v.length > 1) 0.30f else 0.46f).sp)
            }
            name == "字体" -> Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.62f).sp)) { append("A") }
                    withStyle(SpanStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = (size.value * 0.44f).sp)) { append("a") }
                },
                color = tint
            )
        }
    }
}

/** 底部导航 / 详情页用的小图标：按设置里选的风格，在「黑色轮廓」和「彩色徽标」之间切换。 */
@Composable
internal fun CategoryMiniIcon(cat: Cat, size: Dp, tint: Color, modifier: Modifier = Modifier) {
    if (ThemeState.catIconStyle == 1) CategoryGlyph(cat.name, tint, size, modifier)
    else CategoryNavBadge(cat, size, modifier)
}

// ------------------------------------------------------------------------------------------

private fun poly(u: Float, vararg p: Float): Path = Path().apply {
    moveTo(p[0] * u, p[1] * u)
    var i = 2
    while (i < p.size) { lineTo(p[i] * u, p[i + 1] * u); i += 2 }
    close()
}

private fun hexPath(u: Float, cx: Float, cy: Float, r: Float): Path =
    poly(u, cx - r, cy, cx - r / 2, cy - 0.866f * r, cx + r / 2, cy - 0.866f * r, cx + r, cy, cx + r / 2, cy + 0.866f * r, cx - r / 2, cy + 0.866f * r)

private fun circ(u: Float, cx: Float, cy: Float, r: Float): Path =
    Path().apply { addOval(Rect(Offset((cx - r) * u, (cy - r) * u), Size(2 * r * u, 2 * r * u))) }

private fun oval(u: Float, x: Float, y: Float, w: Float, h: Float): Path =
    Path().apply { addOval(Rect(Offset(x * u, y * u), Size(w * u, h * u))) }

private fun rrect(u: Float, x: Float, y: Float, w: Float, h: Float, r: Float): Path =
    Path().apply { addRoundRect(RoundRect(Rect(Offset(x * u, y * u), Size(w * u, h * u)), CornerRadius(r * u))) }

private fun rot(p: Path, deg: Float, c: Float): Path = p.apply {
    transform(androidx.compose.ui.graphics.Matrix().apply { translate(c, c); rotateZ(deg); translate(-c, -c) })
}

private fun diff(a: Path, vararg b: Path): Path {
    var p = a
    b.forEach { p = Path.combine(PathOperation.Difference, p, it) }
    return p
}

private fun union(vararg a: Path): Path {
    var p = a[0]
    for (i in 1 until a.size) p = Path.combine(PathOperation.Union, p, a[i])
    return p
}

/** 实心主体（可带真正的镂空）；没有实心部分的图标返回 null。 */
private fun glyphFill(name: String, u: Float): Path? = when (name) {
    "主题" -> diff(
        oval(u, 2f, 3.5f, 20f, 17f),
        oval(u, 14f, 13.2f, 6f, 5.2f), circ(u, 7.3f, 10f, 1.6f), circ(u, 11.6f, 7.4f, 1.6f), circ(u, 16.4f, 8.6f, 1.6f)
    )
    "模块" -> diff(
        union(rrect(u, 4f, 8.5f, 12f, 12f, 2.2f), circ(u, 10f, 6.9f, 2.6f), circ(u, 17.4f, 14.5f, 2.6f)),
        circ(u, 4f, 14.5f, 2.4f)
    )
    "KernelSU" -> diff(
        rrect(u, 3f, 3f, 18f, 18f, 4.4f),
        rrect(u, 12.2f, 5.2f, 6.6f, 6.6f, 1.3f), rrect(u, 5.2f, 12.2f, 6.6f, 6.6f, 1.3f)
    )
    "CVE" -> {
        val shield = Path().apply {
            moveTo(12f * u, 2.5f * u); lineTo(20f * u, 5.5f * u); lineTo(20f * u, 12f * u)
            cubicTo(20f * u, 16.8f * u, 16.6f * u, 20.2f * u, 12f * u, 21.8f * u)
            cubicTo(7.4f * u, 20.2f * u, 4f * u, 16.8f * u, 4f * u, 12f * u)
            lineTo(4f * u, 5.5f * u); close()
        }
        diff(shield, rrect(u, 10.8f, 7.2f, 2.4f, 6.4f, 1.2f), circ(u, 12f, 16.5f, 1.4f))
    }
    "Shizuku" -> {
        // 卡片上的图：左下一只圆脸小猫（一大一小的耳朵、两个高低不同的小眼睛），右上是一个六边形
        val head = union(
            oval(u, 2.5f, 9.5f, 13f, 11.5f),
            poly(u, 3.4f, 10.8f, 5.0f, 5.2f, 8.6f, 9.8f),
            poly(u, 11.2f, 9.6f, 13.8f, 6.4f, 14.8f, 11.4f)
        )
        val headEx = union(
            oval(u, 1.2f, 8.2f, 15.6f, 14f),
            poly(u, 2.2f, 11.6f, 4.8f, 3.8f, 10.0f, 9.2f),
            poly(u, 10.4f, 9.2f, 14.2f, 5.2f, 16.4f, 12.4f)
        )
        val ring = diff(hexPath(u, 14.8f, 9.2f, 7.4f), hexPath(u, 14.8f, 9.2f, 5.6f))
        union(diff(ring, headEx), diff(head, circ(u, 6.6f, 14.6f, 1.05f), circ(u, 11.1f, 16.4f, 1.05f)))
    }
    "LSPosed" -> {
        // 两条交叉的创可贴，中间一组小点
        val c = 12f * u
        val a1 = rot(rrect(u, 1.2f, 8.6f, 21.6f, 6.8f, 3.4f), 45f, c)
        val b1 = rot(rrect(u, 1.2f, 8.6f, 21.6f, 6.8f, 3.4f), -45f, c)
        diff(
            union(a1, b1),
            circ(u, 12f, 10.3f, 0.95f), circ(u, 13.7f, 12f, 0.95f), circ(u, 12f, 13.7f, 0.95f), circ(u, 10.3f, 12f, 0.95f)
        )
    }
    "Magisk" -> diff(
        poly(u, 3f, 2.5f, 9.2f, 6.8f, 14.8f, 6.8f, 21f, 2.5f, 20.2f, 12.5f, 12f, 21.5f, 3.8f, 12.5f),
        poly(u, 6.2f, 11f, 10.6f, 12.4f, 8.4f, 14.4f), poly(u, 17.8f, 11f, 13.4f, 12.4f, 15.6f, 14.4f)
    )
    "RRO" -> poly(u, 12f, 2.5f, 21.5f, 7.5f, 12f, 12.5f, 2.5f, 7.5f)
    "SystemUI" -> union(
        rrect(u, 9f, 8f, 2.8f, 2.8f, 0.9f), rrect(u, 12.2f, 8f, 2.8f, 2.8f, 0.9f),
        rrect(u, 9f, 11.8f, 2.8f, 2.8f, 0.9f), rrect(u, 12.2f, 11.8f, 2.8f, 2.8f, 0.9f),
        circ(u, 12f, 5f, 0.9f)
    )
    "Fold" -> rrect(u, 3f, 4f, 8.6f, 16f, 2.6f)
    "DeX" -> rrect(u, 15.5f, 10.5f, 5.5f, 10f, 1.4f)
    "Watch" -> union(rrect(u, 9f, 1.5f, 6f, 4.6f, 1.2f), rrect(u, 9f, 17.9f, 6f, 4.6f, 1.2f))
    "Root", "字体" -> null
    else -> if (name.startsWith("One UI")) null else diff(
        poly(u, 3.5f, 3.5f, 12f, 3.5f, 20.5f, 12f, 12f, 20.5f, 3.5f, 12f), circ(u, 7.9f, 7.9f, 1.7f)
    )
}

/** 轮廓线条部分（外框、层叠线、指针等）。 */
private fun DrawScope.glyphExtras(name: String, c: Color, u: Float) {
    val st = Stroke(2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun ln(x1: Float, y1: Float, x2: Float, y2: Float, w: Float = 2f) =
        drawLine(c, Offset(x1 * u, y1 * u), Offset(x2 * u, y2 * u), w * u, StrokeCap.Round)
    fun outline(x: Float, y: Float, w: Float, h: Float, r: Float) =
        drawRoundRect(c, Offset(x * u, y * u), Size(w * u, h * u), CornerRadius(r * u), style = st)

    when {
        name.startsWith("One UI") -> outline(3f, 3f, 18f, 18f, 6f)
        name == "SystemUI" -> outline(6.5f, 2f, 11f, 20f, 3f)
        name == "RRO" -> {
            val p = Path().apply {
                moveTo(2.5f * u, 11.8f * u); lineTo(12f * u, 16.8f * u); lineTo(21.5f * u, 11.8f * u)
                moveTo(2.5f * u, 15.8f * u); lineTo(12f * u, 20.8f * u); lineTo(21.5f * u, 15.8f * u)
            }
            drawPath(p, c, style = st)
        }
        name == "Root" -> {
            outline(2.5f, 4f, 19f, 16f, 2.8f)
            val p = Path().apply { moveTo(7f * u, 9.4f * u); lineTo(10.8f * u, 12.2f * u); lineTo(7f * u, 15f * u) }
            drawPath(p, c, style = st)
            ln(12.8f, 15.4f, 17f, 15.4f)
        }
        name == "DeX" -> { outline(2f, 4f, 20f, 12.5f, 2.2f); ln(12f, 16.6f, 12f, 20f); ln(8f, 20.4f, 14f, 20.4f) }
        name == "Fold" -> outline(12.4f, 4f, 8.6f, 16f, 2.6f)
        name == "Watch" -> {
            drawCircle(c, 5.8f * u, Offset(12f * u, 12f * u), style = st)
            ln(12f, 12f, 12f, 8.8f, 1.8f); ln(12f, 12f, 14.4f, 13.4f, 1.8f)
        }
    }
}
