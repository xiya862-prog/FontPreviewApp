package com.oneuirepo.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** 分类内的自定义标签：项目多的时候，用标签在一个分类里再分组。 */
@Entity(tableName = "category_tag")
data class CategoryTagEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val categoryId: String,
    val name: String
)

/** 项目 ↔ 标签（一个项目可以放进多个标签）。 */
@Entity(tableName = "repo_tag", primaryKeys = ["repositoryId", "tagId"])
data class RepoTagEntity(val repositoryId: Long, val tagId: Long)
