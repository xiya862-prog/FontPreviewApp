package com.oneuirepo.app.ui.category

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.ui.common.IconKind
import com.oneuirepo.app.ui.common.NameInputDialog

@Composable
fun NewCategoryDialog(existing: Set<String>, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    NameInputDialog(
        title = "新建分类",
        subtitle = "新分类会出现在分类页，可手动放入项目",
        placeholder = "分类名称，例如：电池优化",
        leading = IconKind.TAG,
        existing = existing,
        duplicateMessage = "这个分类已经存在",
        maxLen = 20,
        onDismiss = onDismiss,
        onConfirm = onConfirm
    ) { name ->
        // 实时预览：和分类页卡片同样的渐变底 + 标签插画，颜色按名字固定
        val cat = catOf("c:" + name.ifEmpty { "分类名称" })
        val c1 by animateColorAsState(cat.color, tween(300), label = "pv1")
        val c2 by animateColorAsState(cat.color.deep(0.78f), tween(300), label = "pv2")
        Box(
            Modifier.width(168.dp).height(104.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(c1, c2)))
        ) {
            CategoryArt("自建", cat.color.deep(), Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 8.dp), size = 56.dp)
            Text(
                name.ifEmpty { "分类名称" },
                Modifier.align(Alignment.BottomStart).padding(horizontal = 14.dp, vertical = 12.dp),
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = if (name.isEmpty()) 0.7f else 1f), maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}
