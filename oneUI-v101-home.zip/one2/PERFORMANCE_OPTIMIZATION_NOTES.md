# one Store 源码性能优化记录

## 本轮优化（基于 oneUI-v46）

- 移除首页未使用的 HomeViewModel / 工厂及三个未被界面展示的数据库 Flow，避免创建无用 ViewModel 和无效依赖。
- GitHub 仓库导入/更新时，将 Topics、README、Releases 三个互不依赖的 API 请求并行执行；单个端点失败时仍按原有逻辑回退，取消协程时正常传播取消信号。
- 发现页分页加载在启动协程前同步设置 loading 状态，防止列表触底连续回调造成重复请求。
- PickerSheet 选项列表使用稳定 key，减少选项状态变化时的错误复用。
- 保留既有页面入口、收藏/工具区逻辑、数据库 schema、下载、登录、导航和 GitHub Actions 配置；没有新增依赖。

## 验证

- 已检查修改点与调用签名，确认 HomeScreen 调用处同步更新。
- 已检查 ZIP 内项目结构和构建配置未被替换。
- 当前环境没有可用的 Gradle 命令或 Android SDK，无法在此执行 `:app:assembleDebug`、单元测试或设备级帧率测试；不能将静态检查描述为构建成功。
- 合并前请在 GitHub Actions 运行现有构建，并在 Galaxy Z Fold 外屏/展开屏验证导入、失败回退、分页、收藏、工具、导航及页面状态。

## 后续性能测量建议

使用 Android Studio Profiler / Macrobenchmark 测量冷启动、页面切换、列表滑动帧时间和内存；根据实测热点再优化，避免未经验证的大规模重写。
